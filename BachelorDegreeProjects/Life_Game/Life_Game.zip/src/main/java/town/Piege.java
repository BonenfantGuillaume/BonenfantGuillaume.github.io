package town;

public interface Piege {
    // determine si une case présente un piège et affecte le personnage en consequence
    void determinerPiege(Personnage pers);
}
