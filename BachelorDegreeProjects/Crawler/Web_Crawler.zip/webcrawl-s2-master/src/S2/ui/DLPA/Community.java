package S2.ui.DLPA;

import fr.univavignon.ceri.webcrawl.GraphPackage.Node;

import java.util.ArrayList;

public class Community {

    private int communityLabel;
    private ArrayList<Node> listNode = new ArrayList<>();

    public Community(int CN)
    {
        this.communityLabel = CN;
    }

    public int getLabel()
    {
        return this.communityLabel;
    }

    public void addNode(Node node)
    {
        listNode.add(node);
    }

    public int getNbrOfNode()
    {
        return listNode.size();
    }

}
