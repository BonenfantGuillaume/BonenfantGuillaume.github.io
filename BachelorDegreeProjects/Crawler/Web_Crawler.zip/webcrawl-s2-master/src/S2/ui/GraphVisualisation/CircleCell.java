package S2.ui.GraphVisualisation;

import javafx.scene.control.Tooltip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;


import S2.ui.GraphVisualisation.Cell;

public class CircleCell extends Cell {

    public CircleCell(String id, double rank) {       //builder with rank
        super(id); //we call the constructor Cell with the id
        double size= rank*50; //we calculate the vertice size with the coefficient calculated with the pagerank algorithm
        if (size>100){
            size=100;
            System.out.println("-----------");
            System.out.println("Un noeud est trop grand et a ete redimmensionne!!");
            System.out.println("-----------");

        }
        Circle view = new Circle(size); //we create the circle with the size we calculate with the pagerank algorithm
        view.setStroke(Color.DODGERBLUE); //we pick the color for the border of the cirlce
        view.setFill(Color.DODGERBLUE); //we pick the color to fill the circle

        Tooltip t = new Tooltip(id); //we create a tooltip for the vertice with its ID inside
        Tooltip.install(view, t); //and we add it to the vertice

        setView(view);

    }
}