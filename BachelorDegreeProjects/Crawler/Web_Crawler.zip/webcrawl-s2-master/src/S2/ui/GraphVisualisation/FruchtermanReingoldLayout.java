package S2.ui.GraphVisualisation;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.lang.Math;

import static java.lang.Math.max;
import static java.lang.Math.min;

public class FruchtermanReingoldLayout extends Layout {

    private Graph graph;
    private List<Edge> everyEdges;
    private List<Cell> everyCell;
    private int iteration;
    private Pane graphDisplay;

    private static final double EPSILON = 0.000001D;


        private double forceAttraction(double force, double delta)
        {
            return (delta*delta)/force;
        }

        private double forceRepulsion(double force, double delta)
        {
            return (force*force)/delta;
        }

    public FruchtermanReingoldLayout(Graph graph, Pane graphDisplay) {

            this.graph = graph;
            this.everyEdges = graph.getModel().getAllEdges();
            this.everyCell = graph.getModel().getAllCells();
            this.graphDisplay = graphDisplay;

        }


    public int getIteration()
    {
        return iteration;
    }

    //we perfom the Fruchterman Reingold layout algorithm here
    public void execute() {

            //we get the size of our pane that we're using as a frame for our graphe
            double borderPaneHeight = graphDisplay.getPrefHeight();
            double borderPaneWidth = graphDisplay.getPrefWidth();
            iteration = 700;
            double W = borderPaneWidth - 20;
            double L = borderPaneHeight - 20;
            double forceConstant = 0.75 * Math.sqrt(borderPaneHeight*borderPaneWidth / everyCell.size());

            List<Cell> cells = this.everyCell; //We get every vertices that are in the graph

            //Position of each vertice (picked randomly later)
            ArrayList<Double> cord_x = new ArrayList<Double>(); // X coordinate of each vertice
            ArrayList<Double> cord_y = new ArrayList<Double>(); // Y coordinates of each vertice
            HashMap<String, Integer> nom_num = new HashMap<String, Integer>();

            for(Edge e : everyEdges)
            {
                cord_x.add(Math.random() * W);
                cord_y.add(Math.random() * L);
            }

            int numerotate = 0;
            for(Cell c : everyCell )
            {
                nom_num.put(c.getCellId(), numerotate);
                numerotate++;
            }

            ArrayList<Double> cord_dx = new ArrayList<Double>();
            ArrayList<Double> cord_dy = new ArrayList<Double>();

            double t = W / 10;


            for(int i = 0; i < iteration; i++) {

                // We Calculate repulsion
                for (int j = 0; j != cord_x.size(); j++)
                {

                    cord_dx.add(0.0);
                    cord_dy.add(0.0);

                    for (int u = 0; u != cord_x.size(); u++)
                    {
                        if (j != u)
                            {

                                double dx = cord_x.get(j) - cord_x.get(u);
                                double dy = cord_y.get(j) - cord_y.get(u);

                                double delta = Math.max(EPSILON, Math.sqrt(dx * dx + dy * dy));
                                if (delta != 0)
                                {
                                    double f = forceRepulsion(forceConstant, delta);
                                    cord_dx.set(j, cord_dx.get(j) + ((dx/delta) * f));
                                    cord_dy.set(j, cord_dy.get(j) + ((dy/delta) * f));
                                }
                        }
                    }
                }

                // Calculate attraction
                for (Edge e : everyEdges)
                {

                    double dx = cord_x.get(nom_num.get(e.getSource().getCellId())) - cord_x.get(nom_num.get(e.getTarget().getCellId()));
                    double dy = cord_y.get(nom_num.get(e.getSource().getCellId())) - cord_y.get(nom_num.get(e.getTarget().getCellId()));

                    double delta = Math.max(EPSILON, Math.sqrt(dx * dx + dy * dy));

                    if (delta != 0)
                    {
                        double f = forceAttraction(forceConstant, delta) ;
                        double ddx = (dx/delta) * f;
                        double ddy = (dy/delta) * f;

                        cord_dx.set(nom_num.get(e.getSource().getCellId()), cord_dx.get(nom_num.get(e.getSource().getCellId())) + -ddx);
                        cord_dx.set(nom_num.get(e.getTarget().getCellId()), cord_dx.get(nom_num.get(e.getTarget().getCellId())) + ddx);

                        cord_dy.set(nom_num.get(e.getSource().getCellId()), cord_dy.get(nom_num.get(e.getSource().getCellId())) + -ddy);
                        cord_dy.set(nom_num.get(e.getTarget().getCellId()), cord_dy.get(nom_num.get(e.getTarget().getCellId())) + ddy);

                    }
                }

                //We calculate the position of each vertice
                for (int v = 0; v < cord_x.size(); v++)
                    {

                        double dx = cord_dx.get(v);
                        double dy = cord_dy.get(v);
                        double deltaLength= Math.max(EPSILON, Math.sqrt(dx * dx + dy * dy));

                        double xDisp = dx/deltaLength * Math.min(deltaLength, t);

                        double yDisp = dy/deltaLength * Math.min(deltaLength, t);

                        cord_x.set(v, cord_x.get(v) + xDisp);
                        cord_y.set(v, cord_y.get(v) + yDisp);


                        double temp_x = cord_x.get(v);
                        double borderWidth = W/50;
                        if(temp_x < borderWidth)
                        {
                            temp_x = 0 + borderWidth +  Math.random() * borderWidth * 2.0;
                        }
                        else if(temp_x > (borderPaneWidth - borderWidth))
                        {
                            temp_x = borderPaneWidth - borderWidth -  Math.random() * borderWidth * 2.0;
                        }

                        double temp_y = cord_y.get(v);
                        double borderHeight = L/50;

                        if(temp_y < borderHeight)
                        {
                            temp_y = 0 + borderPaneHeight +  Math.random() * borderPaneHeight * 2.0;
                        }
                        else if(temp_y > (borderPaneHeight - borderHeight))
                        {
                            temp_y = borderPaneHeight - borderHeight -  Math.random() * borderHeight * 2.0;
                        }

                        cord_x.set(v, temp_x);
                        cord_y.set(v, temp_y);
                    }
                t *= (1.0 - i / (double) iteration);
            }

        int p = 0;
        for (Cell cell : cells)  // For every cells (vertices) in the graph
        {
            System.out.println("N." + p + " | ID : " + cell.getCellId() + " [ x : " + cord_x.get(p) + ", y : " + cord_y.get(p) + " ]");

            double x =  cord_x.get(p); //We get the coordinate on X
            double y =  cord_y.get(p) ;//We get the coordinate on Y

            cell.relocate(x, y); //Then we relocate the cell to theses coordinates.
            p++;

        }

    }
}
