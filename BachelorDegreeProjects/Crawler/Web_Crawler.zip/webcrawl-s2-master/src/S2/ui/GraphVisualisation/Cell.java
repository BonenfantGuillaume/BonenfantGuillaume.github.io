package S2.ui.GraphVisualisation;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

public class Cell extends Pane {

    private String cellId;

    //Child and parents vertices are linked
    private List<Cell> children = new ArrayList<>(); //List of the child vertices
    private List<Cell> parents = new ArrayList<>(); //List of the parents vertices

    private Node view;

    public Cell(String cellId) { this.cellId = cellId; }

    public void addCellChild(Cell cell) { children.add(cell); }

    public void addCellParent(Cell cell) {  parents.add(cell); }

    public void setView(Node view) {

        this.view = view;
        getChildren().add(view);

    }

    public Node getView() {
        return this.view;
    }

    public String getCellId() {
        return cellId;
    }
}
