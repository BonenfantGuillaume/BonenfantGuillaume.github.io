package S2.ui.GraphVisualisation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Model {

    private List<Cell> allCells;
    private List<Cell> addedCells;
    private List<Cell> removedCells;

    private List<Edge> allEdges;
    private List<Edge> addedEdges;
    private List<Edge> removedEdges;

    private Map<String,Cell> cellMap;

    public Model() {
         clear();
    }

    public void clear() {

        allCells = new ArrayList<>();
        addedCells = new ArrayList<>();
        removedCells = new ArrayList<>();

        allEdges = new ArrayList<>();
        addedEdges = new ArrayList<>();
        removedEdges = new ArrayList<>();

        cellMap = new HashMap<>();

    }

    //we get every vertices added during last merge
    public List<Cell> getAddedCells() {
        return addedCells;
    }
    
    //We get every vertices
    public List<Cell> getAllCells() {
        return allCells;
    }

    //we get every edges added during last merge
    public List<Edge> getAddedEdges() {
        return addedEdges;
    }
    

    //we get every edges
    public List<Edge> getAllEdges() {
        return allEdges;
    }

    //add node with rank
    public void addCell(String id,double size) {

        CircleCell circleCell = new CircleCell(id,size);
        addCell(circleCell);

    }

    //add cell object
    private void addCell( Cell cell) {

        addedCells.add(cell);

        cellMap.put( cell.getCellId(), cell);

    }

    //we add an edge between 2 vertices
    public void addEdge( String sourceId, String targetId) {

        Cell sourceCell = cellMap.get(sourceId);
        Cell targetCell = cellMap.get(targetId);

        Edge edge = new Edge( sourceCell, targetCell);

        addedEdges.add( edge);

    }

    //We update the model
    public void merge() {

        // cells
        allCells.addAll( addedCells);
        allCells.removeAll( removedCells);

        addedCells.clear();
        removedCells.clear();

        // edges
        allEdges.addAll( addedEdges);
        allEdges.removeAll( removedEdges);

        addedEdges.clear();
        removedEdges.clear();
    }
}
