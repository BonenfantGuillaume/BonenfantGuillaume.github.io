package S2.ui.Stats;

import fr.univavignon.ceri.webcrawl.GraphPackage.EdgeException;
import fr.univavignon.ceri.webcrawl.GraphPackage.Graph;
import fr.univavignon.ceri.webcrawl.GraphPackage.Node;

import java.util.ArrayList;
import java.util.HashMap;

public class Test {

    public static void main(String[] args) {
        Graph g1=new Graph();
        g1.readGraphml("Graphs/test-DLPA.graphml");
        System.out.println(g1);


        /*System.out.println("\n##Stats");

        Stats stats = new Stats(g1);

        System.out.println("\n#Degrees");
        stats.degreeCalculation();

        System.out.println("\nTotal Degrees :");
        ArrayList<Integer> totalDegrees = stats.getTotalDegreesTable();
        System.out.println(totalDegrees);

        System.out.println("\nOut Degrees :");
        ArrayList<Integer> outDegrees = stats.getOutDegreesTable();
        System.out.println(outDegrees);

        System.out.println("\nIn Degrees :");
        ArrayList<Integer> inDegrees = stats.getInDegreesTable();
        System.out.println(inDegrees);

        System.out.println("\n#Transitivity");
        stats.transitivityCalculation();
        System.out.println("Global transitivity : " + stats.getGlobalTransitivity());
        System.out.println("Local Transitivity : " + stats.getLocalTransitivityTable());

        System.out.println("\n#Dijkstra : ");
        int x = 0;
        stats.dijkstra(g1.getlistNode().get(x));
        System.out.println("Fathers starting from " + x + " : ");
        int[][] fatherMatrix = stats.getFatherMatrix();
        for (int i = 0; i < g1.getlistNode().size(); i++)
        {
            System.out.println("Node " + i + " has for father " + fatherMatrix[x][i] + " starting from " + x);
        }
        System.out.println("\nDistances starting from " + x + " : ");
        int[][] distanceMatrix = stats.getDistanceMatrix();
        for (int i = 0; i < g1.getlistNode().size(); i++)
        {
            System.out.println("Node " + i + " has for distance " + distanceMatrix[x][i] + " starting from " + x);
        }
        System.out.println("Average Distance to reach another node : " + stats.getAvgDistanceTable().get(x));


        System.out.println("\nReciprocity : ");
        stats.reciprocity();
        System.out.println("Reciprocity = " + stats.getReciprocity());*/

        System.out.println("\nStats :");
        Stats stats = new Stats(g1);
        stats.degreeCalculation();//Degree calcul
        stats.transitivityCalculation();//Transitivity calcul
        for (Node node : g1.getlistNode())
        {
            stats.dijkstra(node);
        }
        stats.reciprocity();
        stats.assortativity();
        ArrayList<Integer> totalDegrees = stats.getTotalDegreesTable();
        ArrayList<Integer> outDegrees = stats.getOutDegreesTable();
        ArrayList<Integer> inDegrees = stats.getInDegreesTable();
        float globalTransitivity = stats.getGlobalTransitivity();
        ArrayList<Float> localTransitivities = stats.getLocalTransitivityTable();
        ArrayList<Float> avgDistances = stats.getAvgDistanceTable();
        float reciprocity = stats.getReciprocity();
        float assortativity = stats.getAssortativity();

        System.out.println("\nPrints : ");
        System.out.println("Total degrees for each node : " + totalDegrees);
        System.out.println("Out degrees for each node : " + outDegrees);
        System.out.println("In degrees for each node : " + inDegrees);
        System.out.println("Global transitivity : " + globalTransitivity);
        System.out.println("Local transitivity for each node : " + localTransitivities);
        System.out.println("Average distance to reach another node : " + avgDistances);
        System.out.println("Reciprocity : " + reciprocity);
        System.out.println("Assortativity : " + assortativity);


        stats.maxDegree();
        int maxDegree = stats.getMaxDegree();
        Node nodeMaxDegree = stats.getNodeMaxDegree();
        System.out.println("Max degree : " + maxDegree);
        System.out.println("Node max degree : " + nodeMaxDegree.getId());


        //#######
        //useful for the final project :
        //stats.getTotalDegreesTable()
        //stats.getOutDegreesTable()
        //stats.getInDegreesTable()
        //stats.getGlobalTransitivity()
        //stats.getLocalTransitivity()
        //stats.getAvgDistanceTable()
        //stats.getReciprocity
        //#######


        System.out.println("\nFinished");
    }
}