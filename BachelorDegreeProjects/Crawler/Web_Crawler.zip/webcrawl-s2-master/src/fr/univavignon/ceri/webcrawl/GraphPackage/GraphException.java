package fr.univavignon.ceri.webcrawl.GraphPackage;

public class GraphException extends Exception{
	
	public GraphException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
