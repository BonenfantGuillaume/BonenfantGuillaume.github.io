package fr.univavignon.ceri.webcrawl.GraphPackage;

public class EdgeException extends GraphException{

	public EdgeException(Edge l,String err) {
		super("Erreur avec le lien ("+l.toString() +") : "+err);
	}
}