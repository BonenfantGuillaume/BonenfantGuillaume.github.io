package fr.univavignon.ceri.webcrawl.uiPackage.address.view;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import fr.univavignon.ceri.webcrawl.UrlTable;
import fr.univavignon.ceri.webcrawl.uiPackage.address.MainApp;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.LaunchSettings;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.Url;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;

import javafx.scene.control.cell.TextFieldTableCell;

public class UrlOverviewController {

	@FXML
    private TableView<Url> urlTable; 
	
	@FXML 
	private Button b1; 
	
    @FXML
    private TableColumn<Url, String> urlColumn;
    
    
    @FXML
    private Label urlLabel;

    // Reference to the main application.
    private MainApp mainApp;
    
    private LaunchSettings settings;

    public UrlOverviewController() {
	
    }

    
    @FXML
    private void initialize() {
    	// Initialize the person table with the two columns.
    	//TableColumn<Url, String>  urlColumn = new TableColumn<Url, String>("URL");
    	urlColumn.setCellValueFactory(cellData -> cellData.getValue().urlProperty());
    	urlColumn.setCellFactory(TextFieldTableCell.<Url>forTableColumn());
    	
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        this.settings = mainApp.getSettings(); 
        //System.out.println(this.mainApp);
        // Add observable list data to the table
        /*SceneController sceneC = this.mainApp.getSceneController(); 
        sceneC.buttonDisable("b1"); */
        urlTable.setItems(settings.getUrlData());
          
    }
    
    public void deleteUrl()
    {
    	int selectedIndex = 0;  
    	selectedIndex = urlTable.getSelectionModel().getSelectedIndex(); 
    	if(selectedIndex >= 0)
    	{
    		urlTable.getItems().remove(selectedIndex); 
    	}
    	
    	SceneController sceneC = this.mainApp.getSceneController(); 
    	if(settings.getUrlData().size() == 0)
        {
    		sceneC.buttonDisable("b3");
        }
          	
    }
    
    @FXML
    public void addUrl() 
    {
        Url tempU = new Url("https://");
       
        //mainApp.getSettings().getUrlData().add(tempU);
        settings.getUrlData().add(tempU); 
    }
    
    @FXML
    public void modifyAndCheckValidURL(CellEditEvent<Url, String> t)
    {
    	Pattern p = Pattern.compile("(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?(https://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?"); 
    	
        ((Url) t.getTableView().getItems().get(
            t.getTablePosition().getRow())
            ).setUrl(t.getNewValue());
               
        SceneController sceneC = this.mainApp.getSceneController(); 
    	
        if(settings.getUrlData().size() > 0)
        {
        	sceneC.buttonEnable("b3");
        }
        else
        {
        	sceneC.buttonDisable("b3");
        }
        
        //for (Url i : settings.getUrlData())
        //{
        	
       	 //System.out.println(t.getNewValue());
         Matcher m1 = p.matcher(t.getNewValue()); 
       	
       	 boolean b = m1.matches();
       	 
       	 System.out.println(b + " ");
       	 if(!b)
       		{
       		 
       		sceneC.buttonDisable("b3");
       		//break; 
       		}
        	
        //}
    	
        
    }
    
    
    
	
}
