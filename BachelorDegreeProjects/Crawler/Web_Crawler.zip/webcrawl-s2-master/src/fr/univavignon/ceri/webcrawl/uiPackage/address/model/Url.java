package fr.univavignon.ceri.webcrawl.uiPackage.address.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Model class for a Person.
 *
 * @author Marco Jakob //inspir� de
 */
public class Url {

	private final StringProperty url;
	

	/**
	 * Default constructor.
	 */
	public Url() {
		this(null);
	}
	
	/**
	 * Constructor with some initial data.
	 * 
	 * @param firstName
	 * @param lastName
	 */
	public Url(String u) {
		this.url = new SimpleStringProperty(u);
		
		
		// Some initial dummy data, just for convenient testing.
		
	}
	
	public String getUrl() {
		return url.get();
	}

	public void setUrl(String u) {
		this.url.set(u);
	}
	
	public StringProperty urlProperty() {
		return url;
	}
	
	
}