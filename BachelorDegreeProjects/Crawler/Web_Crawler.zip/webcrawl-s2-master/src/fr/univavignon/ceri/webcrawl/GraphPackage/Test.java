package fr.univavignon.ceri.webcrawl.GraphPackage;


//http://graphml.graphdrawing.org/primer/graphml-primer.html

/**
 * @author audran
 * Main 
 */
public class Test {

	public static void main(String[] args) {
		/*
		Graphe g1 = new Graphe(false);
		//Lien l1=new Lien("Site1",1,"Site2");
		//n1.addedge(l1);
		//n1.addedge("Site1",1,"Site5");
		g1.addnode("Site1","url1");
		g1.addnode("Site2","url2");
		try {
			g1.addedge("Site1", 1, "Site2");
			g1.addedge("Site1", "Site2");
			g1.addedge("Site1", 1, "Site3");
			Noeud n3 = new Noeud("Site3","url3");
			g1.addnode(n3);	
			g1.addedge("Site2", 1, "Site3");
			g1.addedge("Site3", 1, "Site1");
			g1.addedge("Site1", 1, "Site1");
			System.out.println(g1.toString());
			g1.exportgraphe();
		}catch (LienException  e) {
			System.err.println("Main.main() "+e.getMessage());
			System.exit(-1);
		}

	}*/
	
	
	    //Graphe
		Graph g1 = new Graph(false);
		g1.addNode("Site1","https://url1");
		g1.addNode("Site2","https://url2");
		try {
			g1.addEdge("Site1", 2, "Site2");
			g1.addEdge("Site1", "Site2");
			g1.addEdge("Site1", 1, "Site3");
			Node n3 = new Node("Site3","https://url3");
			g1.addNode(n3);
			g1.addEdge("Site2", 3, "Site3");
			g1.addEdge("Site3", 5, "Site1");
			g1.addEdge("Site3", 4, "Site2");
			System.out.println(g1.toString());
		}catch (EdgeException  e) {
			System.err.println("Main.main() "+e.getMessage());
			System.exit(-1);
		}
		g1.exportToGraphml();
	}	
}