package fr.univavignon.ceri.webcrawl.ParserPackage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;


public class RobotsTxt {
	private boolean exist; //vrai si le fichier robots.txt du domaine existe
	private URL robotUrl;
	private ArrayList<String> disallowTable = new ArrayList<String>(); //tableau d'interdictions
	private ArrayList<String> allowTable = new ArrayList<String>(); //tableau d'autorisations
	private ArrayList<URL> sitemap = new ArrayList<URL>();
	private ArrayList<URL> sitemapToParse;
	private boolean sitemapBool;

	public RobotsTxt(URL site, boolean sitemapBoolCopy) throws Exception
	{
		this.robotUrl = new URL ("https://" + site.getHost() + "/robots.txt"); //url du fichier robots.txt pour le domaine
		RobotAnalysis(site);
		if(!(disallowTable.isEmpty()) || !(allowTable.isEmpty())) //le fichier robots.txt existe et donne au moins une information nous concernant
		{
			exist = true;
		}
		else //le fichier robots.txt n'existe pas ou ne donne aucune information nous concernant
		{
			exist = false;
		}
		this.sitemapBool = sitemapBoolCopy;
		if(this.sitemapBool)
		{
			ArrayList<String> alreadyParsed = new ArrayList<String>();
			if(sitemap != null)
			{
				sitemapToParse = SitemapParser(sitemap, alreadyParsed);
			}
		}
	}

	public RobotsTxt() {
		sitemapToParse = new ArrayList<URL>();
	}

	private void RobotAnalysis(URL site)
	{
		try {
			BufferedReader BR = new BufferedReader(new InputStreamReader(robotUrl.openStream()));
			String text;
			boolean copy = false;
			while ((text = BR.readLine()) != null)
			{
				if(text.matches("User-agent: \\*")) //Les prochaines informations vont nous concernes
				{
					copy = true; //Donc on va stocker les informations
				}
				else if(text.matches("User-agent: (\\w)*")) //Les prochaines informations ne nous concerneront pas
				{
					copy = false; //Donc on les ignorera
				}
				else if(text.matches("Sitemap:\\s+https://" + site.getHost() + "(/(\\w)+)*((\\-)|(\\.)\\w+)*.xml(.gz)?(/)?$")) //Il y a un sitemap
				{
					text = text.replace("Sitemap:", "");
					text = text.replaceAll(" ", "");
					this.sitemap.add(new URL (text)); //On rcupre l'url du sitemap
				}
				else if(copy == true)
				{
					if(text.contains("Disallow: ")) //On nous donne une interdiction
					{
						text = text.replace("Disallow:", "");
						text = text.replaceAll(" ", "");
						this.disallowTable.add(text); //On rajoute l'information utile dans le tableau disallowTable
					}
					else if(text.contains("Allow: "))  //On nous donne une autorisation
					{
						text = text.replace("Allow:", "");
						text = text.replaceAll(" ", "");
						this.allowTable.add(text); //On rajoute l'information utile dans le tableau allowTable
					}
				}
			}
			BR.close();
		}
		catch(IOException e){ //exception de lecture pour openstream()
			System.err.println(e);
		}
	}

	private ArrayList<URL> SitemapParser(ArrayList<URL> map, ArrayList<String> alreadyParsed)
	{
		ArrayList<URL> urlToParse = new ArrayList<URL>();
		ArrayList<URL> sitemapIndex = new ArrayList<URL>();
		for(URL site : map)
		{
			try {
				BufferedReader BR = new BufferedReader(new InputStreamReader(site.openStream()));
				String text;
				boolean copy = false;
				while ((text = BR.readLine()) != null)
				{
					if(text.contains("<loc>") && !(text.contains("</loc>")))
					{
						copy = true;
					}
					else if(text.contains("</loc>") && !(text.contains("<loc>")))
					{
						copy = false;
					}
					else if(text.contains("<loc>") && text.contains("</loc>"))
					{
						text = text.replace("<loc>", "");
						text = text.replace("</loc>", "");
						text = text.replaceAll(" ", "");
						if(text.matches("https://" + robotUrl.getHost() + "(/(\\w)+)*(\\-\\w+)*.xml(.gz)?(/)?$"))
						{
							sitemapIndex.add(new URL (text));
						}
						else if(text.matches("https://" + robotUrl.getHost() + "(/(\\w)+(\\-\\w+)*)*((\\-\\w+)|(\\.\\w+))*(/)?$") && !(alreadyParsed.contains(text)))
						{
							urlToParse.add(new URL (text));
							alreadyParsed.add(text);
						}
					}
					else if (copy == true)
					{
						text = text.replaceAll(" ", "");
						if(text.matches("https://" + robotUrl.getHost() + "(/(\\w)+)*(\\-\\w+)*.xml(/)?$"))
						{
							sitemapIndex.add(new URL (text));
						}
						else if(text.matches("https://" + robotUrl.getHost() + "(/(\\w)+(\\-\\w+)*)*((\\-\\w+)|(\\.\\w+))*(/)?$") && !(alreadyParsed.contains(text)))
						{
							urlToParse.add(new URL (text));
							alreadyParsed.add(text);
						}
					}
				}
				BR.close();
			}
			catch(IOException e){ //exception de lecture pour openstream()
				System.err.println(e);
			}
		}
		if (!(sitemapIndex.isEmpty()))
		{
			urlToParse.addAll(SitemapParser(sitemapIndex, alreadyParsed));
		}
		return urlToParse;
	}

	public boolean Access(String fullUrl)
	{
		boolean access = true;

		for(String disallow : disallowTable)
		{
			if(fullUrl.contains(disallow))
			{
				access = false;
			}
		}

		for(String allow : allowTable)
		{
			if(fullUrl.contains(allow) && allow != "\\")
			{
				access = true;
			}
		}

		return access;
	}

	public ArrayList<String> getDisallowTable()
	{
		return this.disallowTable;
	}

	public ArrayList<String> getAllowTable()
	{
		return this.allowTable;
	}

	public boolean getExist()
	{
		return this.exist;
	}

	public ArrayList<URL> getSitemap()
	{
		return this.sitemap;
	}

	public ArrayList<URL> getSitemapToParse()
	{
		return this.sitemapToParse;
	}
}
