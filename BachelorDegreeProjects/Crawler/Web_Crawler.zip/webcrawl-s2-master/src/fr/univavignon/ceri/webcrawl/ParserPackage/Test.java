package fr.univavignon.ceri.webcrawl.ParserPackage;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class Test {
	public static void main(String[] args) throws Exception {

		LinkParser wikipedia = new LinkParser(new URL("https://www.google.com"),false,"Domaine",2, null, new HashMap<URL, RobotsTxt>(), true, true);

		for(LinkParser LP : wikipedia.getURLList())
		{
			System.out.println(LP.getHauteur() + " " + LP.getURL());
			for(LinkParser LP2 : LP.getURLList())
			{
				System.out.println(LP2.getURL());
			}
		}

		System.out.println("test");

	}
}
