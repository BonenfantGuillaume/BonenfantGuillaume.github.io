package fr.univavignon.ceri.webcrawl.GraphPackage;
import java.net.URL;
import java.util.*;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import fr.univavignon.ceri.webcrawl.ParserPackage.LinkParser;

/**
 * @author audran
 * Node class
 */
public class Node {
	private int id=-1; 					//id of the node
	private String name;				//name
	private String url;					//url
	private ArrayList<Edge> listEdge;	//edges that starts from the node
	private int label;				//labels of the node
	private boolean hasChanged;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ArrayList<Edge> getListEdge(){
		return listEdge;
	}

	/**
	 * Constructeur
	 * @param name
	 * @param url
	 */
	public Node(String name, String url) {
		super();
		this.name = name;
		this.url=url;
		this.listEdge=null;
	}

	public Node(int id,String name, String url) {
		super();
		this.id=id;
		this.name = name;
		this.url=url;
		this.listEdge=null;
	}


	/**
	 * ToString
	 * @return String
	 */
	@Override
	public String toString() {
		String texte="";
		if (listEdge!=null) {
			for (int i=0;i<listEdge.size();i++) {
				texte=texte+"\n"+listEdge.get(i).toString();
			}		
		}
		return name + ":\n[listEdge("+url+"):" + texte + "\n]";
	}

	/**
	 * addedge
	 * @param nedge
	 * @return boolean
	 */
	public boolean addEdge(Edge nedge) {					//ajout lien deja cree au node
		if (nedge==null) {
			return false;
		}
		if (listEdge==null){
			listEdge=new ArrayList<Edge>();
		}
		if ((nedge.getsrc()==this.name) && (nedge.getdest()!=null)) {
			return listEdge.add(nedge); 
		}
		return false;
	}
	
	/**
	 * addedge
	 * @param list
	 * @return boolean
	 */
	public boolean addEdge(List<LinkParser> list,boolean graphWeighted) {					//ajout lien deja cree au node
		if (listEdge==null) {
			listEdge=new ArrayList<Edge>();
		}
		if (graphWeighted==false) {	
			if (list!=null) {
				for (int i=0;i<list.size();i++) {
					Edge e=new Edge(name,1,list.get(i).getURL().toString());
					listEdge.add(e);
				}
			}
		}
		else {		//graphe de domaine
			if (list!=null) {
				for (int i=0;i<list.size();i++) {
					boolean found=false;
					for (int j=0;j<listEdge.size();j++) {
						/*if (list.get(i).getURL().toString()=="https://www.google.com") {
							System.out.println(listEdge.get(j).getdest()+" == "+ list.get(i).getURL().toString());
						}*/
						
						if (list.get(i).getURL().toString()==listEdge.get(j).getdest()) {		//si le lien existe deja ajouter
							listEdge.get(j).setweight((listEdge.get(j).getweight())+1);
							found=true;
							//System.out.println("AddWeight");
							break;
						}
					}
					if (found==false) {													//sinon le crer
						Edge e=new Edge(name,1,list.get(i).getURL().toString());
						
						listEdge.add(e);	
					}
				}
			}
		}
		return true;
	}
	
	/**
	 * addedge
	 * @param src
	 * @param weight
	 * @param dest
	 * @return boolean
	 */
	public boolean addEdge(String src,int weight,String dest,int idDest) {			//ajout lien pas cree au node
		if ((src=="") || (weight==0) || (dest=="")){
			return false;
		}
		Edge newEdge;
		if (idDest==-1){
			newEdge=new Edge(src,weight,dest);
		}else {
			newEdge = new Edge(src, weight, dest, idDest);
		}
		if (listEdge==null){
			listEdge=new ArrayList<Edge>();
		}
		if ((newEdge.getsrc()==this.url) && (newEdge.getdest()!=null)) {
			return listEdge.add(newEdge);
		}
		return false;
	}
	
	/**
	 * getfirstedge
	 * @deprecated
	 * @return Edge
	 */
	public Edge getFirstEdge() {
		Edge ret=listEdge.get(0);
		if (ret!=null) {
			return ret;
		}
		return null;
	}

	public void setHasChanged(boolean bool){this.hasChanged = bool;}
	public boolean getHasChanged(){return hasChanged;}

	/**
	 * getname
	 * @return this.name
	 */
	public String getName() {
		return name;
	}

	/**
	 * getlabel
	 * @return this.label
	 */
	public int getLabel() {
		return label;
	}
	public void setLabel(int label) { this.label = label; }
	/**
	 * get url
	 * @return this.url
	 */
	public String getUrl() {
		return url;
	}
	
	/**
	 * search edge
	 * @param src
	 * @param dest
	 * @return edge
	 */

	public int getStrenght() {
		int str = 0;
		if(listEdge!=null)
			for (Edge edge : listEdge) {str += edge.getweight();}
		return str;
	}

	public Edge searchEdge(String src, String dest) {			//cherche un lien
		if (listEdge!=null) {
			for (int i=0;i<listEdge.size();i++) { 
				if ((listEdge.get(i).getsrc()==src) && (listEdge.get(i).getdest()==dest)) {
					return listEdge.get(i);
				}
			}
		}
		return null;
	}
	
	
	
	/**
	 * addedgetodom
	 * @param isWeighted
	 * @param doc
	 * @param graph
	 * @param ct
	 */
	public void addEdgeToDOM(boolean isWeighted,Document doc,Element graph, int ct) {
		if (isWeighted) {
			if (listEdge!=null) {
				for (int i=0;i<listEdge.size();i++) {
					Element edge = doc.createElement("edge");
		            graph.appendChild(edge);
		     
		            // attributs de l'�l�ment graph
		            Attr attr = doc.createAttribute("id");
		            attr.setValue("e"+ct+String.valueOf(i));
		            edge.setAttributeNode(attr);
		            Attr src = doc.createAttribute("source");
		            src.setValue(listEdge.get(i).getsrc());
		            edge.setAttributeNode(src);
		            Attr target = doc.createAttribute("target");
		            target.setValue(listEdge.get(i).getdest());
		            edge.setAttributeNode(target);
		            
		            
		            Element weight = doc.createElement("data");
		            edge.appendChild(weight);
		            attr = doc.createAttribute("key");
		            attr.setValue("e0");
		            weight.appendChild(doc.createTextNode(String.valueOf(listEdge.get(i).getweight())));
		            weight.setAttributeNode(attr); 
	
				}	
			}
		}
		else {
			if (listEdge!=null) {

				for (int i=0;i<listEdge.size();i++) {
					Element edge = doc.createElement("edge");
		            graph.appendChild(edge);
		     
		            // attributs de l'�l�ment graph
		            Attr attr = doc.createAttribute("id");
		            attr.setValue("e"+ct+String.valueOf(i));
		            edge.setAttributeNode(attr);
		            Attr src = doc.createAttribute("source");
		            src.setValue(listEdge.get(i).getsrc());
		            edge.setAttributeNode(src);
		            Attr target = doc.createAttribute("target");
		            target.setValue(listEdge.get(i).getdest());
		            edge.setAttributeNode(target);
				}	
			}
		}
	}
}
