# Webcrawl

### Auteurs

Bert Audran
Bonenfant Guillaume
Hoffman Samy
Rocca Sébastien

### Lancer l'application

Pour lancer l'application il faut avoir java et javafx d'installé. 
Il faut lancer MainApp.java qui se trouve dans src>S2.ui.
 
Il est aussi possible de lancer certaines parties de l'application via des méthodes main dans certaines classes.

Fonctionne sous Eclipse et IntelliJ IDEA.

Il faut sélectionner un fichier GraphML puis cliquer sur visualisation et enfin sur visualiser. Il y a un bouton retour au menu en haut à gauche.

### Description

Cette application permet de sélectionner un fichier GraphML pour le visualiser. Lors de la visualisation on peut voir des données statistiques (et graphiques) sur le graphe, ainsi que la valeur de centralité des noeuds (taille des noeuds). La position des noeuds est déterminé par l'algorithme de spatialisation.
