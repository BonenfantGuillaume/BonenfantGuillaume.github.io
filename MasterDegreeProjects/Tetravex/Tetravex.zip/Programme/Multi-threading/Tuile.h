#include <iostream>

using namespace std;

class Tuile
{
	private :
		int gauche;
		int haut;
		int droite;
		int bas;
	public : 		
		Tuile(int g_copy, int h_copy, int d_copy, int b_copy);
		Tuile();
		Tuile(const Tuile&);
		void affichage();
		int getGauche();
		int getHaut();
		int getDroite();
		int getBas();
		void setGauche(int);
		void setHaut(int);
		void setDroite(int);
		void setBas(int);
};
