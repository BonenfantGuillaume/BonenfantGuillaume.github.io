#include <iostream>
#include "Tuile.h"
#include "Puzzle.h"
#include "Resolution.h"

using namespace std;

Puzzle::Puzzle(int longueur_copy, int largeur_copy, Tuile** tuiles) //création d'un puzzle
{
	cout << "initialisation du puzzle" << endl;
	
	this->longueur = longueur_copy;
	this->largeur = largeur_copy;
	this->puzzle = tuiles;
}

Puzzle::Puzzle(int longueurCopy, int largeurCopy) //création d'un puzzle vide avec juste une longueur, largeur et matrice de tuiles vides
{
	this->longueur = longueurCopy;
	this->largeur = largeurCopy;
	
	this->puzzle = new Tuile * [longueurCopy];
	for (int i = 0; i < longueurCopy; i++)
	{
		this->puzzle[i] = new Tuile [largeurCopy];
	}
}

Puzzle::Puzzle() //constructeur vide pour les tableaux et matrices de puzzle
{
	//cout << "création d'un puzzle vide" << endl;
}

Puzzle::Puzzle(const Puzzle& PuzzleACopier) //constructeur par copie pour cloner
{
	longueur = PuzzleACopier.longueur;
	largeur = PuzzleACopier.largeur;
	
	puzzle = new Tuile * [longueur];
	for (int i = 0; i < longueur; i++)
	{
		puzzle[i] = new Tuile [largeur];
		for (int j = 0; j < largeur; j++)
		{
			puzzle[i][j].setHaut(PuzzleACopier.puzzle[i][j].getHaut());
			puzzle[i][j].setDroite(PuzzleACopier.puzzle[i][j].getDroite());
			puzzle[i][j].setBas(PuzzleACopier.puzzle[i][j].getBas());
			puzzle[i][j].setGauche(PuzzleACopier.puzzle[i][j].getGauche());
		}
	}
}

void Puzzle::addTuile(int i, int j, Tuile tuileCopy) //pour ajouter sur une case précise du puzzle (utile en partant d'un puzzle vide)
{
	this->puzzle[i][j] = tuileCopy;
}

void Puzzle::affichage() //affichage du puzzle
{
	for (int i = 0; i < longueur; i++)
	{
		for (int j = 0; j < largeur; j++)
		{
			cout << " / " << puzzle[i][j].getHaut() << " \\ ";
		}

		cout << endl;

		for (int j = 0; j < largeur; j++)
		{
			cout << " " << puzzle[i][j].getGauche() << "   " << puzzle[i][j].getDroite() << " ";
		}
		
		cout << endl;

		for (int j = 0; j < largeur; j++)
		{
			cout << " \\ " << puzzle[i][j].getBas() << " / ";
		}

		cout << endl << endl;
	}
}

Tuile Puzzle::getTuile(int numeroTuile)
{
	return (*this).puzzle[numeroTuile/this->longueur][numeroTuile%this->largeur];
}

Tuile Puzzle::getTuile(int i, int j)
{
	return (*this).puzzle[i][j];
}

int Puzzle::getLongueur()
{
	return this->longueur;
}

int Puzzle::getLargeur()
{
	return this->largeur;
}
