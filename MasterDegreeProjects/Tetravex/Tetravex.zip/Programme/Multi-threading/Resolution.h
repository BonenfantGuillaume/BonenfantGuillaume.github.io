#include <iostream>
using namespace std;

class Resolution
{
	private:
		int longueur;
		int largeur;
		bool solutionTrouvee;
		Puzzle puzzle;
		Puzzle victoryPuzzle;
		bool placementTuile(int);
		bool placementTuilePourThread(int, Puzzle& , int**);
	public:
		Resolution(Puzzle puzzleCopy);
		bool resoudre();
		void affichage();
};
