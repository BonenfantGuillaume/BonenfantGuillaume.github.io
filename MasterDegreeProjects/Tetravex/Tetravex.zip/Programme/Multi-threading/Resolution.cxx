#include <iostream>
#include <thread>
#include <vector>
#include "Tuile.h"
#include "Puzzle.h"
#include "Resolution.h"

using namespace std;

Resolution::Resolution(Puzzle puzzleCopy) //création d'un objet pour résoudre le puzzle
{
	this->puzzle = puzzleCopy; //puzzle de départ contenant toutes les tuiles
	Puzzle puzzleTemp(this->puzzle.getLongueur(), this->puzzle.getLargeur());
	this->victoryPuzzle = puzzleTemp; //puzzle que l'on remplie petit à petit jusqu'à arriver à la solution
	this->longueur = this->victoryPuzzle.getLongueur();
	this->largeur = this->victoryPuzzle.getLargeur();
	this->solutionTrouvee = false; //s'il existe une solution pour le puzzle
}

bool Resolution::placementTuilePourThread(int numero, Puzzle& victoryPuzzleCopy, int** tuilesUtilisees) //méthode de recherche de solution
{
	if (numero < this->longueur * this->largeur) //si nous n'avons pas encore placé la dernière tuile
	{
		if (this->solutionTrouvee) //si un autre thread a déjà trouvé une solution
		{
			return false; //return false pour finir l'exécution de ce thread plus rapidement
		}
		for (int i = 0; i < this->longueur; i++)
		{
			for (int j = 0; j < this->largeur; j++)
			{
				if (tuilesUtilisees[i][j] == 0) //si la tuile n'est pas déjà placée
				{
					Tuile tuileAPlacer = this->puzzle.getTuile(i, j); //récupération de la tuile à placer
					if ((numero < this->longueur || tuileAPlacer.getHaut() == victoryPuzzleCopy.getTuile(numero-this->longueur).getBas()) && (numero%this->largeur == 0 || tuileAPlacer.getGauche() == victoryPuzzleCopy.getTuile(numero-1).getDroite())) //si l'endroit où l'on veut placer la pièce est tout en haut ou que la valeur haute de la tuile correspond à la valeur basse de la tuile du dessus ET que l'endroit où l'on veut placer la tuile est tout à gauche ou que la valeur gauche de la tuile à placer correspond à la valeur droite de la tuile située à gauche
					{
						victoryPuzzleCopy.addTuile(numero/this->longueur, numero%this->largeur, this->puzzle.getTuile(i*this->puzzle.getLongueur() + j)); //on ajoute la tuile
						tuilesUtilisees[i][j] = 1; //la tuile est mise comme placée
						
						if (this->placementTuilePourThread(numero + 1, victoryPuzzleCopy, tuilesUtilisees)) //s'il existe une solution avec cette tuile de placée (appel récursif qui va essayer de placer toutes les tuiles suivantes. Si cela est possible, la valeur sera alors true)
						{
							return true; //solution trouvée
						}
						tuilesUtilisees[i][j] = 0; //si solution non trouvée, on remet la pièce comme non placée et on essaie de chercher une autre tuile solution
					}
				}
			}
		}
		
		return false; //aucune solution trouvée en essayant toutes les tuiles donc on renvoie false
	}
	else //si la dernière tuile est placée
	{
		cout << "Solution trouvée : " << endl;
		victoryPuzzleCopy.affichage(); //affichage du puzzle solution
		return true; //solution trouvée
	}
	
	return false;
}

bool Resolution::placementTuile(int numero) //pour threader notre recherche de solution
{
	if (numero == 0)
	{
		vector<thread> threads;
		for (int i = 0; i < this->longueur; i++)
		{
			for (int j = 0; j < this->largeur; j++)
			{
				Puzzle victoryPuzzleCopy = this->victoryPuzzle; //on crée un nouveau puzzle vide
				
				auto premiereTuile = [&, i, j](Puzzle victoryPuzzleCopyOfThread){ //exécution d'un thread
					victoryPuzzleCopyOfThread.addTuile(0, 0, puzzle.getTuile(i, j)); //on ajoute la premiere tuile au puzzle vide
					
					int** tuilesUtilisees = new int* [this->longueur]; //matrice de int pour savoir si une tuile est placée (0 si pas placée, 1 si placée)
					for (int i = 0; i < this->longueur; i++)
					{
						tuilesUtilisees[i] = new int [this->largeur];
						for (int j = 0; j < this->largeur; j++)
						{
							tuilesUtilisees[i][j] = 0;
						}
					}
					
					if (placementTuilePourThread(1, victoryPuzzleCopyOfThread, tuilesUtilisees)) //s'il existe une solution avec cette première tuile de déjà placée
					{
						cout << "Une solution trouvée !" << endl;
						victoryPuzzle = victoryPuzzleCopyOfThread; //récupération du puzzle solution
						solutionTrouvee = true; //solution trouvée
					}
				};
				
				thread t(premiereTuile, victoryPuzzleCopy); //création d'un thread
				threads.push_back(move(t)); //ajout du thread au vecteur de threads
			}
		}
		for (thread &t : threads) //on attend que tous les threads s'exécutent
		{
			t.join();
		}
	}
	
	return this->solutionTrouvee;
}

bool Resolution::resoudre() //resoudre le puzzle
{
	cout << "début de modification du victoryPuzzle" << endl;
	
	bool puzzleValide = this->placementTuile(0); //pour threader notre recherche de solution
	
	if (puzzleValide) //s'il y a une solution
	{
		cout << "Puzzle valide !" << endl;
	}
	else //s'il n'y a pas de solution
	{
		cout << "Puzzle invalide !" << endl;
	}
	
	return puzzleValide;
}

void Resolution::affichage() //affichage du puzzle solution
{
	this->victoryPuzzle.affichage();
}
