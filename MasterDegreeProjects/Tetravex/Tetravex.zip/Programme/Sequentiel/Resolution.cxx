#include <iostream>
#include "Tuile.h"
#include "Puzzle.h"
#include "Resolution.h"

using namespace std;

Resolution::Resolution(Puzzle puzzleCopy) //création d'un objet pour résoudre le puzzle
{
	this->puzzle = puzzleCopy; //puzzle de départ contenant toutes les tuiles
	Puzzle puzzleTemp(this->puzzle.getLongueur(), this->puzzle.getLargeur());
	this->victoryPuzzle = puzzleTemp; //puzzle que l'on remplie petit à petit jusqu'à arriver à la solution
	this->longueur = this->victoryPuzzle.getLongueur();
	this->largeur = this->victoryPuzzle.getLargeur();
	
	this->tuilesUtilisees = new int* [this->longueur];
	for (int i = 0; i < this->longueur; i++)
	{
		this->tuilesUtilisees[i] = new int [this->largeur];
		for (int j = 0; j < this->largeur; j++)
		{
			this->tuilesUtilisees[i][j] = 0;
		}
	}
}


bool Resolution::placementTuile(int numero) //méthode de recherche de solution
{
	if (numero < this->longueur * this->largeur) //si nous n'avons pas encore placé la dernière tuile
	{
		for (int i = 0; i < this->longueur; i++)
		{
			for (int j = 0; j < this->largeur; j++)
			{
				if (this->tuilesUtilisees[i][j] == 0) //si la tuile n'est pas déjà placée
				{
					Tuile tuileAPlacer = this->puzzle.getTuile(i, j); //récupération de la tuile à placer
					if ((numero < this->longueur || tuileAPlacer.getHaut() == this->victoryPuzzle.getTuile(numero-this->longueur).getBas()) && (numero%this->largeur == 0 || tuileAPlacer.getGauche() == this->victoryPuzzle.getTuile(numero-1).getDroite())) //si l'endroit où l'on veut placer la pièce est tout en haut ou que la valeur haute de la tuile correspond à la valeur basse de la tuile du dessus ET que l'endroit où l'on veut placer la tuile est tout à gauche ou que la valeur gauche de la tuile à placer correspond à la valeur droite de la tuile située à gauche
					{
						this->victoryPuzzle.addTuile(numero/this->longueur, numero%this->largeur, this->puzzle.getTuile(i*this->puzzle.getLongueur() + j)); //on ajoute la tuile
						this->tuilesUtilisees[i][j] = 1; //la tuile est mise comme placée
						
						if (this->placementTuile(numero + 1)) //s'il existe une solution avec cette tuile de placée (appel récursif qui va essayer de placer toutes les tuiles suivantes. Si cela est possible, la valeur sera alors true)
						{
							return true; //solution trouvée
						}
						this->tuilesUtilisees[i][j] = 0; //si solution non trouvée, on remet la tuile comme non placée et on essaie de chercher une autre tuile solution
					}
				}
			}
		}
		
		return false; //aucune solution trouvée en essayant toutes les tuiles donc on renvoie false
	}
	else //si la dernière tuile est placée
	{
		return true; //solution trouvée
	}
	
	return false;
}

bool Resolution::resoudre() //resoudre le puzzle
{
	cout << "début de modification du victoryPuzzle" << endl;
	
	bool puzzleValide = this->placementTuile(0); //pour threader notre recherche de solution
	
	if (puzzleValide) //s'il y a une solution
	{
		cout << "Puzzle valide !" << endl;
	}
	else //s'il n'y a pas de solution
	{
		cout << "Puzzle invalide !" << endl;
	}
	
	return puzzleValide;
}

void Resolution::affichage() //affichage du puzzle solution
{
	this->victoryPuzzle.affichage();
}
