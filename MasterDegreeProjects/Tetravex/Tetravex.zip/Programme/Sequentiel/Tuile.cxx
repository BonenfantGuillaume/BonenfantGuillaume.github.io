#include <iostream>
#include "Tuile.h"
#include "Puzzle.h"
#include "Resolution.h"

using namespace std;

Tuile::Tuile(int g_copy, int h_copy, int d_copy, int b_copy) //création d'une tuile
{
	cout << "création d'une tuile" << endl;
	
	this->gauche = g_copy;
	this->haut = h_copy;
	this->droite = d_copy;
	this->bas = b_copy;
}
		
Tuile::Tuile() //constructeur vide fait pour les tableaux et matrices de tuiles
{
	//cout << "création d'une tuile vide" << endl;
}

void Tuile::affichage() //affichage d'une tuile
{
	cout << "affichage de la tuile" << endl;
	
	cout << "cote gauche : " << this->gauche << endl;
	cout << "cote haut : " << this->haut << endl;
	cout << "cote droit : " << this->droite << endl;
	cout << "cote bas : " << this->bas << endl;
}

int Tuile::getGauche()
{
	return this->gauche;
}
		
int Tuile::getHaut()
{
	return this->haut;
}
		
int Tuile::getDroite()
{
	return this->droite;
}
		
int Tuile::getBas()
{
	return this->bas;
}
