#include <iostream>
#include <thread>
#include <fstream>
#include "Tuile.h"
#include "Puzzle.h"
#include "Resolution.h"

using namespace std;

int main(int argc, char **argv)
{
	string nomFichier = "7x7.txt"; //fichier que l'on récupère
	if (argv[1] != NULL)
	{
		nomFichier = argv[1];
	}
	ifstream fichier (nomFichier);

	Tuile** tableauTuiles; //matrice de tuiles

	string ligne;
	int longueur, largeur;
	int gauche, haut, droite, bas;

	if (fichier.is_open()) //si le fichier s'ouvre correctement
	{
		fichier >> longueur >> largeur; //la première ligne correspond à la longueur et largeur du puzzle
		tableauTuiles = new Tuile * [longueur];
		
		int i = 0;
		int j = 0;
		while (fichier >> gauche >> haut >> droite >> bas) //chaque ligne possède une case gauche, haute, droite, basse, représentant une tuile
		{
			if (j == 0)
			{
				tableauTuiles[i] = new Tuile [largeur];
			}
			tableauTuiles[i][j] = Tuile(gauche, haut, droite, bas); //on crée notre tuile avec les bonnes données
			j++;
			
			if (j == largeur) //si on est arrivé au bout du puzzle en largeur
			{
				i++;
				j = 0;
			}
			
			if (i >= longueur) //si on est arrivé au bout du puzzle en longueur
			{
				break;
			}
		}
		fichier.close(); //on ferme le fichier
	}
	else //s'il y a un probleme d'ouverture du fichier
	{
		cout << "Unable to open file"; 
	}
	
	Puzzle puzzle(longueur, largeur, tableauTuiles); //on crée notre puzzle
	cout << "affichage du puzzle de départ" << endl;
	puzzle.affichage();
	
	Resolution resolution(puzzle); //on crée notre objet qui va résoudre le puzzle
	bool puzzleValide = resolution.resoudre(); //s'il y a une solution, le puzzle est valide
	if (puzzleValide) //s'il y a une solution au puzzle
	{
		cout << "affichage du puzzle résolu" << endl;
		resolution.affichage(); //afichage de la solution
	}
	else
	{
		cout << "solution non trouvée !" << endl;
	}
	return 0;
}
