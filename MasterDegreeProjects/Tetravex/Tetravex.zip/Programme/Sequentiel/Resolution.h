#include <iostream>
using namespace std;

class Resolution
{
	private:
		int longueur;
		int largeur;
		Puzzle puzzle;
		Puzzle victoryPuzzle;
		int** tuilesUtilisees;
		bool placementTuile(int);
	public:
		Resolution(Puzzle puzzleCopy);
		bool resoudre();
		void affichage();
};
