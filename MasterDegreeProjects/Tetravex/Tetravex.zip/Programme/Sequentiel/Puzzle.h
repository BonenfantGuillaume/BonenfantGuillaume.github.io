#include <iostream>

using namespace std;

class Puzzle
{
	private: 
		Tuile** puzzle = NULL;
		int longueur;
		int largeur;
	public:
		Puzzle(int longueur_copy, int largeur_copy, Tuile** tuiles);
		Puzzle();
		Puzzle(int longueurCopy, int largeurCopy);
		Tuile getTuile(int numeroTuile);
		Tuile getTuile(int i, int j);
		void setTuile(int numeroTuile, Tuile tuileCopy);
		void addTuile(int i, int j, Tuile tuileCopy);
		void affichage();
		int getLongueur();
		int getLargeur();
};
