import React, {useRef} from 'react'
import {Scatter, Bar, Radar, getElementsAtEvent, getElementAtEvent} from 'react-chartjs-2';
import {useState} from "react";
import "./Chart.css"

import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    RadialLinearScale,
    BarElement,
    Title,
    PointElement,
    LineElement,
    Tooltip,
    Legend,
} from 'chart.js';

ChartJS.register(LinearScale, RadialLinearScale, CategoryScale,BarElement, PointElement, LineElement, Title, Tooltip, Legend);


//colors to use for the datasets
let colors = ['red', 'blue', 'yellow', 'purple', 'green', 'orange', 'pink', 'gray', 'black', 'maroon', 'fuchsia', 'lime', 'navy', 'aqua', 'bisque', 'chartreuse', 'chocolate', 'gold', 'indigo', 'olive', 'orangered', 'palevioletred']
let pointGroup = [] //each point is linked to a group. key: index; value: group;   Used to find the good dataset to add data
let labels = [] //labels for scatter chart
let maximums = [] //maximum values for each numeric attribute
let minimums = [] //minimum values for each numeric attribute


//SCATTER CHART
export let optionsForScatter = {
    scales: {
        y: {
            title: {
            },
        },
        x: {
            title: {
            },
        },
    },
    plugins: {
        tooltip: {
            callbacks: {
                label: function(context) {
                    let toReturn = "maker : " + context.raw.maker + "; car : " + context.raw.id
                    //let toReturn = "maker : " + context.raw.maker + "; fuel-type : " + context.raw.fuelType + "; doors number : " + context.raw.doorsNum + "; cylinders number : " + context.raw.cylindersNum
                    return toReturn;
                },
                title: function(context) {
                    return "x: " + context[0].parsed.x + "; y: " + context[0].parsed.y;
                }
            }
        }
    },
    maintainAspectRatio: false,
};

export let dataForScatter = {
    datasets: [
        {
            label: 'A dataset',
            data: [],
            backgroundColor: "Red",
            borderColor: "Red"
        },
    ],
};

//index of the attributes used
let indexX = 0
let indexY = 1



//BAR CHART
const optionsBar = {
    responsive: true,
    plugins: {
        legend: {
            display: false
        },
        title: {
            display: true,
        }
    },
    maintainAspectRatio: false,
};

export const dataBar = {
    labels,
    datasets: [
        {
            data: [],
            backgroundColor: colors,
        },
    ],
};

let attribute = 0 //index of the attribute used
let redAndBlue = false //if we are doing preattentive process



//RADAR CHART
const optionsRadar = {
    maintainAspectRatio: false,
};

export const dataRadar = {
    labels: [],
    datasets: [],
};

let starInitialized = false //if the star chart is initialized
let starWithValues = false //if at least 1 value of the chart is initialized

function Chart(props) {
    const chartRef = useRef(); //Used to find which bar is being clicked on on the chart
    const chartRefScatter = useRef(); //Used to find which point is being clicked on on the chart
    const [name, setName] = useState(0); //value used to rerender the component
    const [tempColors, setTempColors] = useState([]) //colors for preattentive process


    //updating scatter chart
    function updateDataScatter() {
        dataForScatter.datasets = []
        optionsForScatter.scales.x.title.text = props.scatterData[indexX][0] //name of the X attribute
        optionsForScatter.scales.x.title.display = true
        optionsForScatter.scales.y.title.text = props.scatterData[indexY][0] //name of the Y attribute
        optionsForScatter.scales.y.title.display = true


        //we create a dataset for each group in the bar chart
        for (let i = 0; i < labels.length; i++)
        {
            dataForScatter.datasets.push(
                {
                    label: labels[i],
                    data: [],
                    backgroundColor: colors[i],
                    borderColor: colors[i]
                }
            )
        }

        if(redAndBlue) //if we are in preattentive process mode we use these colors
        {
            for (let i = 0; i < labels.length; i++)
            {
                dataForScatter.datasets[i].backgroundColor = tempColors[i]
                dataForScatter.datasets[i].borderColor = tempColors[i]
            }
        }

        //adding data to the datasets if they have no "?" value
        for (let i = 1; i < props.scatterData[indexX].length-1; i++) {
            if (props.scatterData[indexX][i] !== "?" && props.scatterData[indexY][i] !== "?")
            {
                dataForScatter.datasets[pointGroup[i-1]].data.push({
                    x: props.scatterData[indexX][i],
                    y: props.scatterData[indexY][i],
                    id: i,
                    pointGroup: pointGroup[i-1],
                    maker: props.textData[0][i],
                    fuelType: props.textData[1][i],
                    doorsNum: props.textData[3][i],
                    cylindersNum: props.textData[8][i]
                })
            }
        }

        setName(name + 1) //rerendering the component
    }

    //update bar chart
    function updateDataBar(){
        let tempData = []
        labels = [] //group labels
        pointGroup = []
        for (let i = 1; i < props.textData[attribute].length-1; i++) {
            let cpt = 0
            let found = false
            //if the label of the new value is not in the group labels yet, we add the value to the group labels
            for (let label of labels)
            {
                if(label === props.textData[attribute][i])
                {
                    found = true
                    break
                }
                cpt += 1
            }
            if(!found)
            {
                labels.push(props.textData[attribute][i])
                tempData.push(0)
            }
            //we add 1 to the group that has this value (data numbers)
            tempData[cpt]+=1
            pointGroup.push(cpt) //we fill the pointGroup list so we can link each point to a group
        }

        dataBar.labels = labels
        dataBar.datasets[0].data = tempData
        dataBar.datasets[0].backgroundColor = colors
        redAndBlue = false //not in preattentive process anymore (reload bar chart)
        updateDataScatter() //updating scatter chart according to the changes
        updateStarColors() //updating star chart according to the changes
    }

    //update all charts (bar chart is enough actually)
    function updateAllCharts(){
        updateDataBar()
    }

    return (
        <div className="mainPage">
            <div className="firstChart">
                <div>
                    {/* Y axis select */}
                    <select className="selectY">
                        <option>Y axis attribute</option>
                        {props.scatterData.map(datum =>
                            <option key={datum[0]} value={datum[0]} onClick={(event) => selectChange(props.scatterData, datum[0], false, "scatter")}>
                                {datum[0]}
                            </option>
                        )}
                    </select>
                    <button className="reload" onClick={updateAllCharts}>Load data</button>
                </div>
                <div style={{width: "100%", height: "85%"}}>
                    {/* scatter chart */}
                    <Scatter ref={chartRefScatter} options={optionsForScatter} data={dataForScatter} key={Math.random()} onClick={(event) => starChart(event)}/>
                </div>
                <div>
                    {/* X axis select */}
                    <select className="selectX">
                        <option>X axis attribute</option>
                        {props.scatterData.map(datum =>
                            <option key={datum[0]} value={datum[0]} onClick={(event) => selectChange(props.scatterData, datum[0], true, "scatter")} >
                                {datum[0]}
                            </option>
                        )}
                    </select>
                </div>
                <div className="starChart" style={{display: starWithValues !== false ? ("initial") : ("none")}}>
                    {/* star chart and its reset data button */}
                    <button style={{position: "absolute", left: "41%"}} onClick={resetStarChart}>Reset data</button>
                    <div style={{height: "85%"}}>
                        <Radar style={{position: "absolute", top: "10%"}} data={dataRadar} options={optionsRadar} key={Math.random()}/>
                    </div>
                </div>
            </div>
            <div className="barChart" style={{position: "relative"}}>
                {/* bar chart and its select */}
                <Bar ref={chartRef} options={optionsBar} data={dataBar} key={Math.random()} onClick={(event) => linkAndBrushing(event)}/>
                <select style={{position: "absolute", top: "0%", left: "47%"}}>
                    <option>Attribute</option>
                    {props.textData.map(datum =>
                        <option key={datum[0]} value={datum[0]}
                                onClick={(event) => selectChange(props.textData, datum[0], true, "bar")}>
                            {datum[0]}
                        </option>
                    )}
                </select>
            </div>
        </div>
    )

    //function for selects changes
    function selectChange(data, datum, index, type){
        let cpt = 0 //counter
        for (const datumOfData of data) //for all data
        {
            if (datumOfData[0] === datum) //if the first data is the same as the selected datum
            {
                if (type === "scatter") //for scatter chart
                {
                    if (index === true)
                    {
                        indexX = cpt //changing X axis' index
                    }
                    else
                    {
                        indexY = cpt //changing Y axis' index
                    }
                    updateDataScatter() //updating scatter chart accordingly
                    break
                }
                else if (type === "bar") //for bar chart
                {
                    attribute = cpt //changing attribute's index
                    redAndBlue = false //not in preattentive mode anymore
                    updateDataBar() //updating bar chart accordingly
                }
            }
            cpt += 1
        }
    }

    //linking and brushing data between charts for preattentive process or not after clicking on bar chart
    function linkAndBrushing(event){
        if (redAndBlue) //if preattentive process is already on
        {
            //setting back colors for every charts
            dataBar.datasets[0].backgroundColor = colors
            for (let i = 0; i < dataForScatter.datasets.length; i++)
            {
                dataForScatter.datasets[i].backgroundColor = colors[i]
                dataForScatter.datasets[i].borderColor = colors[i]
            }
            for (let i = 0; i < dataRadar.datasets.length; i++)
            {
                dataRadar.datasets[i].backgroundColor = colors[pointGroup[dataRadar.datasets[i].label.replace("car ", "") - 1]]
                dataRadar.datasets[i].borderColor = colors[pointGroup[dataRadar.datasets[i].label.replace("car ", "") - 1]]
            }
            redAndBlue = false //turning prattentive process off
        }
        else
        {
            let temp = [] //colors order list
            for (let i = 0; i < dataBar.datasets[0].data.length; i++) //adding red colors for every indexes
            {
                temp.push(("red"))
            }
            temp[getElementsAtEvent(chartRef.current, event)[0].index] = "blue" //replacing red color for blue one at the selected index

            //setting charts preattentive colors
            dataBar.datasets[0].backgroundColor = temp
            for (let i = 0; i < dataForScatter.datasets.length; i++)
            {
                dataForScatter.datasets[i].backgroundColor = temp[i]
                dataForScatter.datasets[i].borderColor = temp[i]
            }
            setTempColors(temp) //setting the new preattentive colors globally

            //for every dataset in the radar chart, we look for the point in the scatter chart with the same id
            //and we set the radar's dataset's color to the same as the scatter chart's one
            for (let i = 0; i < dataRadar.datasets.length; i++)
            {
                for (let j = 0; j < dataForScatter.datasets.length; j++)
                {
                    for (let k = 0; k < dataForScatter.datasets[j].data.length; k++)
                    {
                        if (parseInt(dataRadar.datasets[i].label.replace("car ", "")) === parseInt(dataForScatter.datasets[j].data[k].id))
                        {
                            dataRadar.datasets[i].backgroundColor = dataForScatter.datasets[j].backgroundColor
                            dataRadar.datasets[i].borderColor = dataForScatter.datasets[j].borderColor
                            break
                        }
                    }
                }
            }

            redAndBlue = true //turning preattentive process on
        }
        setName(name + 1) //rerendering the component
    }

    //function to fill star chart
    function starChart(event){
        if(!starInitialized) //if the chart is not yet initialized
        {
            //computing the minimum and maximum values for each attribute
            for (let i = 0; i < props.scatterData.length; i++)
            {
                let max = 0
                let min = 9999999
                for (let j = 1; j < props.scatterData[i].length; j++)
                {
                    if (parseFloat(props.scatterData[i][j]) > parseFloat(max) && props.scatterData[i][j] !== "?")
                    {
                        max = parseFloat(props.scatterData[i][j])
                    }
                    if (parseFloat(props.scatterData[i][j]) < parseFloat(min) && props.scatterData[i][j] !== "?")
                    {
                        min = parseFloat(props.scatterData[i][j])
                    }
                }
                maximums.push(parseFloat(max))
                minimums.push(parseFloat(min))
                dataRadar.labels.push(props.scatterData[i][0]) //giving the labels its names
            }
            starInitialized = true //now initialized
        }

        const pointId = getElementAtEvent(chartRefScatter.current, event)[0].element.$context.raw.id //id from the selected data in the scatter chart

        //searching for an already existing dataset with the same id
        let doOrNot = true
        for (let i = 0; i < dataRadar.datasets.length; i++)
        {
            if (parseInt(dataRadar.datasets[i].label.replace("car ", "")) === parseInt(pointId))
            {
                doOrNot = false
            }
        }

        if (doOrNot) //adding the dataset only if not already existing
        {
            const grp = getElementAtEvent(chartRefScatter.current, event)[0].element.$context.raw.pointGroup //pointGroup from the selected data in the scatter chart
            //adding a new dataset to the star chart
            dataRadar.datasets.push({
                label: "car " + pointId,
                data: [],
                backgroundColor: colors[grp],
                borderColor: colors[grp],
            })

            //normalizing the attributes' values and adding them to the dataset. The maximum value of an attribute will be 10. Minimum 0.
            let value = parseFloat(props.scatterData[0][pointId])
            value = (value + 2) * 2 //putting risk-factor on a positive value and normalizing it
            dataRadar.datasets[dataRadar.datasets.length - 1].data.push(value)
            for (let i = 1; i < props.scatterData.length; i++)
            {
                value = parseFloat(props.scatterData[i][pointId])
                value = ((value - minimums[i]) * 10 / (maximums[i] - minimums[i]))
                dataRadar.datasets[dataRadar.datasets.length - 1].data.push(value)
            }

            starWithValues = true //values now set
        }
        setName(name + 1) //rerendering the component
    }

    //updating colors when changing of groups
    function updateStarColors() {
        for (let i = 0; i < dataRadar.datasets.length; i++)
        {
            dataRadar.datasets[i].backgroundColor = colors[pointGroup[dataRadar.datasets[i].label.replace("car ", "") - 1]]
            dataRadar.datasets[i].borderColor = colors[pointGroup[dataRadar.datasets[i].label.replace("car ", "") - 1]]
        }
    }

    //reseting the star chart
    function resetStarChart() {
        dataRadar.datasets = []
        starWithValues = false //values now unset
        setName(name + 1) //rerendering the component
    }
}


export default Chart