import './App.css';
import Chart from './components/Chart'
import {useState} from 'react';


let contents = ""
let tempData = []
let tempTextData = []


function App() {
    const [scatterData, setScatterData] = useState([]);
    const [textData, setTextData] = useState([]);

    function readSingleFile(e) {
        var file = e.target.files[0];
        if (!file) {
            return;
        }
        var reader = new FileReader();
        reader.onload = function(e) {
            contents = e.target.result;
            loadData(contents);
        };
        reader.readAsText(file);
    }

    function loadData(contents) {
        const lines = contents.split("\n")
        for (let i = 0; i < 16; i++)
        {
            tempData.push([])
        }
        for (let i = 0; i < 10; i++)
        {
            tempTextData.push([])
        }

        for (const line of lines)
        {
            const data = line.split(",")

            tempData[0].push(data[0])
            tempData[1].push(data[1])
            tempData[2].push(data[9])
            tempData[3].push(data[10])
            tempData[4].push(data[11])
            tempData[5].push(data[12])
            tempData[6].push(data[13])
            tempData[7].push(data[16])
            tempData[8].push(data[18])
            tempData[9].push(data[19])
            tempData[10].push(data[20])
            tempData[11].push(data[21])
            tempData[12].push(data[22])
            tempData[13].push(data[23])
            tempData[14].push(data[24])
            tempData[15].push(data[25])

            tempTextData[0].push(data[2])
            tempTextData[1].push(data[3])
            tempTextData[2].push(data[4])
            tempTextData[3].push(data[5])
            tempTextData[4].push(data[6])
            tempTextData[5].push(data[7])
            tempTextData[6].push(data[8])
            tempTextData[7].push(data[14])
            tempTextData[8].push(data[15])
            tempTextData[9].push(data[17])
        }

        setScatterData(tempData)
        setTextData(tempTextData)
    }

  return (
    <div>
        <input type="file" id="file-input" onChange={readSingleFile} />
      <Chart scatterData={scatterData} textData={textData}></Chart>
    </div>
  );
}


export default App;
