Before lunching the app : download Node.js (npm and npx so you can run the commands below)

everything to run the project :
	- in command line, go to a folder of your choice
	- enter the commands : 
		* npx create-react-app my-app
		* cd my-app
		* npm install --save chart.js react-chartjs-2
	- copy paste the "App.js" file and "components" folder from the "Code" folder of this .zip into the src directory of the created projet (here, my-app)
	- enter the command : npm start
	- Test the program !


Once the website loaded, you have first to select the "cars.csv" file using the upper left button of the website and then press "Load data".
Then you can start use it freely, enjoy !