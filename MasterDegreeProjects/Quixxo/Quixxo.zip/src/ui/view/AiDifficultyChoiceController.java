package ui.view;

import javafx.fxml.FXML;
import ui.MainApp;

public class AiDifficultyChoiceController {

    private MainApp mainApp;

    public void setMainApp(MainApp mainApp)
    {
        this.mainApp = mainApp;
    }

    //On charge la page de jeu pour jouer contre l'IA facile
    @FXML
    public void playAgainstAIEasy() {	mainApp.showGameView(1, 0, 0);	}

    //On charge la page de jeu pour jouer conter l'IA difficile
    @FXML
    public void playAgainstAIHard() {	mainApp.showGameView(2, 0, 0);	}

    @FXML
    public void homepage() //On charge la page d'accueil
    {
        mainApp.showHomepageView();
    }
}
