package ui.view;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

import javafx.scene.layout.BorderPane;

import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.util.Duration;
import ui.MainApp;
import ui.model.Ai;
import ui.model.Board;
import ui.model.GameModel;
import ui.model.Piece;

import java.util.ArrayList;

public class GameController {
	private MainApp mainApp;

	private int depthAI; //si la partie est jouée avec une IA

	private int winner = 0; //gagnant de la partie

	//Nombre de victoire des différents joueurs
	private int playerOneVictoryNumber;
	private int playerTwoVictoryNumber;

	//Experience des différents joueurs
	private int playerOneLevel;
	private int playerTwoLevel;


	@FXML
	private GridPane gridPane; //GridPane contenant toutes les BorderPanes du jeu (une BorderPane représente une case)

	//Texte d'affichage des statistiques joueurs
	@FXML
	private Text playerOne;
	@FXML
	private Text levelPlayerOne;
	@FXML
	private Text victoriesPlayerOne;
	@FXML
	private Text playerTwo;
	@FXML
	private Text LevelPlayerTwo;
	@FXML
	private Text victoriesPlayerTwo;
	@FXML
	private ProgressBar experienceOne;
	@FXML
	private ProgressBar experienceTwo;

	//affichage gagnant
	@FXML
	private Text descriptiveText;
	@FXML
	private Text descriptiveText2;

	private GameModel gameModel;


	public void setMainApp(MainApp mainApp, int depthAICopy, int playerOneVictoryNumberCopy, int playerTwoVictoryNumberCopy)
	{
		this.mainApp = mainApp;

		this.depthAI = depthAICopy;

		//On affiche le nombre de victoires pour chaque joueur
		this.playerOneVictoryNumber = playerOneVictoryNumberCopy;
		this.playerTwoVictoryNumber = playerTwoVictoryNumberCopy;
		this.victoriesPlayerOne.setText("Victoire(s) : " + this.playerOneVictoryNumber);
		this.victoriesPlayerTwo.setText("Victoire(s) : " + this.playerTwoVictoryNumber);

		//On calcule et affiche le niveau de chaque joueur
		this.playerOneLevel = 1;
		this.playerTwoLevel = 1;
		double playerOneExperience = 1;
		double playerTwoExperience = 1;
		for (int i = 1; i <= this.playerOneVictoryNumber; i++)
		{
			playerOneExperience += ((double) 1/(double) this.playerOneLevel);
			this.playerOneLevel = (int) playerOneExperience;
		}
		for (int i = 1; i <= this.playerTwoVictoryNumber; i++)
		{
			playerTwoExperience += ((double) 1/(double) this.playerTwoLevel);
			this.playerTwoLevel = (int) playerTwoExperience;
		}
		this.levelPlayerOne.setText("Niveau : " + this.playerOneLevel);
		this.LevelPlayerTwo.setText("Niveau : " + this.playerTwoLevel);

		//On calcul le progrès de la barre de progrès pour prendre un niveau pour les deux joueurs
		this.experienceOne.setProgress(playerOneExperience - (int) playerOneExperience);
		this.experienceTwo.setProgress(playerTwoExperience - (int) playerTwoExperience);

		int boardSize = 5; // taille du plateau

		ArrayList<ArrayList<BorderPane>> allBorderPanes = new ArrayList<ArrayList<BorderPane>>(); //ArrayList qui contient toutes les borderPanes de la gridPane
		for (int i = 0; i < boardSize; i++)
		{
			allBorderPanes.add(new ArrayList<BorderPane>());
			for (int j = 0; j < boardSize; j++)
			{
				allBorderPanes.get(i).add((BorderPane) gridPane.getChildren().get(i*5 + j)); //On récupère toutes les borderPanes pour les mettre dans "Piece"
			}
		}

		gameModel = new GameModel(this.depthAI, boardSize, allBorderPanes); //Création du modèle
	}

	@FXML
	public void homepage() //Lorsque le bouton retour est cliqué
	{
		mainApp.showHomepageView();
	}

	@FXML
	public void replay() //Lorsque le bouton rejouer est cliqué
	{
		mainApp.showGameView(this.depthAI, this.playerOneVictoryNumber, this.playerTwoVictoryNumber);
	}

	@FXML
	public void actionOnPiece(MouseEvent event) throws InterruptedException //Réception de l'évènement lorsqu'une pièce est cliquée
	{
		if (this.winner == 0) { //Si la partie n'est pas déjà finie
			ArrayList<Piece> winningPieces = new ArrayList<Piece>();

			Board boardTemp = (Board) gameModel.getBoard().clone(); //On copie le plateau (pour ne pas le modifier réellement lorsque les méthodes l'utilisent)
			int pieceId = Integer.valueOf(((BorderPane) event.getSource()).getId()); //On récupère l'ID de la pièce où le joueur a cliqué
			for (int move : gameModel.getPlayerTurn().move(boardTemp, pieceId))
			{
				winningPieces = gameModel.actionOnPiece(move); //On exécute l'action de l'utilisateur. On récupère les cases gagnantes si jamais il y en a après ce coup.
			}

			if (!winningPieces.isEmpty()) { //Si il y a un gagnant
				paint(winningPieces); //On peint les cases gagnantes

				int nbrWinningPiecePlayerOne = 0; //Nombre de cases gagnantes pour le joueur 1
				int nbrWinningPiecePlayerTwo = 0; //Nomber de cases gagnantes pour le joueur 2

				for (Piece piece : winningPieces) {
					if (piece.getPlayerNumber() == 1)
						nbrWinningPiecePlayerOne++; //On récupère le nombre de cases gagnantes du joueur 1
					else if (piece.getPlayerNumber() == 2)
						nbrWinningPiecePlayerTwo++; //On récupère le nombre de cases gagnantes du joueur 2
				}

				if (nbrWinningPiecePlayerOne > nbrWinningPiecePlayerTwo){ //Si le joueur 1 possède plus de cases gagnantes que le joueur 2
					this.winner = 1; //Le gagnant est le joueur 1
					this.playerOneVictoryNumber++;
				}
				else if (nbrWinningPiecePlayerTwo > nbrWinningPiecePlayerOne){ //Si le joueur 2 possède plus de cases gagnantes que le joueur 1
					this.winner = 2; //Le gagnant est le joueur 2
					this.playerTwoVictoryNumber++;
				}
				else //Sinon
					this.winner = 3; //S'il y a égalité
				displayWinner(); //On affiche le gagnant
			}


			else if (this.winner == 0)
			{
				//Affichage du joueur au quel c'est de jouer
				this.descriptiveText.setText("Au tour de");
				this.descriptiveText.setStyle("-fx-fill: " + this.gameModel.getPlayerTurn().getColor());
				this.descriptiveText2.setText("joueur " + this.gameModel.getPlayerTurn().getPlayerNumber());
				this.descriptiveText2.setStyle("-fx-fill: " + this.gameModel.getPlayerTurn().getColor());

				if (this.gameModel.getPlayerTurn().getClass() == new Ai(0, 2).getClass()) //S'il n'y a pas de gagnant et que c'est au tour de l'IA de jouer
				{
					//On exécute un click pour que la fonction soit rappelée et que l'IA joue
					//Le click se fait sur une case au milieu du plateau pour qu'elle n'ait aucun impact sur la suite du jeu
					this.gridPane.getChildren().get(gameModel.getBoard().getBoardSize()+1).fireEvent((new MouseEvent(MouseEvent.MOUSE_CLICKED, 0, 0, 0, 0, MouseButton.PRIMARY, 1, true, true, true, true, true, true, true, true, true, true, null)));
				}
			}
		}
	}

	public void paint(ArrayList<Piece> winningPieces) { //Pour peindre les cases

		ArrayList<Timeline> timelines = new ArrayList<Timeline>(); //ArrayList d'animations à exécuter en séquentiel

		for (Piece piece: winningPieces)
		{
			timelines.add(new Timeline(
					new KeyFrame(Duration.ZERO, new KeyValue(((BorderPane) gridPane.lookup("#" + String.valueOf(piece.getId()))).styleProperty(), "-fx-background-color: rgba(0, 230, 64, 0)")), //On peint les cases en vert transparent
					new KeyFrame(Duration.seconds(1), new KeyValue(((BorderPane) gridPane.lookup("#" + String.valueOf(piece.getId()))).styleProperty(), "-fx-background-color:rgba(0, 230, 64, 0.5)"))) //Puis on rend le vert de plus en plus visible (de moins en moins transparent) transition d'une durée de 1 seconde
			);
		}

		SequentialTransition seqT = new SequentialTransition(); //On définit l'animation comme étant une transition séquentielle
		for (Timeline timeline: timelines) //On rajoute toutes les timelines à la transition séquentielle
		{
			seqT.getChildren().add(timeline);
		}

		seqT.play(); //On exécute l'animation
	}

	public void displayWinner()
	{
		if (this.winner == 1) //Si le gagnant est le premier joueur
		{
			descriptiveText.setText("Félicitations joueur 1,"); //On félicite le premier joueur
			descriptiveText.setStyle("-fx-fill: blue"); //On colorie le texte en bleu
			descriptiveText.setOpacity(1); //On affiche le texte
			descriptiveText2.setText("Vous avez gagné !");
			descriptiveText2.setStyle("-fx-fill: blue");
			descriptiveText2.setOpacity(1);
		}
		else if (this.winner == 2) //Si le gagnant est le deuxième joueur
		{
			descriptiveText.setText("Félicitations joueur 2,"); //On félicite le deuxième joueur
			descriptiveText.setStyle("-fx-fill: red"); //On colorie le texte en rouge
			descriptiveText.setOpacity(1); //On affiche le texte
			descriptiveText2.setText("Vous avez gagné !");
			descriptiveText2.setStyle("-fx-fill: red");
			descriptiveText2.setOpacity(1);
		}
		else if (this.winner == 3) //S'il y a eu égalité
		{
			descriptiveText.setText("Egalite !"); //On prévient de l'égalité
			descriptiveText.setStyle("-fx-fill: gray"); //On affiche le texte en gris
			descriptiveText.setOpacity(1); //On affiche le texte
			descriptiveText2.setOpacity(0);
		}
	}
}
