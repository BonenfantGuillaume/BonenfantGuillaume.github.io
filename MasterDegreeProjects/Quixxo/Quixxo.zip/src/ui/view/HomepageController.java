package ui.view;

import javafx.fxml.FXML;
import ui.MainApp;

public class HomepageController {
	
	private MainApp mainApp;

	public void setMainApp(MainApp mainApp)
	{
		this.mainApp = mainApp; 
	}

	//On charge la page pour choisir le niveau de difficulté de l'IA si on appuie sur le bouton pour
	@FXML
	public void playAgainstAI() {	mainApp.showAiDifficultyChoiceView();	}

	//On charge la page de jeu en mode joueur contre joueur si on appuie sur le bouton pour
	@FXML
	public void playAgainstFriend()
	{
		mainApp.showGameView(0, 0, 0);
	}

}
