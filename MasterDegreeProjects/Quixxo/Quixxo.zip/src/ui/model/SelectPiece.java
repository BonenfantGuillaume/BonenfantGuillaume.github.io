package ui.model;

public class SelectPiece implements Functionality {
    private Piece piece;

    public SelectPiece(Piece pieceCopy)
    {
        this.piece = pieceCopy;
    }

    public void trigger(){
        //On colorie la case pour montrer qu'elle est sélectionnée
        Piece.setSelectedPiece(this.piece); //On sélectionne la case
        this.piece.getBorderPane().setStyle("-fx-background-color: blue");
        this.piece.getBorderPane().setOpacity(0.5);
    }
}
