package ui.model;

import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public class Ai extends PlayerType{
    private int playerNumber; //Numéro du joueur
    private Image image; //Image appartenant au joueur (croix ou cercle)
    private String color; //Couleur du joueur (bleu ou rouge)
    private int depthAI; //Profondeur de l'IA

    public Ai(int playerNumberCopy, int depthAICopy){
        super(playerNumberCopy);
        this.playerNumber = playerNumberCopy; //Numéro du joueur
        this.depthAI = depthAICopy; //Profondeur de l'IA

        //On initialise l'image et la couleur qui vont au joueur
        if (this.playerNumber == 1)
        {
            this.image = new Image(getClass().getResource("../view/images/cross.png").toExternalForm(), 110.0, 110.0, true, true); //le joueur 1 possède les croix
            this.color = "blue";
        }
        else if (this.playerNumber == 2) {
            this.image = new Image(getClass().getResource("../view/images/circle.png").toExternalForm(), 70.0, 70.0, true, true); //l'IA est toujours le joueur 2 donc possède les cercles
            this.color = "red";
        }
    }

    @Override
    public ArrayList<Integer> move(Board board, int pieceId) throws InterruptedException {
        System.out.println("AU TOUR DE L'IA !!");

        int playerPlaying = this.playerNumber; //Joueur qui joue (peut changer lorsque la fonction se fait rappeler (récursivement)
        //Adversaire qui prend la valeur opposé du joueur qui joue
        int opponent = 1;
        if (playerPlaying == 1)
            opponent = 2;

        boolean minMax = true; //MinMax prend la valeur true si on veut maximiser la valeur du joueur ou la miniser (pour l'adversaire)
        if (depthAI%2 == 0) //On minimise si il y a un nombre pair de profondeur (Car nous récupérerons alors les valeurs de l'adversaire que nous voulons minimiser)
            minMax = false;

        ArrayList<Integer> moves = aiMove(board, playerPlaying, opponent, depthAI, true, minMax); //on fait joueur l'IA (elle choisi les deux cases à jouer).

        return moves; //On renvoie les deux coups à jouer pour l'IA (premier coup, elle choisit une case à déplacer. Deuxième coup, elle déplace la case).
    }

    public ArrayList<Integer> aiMove(Board board, int playerPlaying, int opponent, int depthAI, boolean original, boolean minMax) throws InterruptedException //original vaut true si c'est le tout premier appel de la fonction
    {
        //System.out.println("L'IA choisie une case...");

        int minMaxValue = 0;
        if (minMax) //Si on veut maximiser la valeur
            minMaxValue = -99999; //On commence par mettre le maximum très bas
        else //Sinon
            minMaxValue = 99999; //On commence par mettre le maximum très haut

        ArrayList<Integer> moves = new ArrayList<Integer>(); //Les deux clicks cases où appuyer pour jouer

        ArrayList<Piece> sidedPieces = new ArrayList<Piece>(); //ArrayList des pièces déplacables
        //On récupère toutes les pièces déplaçables
        for (ArrayList<Piece> pieceLine: board.getPieces())
        {
            for (Piece piece: pieceLine)
            {
                if (piece.isSided() && piece.getPlayerNumberForAI() != opponent)
                    sidedPieces.add(piece);
            }
        }

        //On crée des threads pour récupérer le meilleur coup possible parmi les différents coups qui suivront chaque premier coup (un thread par premier coup possible (pièce déplaçable))
        //System.out.println("Start Threads");
        CountDownLatch startSignalForSidedPieces = new CountDownLatch(1);
        CountDownLatch doneSignalForSidedPieces = new CountDownLatch(sidedPieces.size()); //Nombre de threads qui doivent finir de s'exécuter avant de continuer

        ArrayList<ThreadsForAiSidedPieces> threadsForSidedPieces = new ArrayList<ThreadsForAiSidedPieces>(); //ArrayList des threads qui vont s'exécuter

        for (Piece sidedPiece: sidedPieces) //Pour chaque pièce déplaçable
        {
            Board boardTempForSidedPieces = (Board) board.clone(); //On copie le plateau (pour ne pas le modifier réellement dans tous les threads en meme temps)
            Piece sidedPieceTemp = (Piece) sidedPiece.clone(); //On copie la pièce également pour que tous les threads ne touchent pas à la même pièce
            ThreadsForAiSidedPieces threadForSidedPieces = new ThreadsForAiSidedPieces(startSignalForSidedPieces, doneSignalForSidedPieces, boardTempForSidedPieces, sidedPieceTemp, playerPlaying, opponent, moves, depthAI, this, original, minMax); //On crée un thread fonctionnant pour les cases déplaçables
            new Thread(threadForSidedPieces).start(); //On crée et lance le thread
            threadsForSidedPieces.add(threadForSidedPieces); //On ajoute le thread à l'Arraylist
        }

        startSignalForSidedPieces.countDown(); //On laisse les thread s'exécuter
        doneSignalForSidedPieces.await(); //On attend que tous les threads aient fini de s'exécuter
        //System.out.println("All threadsForSidedPieces are done");


        if (original) //Si nous sommes bien à la racine de l'arbre (la première instance de la fonction)
        {
            minMaxValue = ThreadsForAiSidedPieces.getBestBoardWorthStatic(); //la valeur minMax prend la meilleure valeur des threads (commune car static)
            //On récupère les coups correspondants à cette valeur
            if (moves.isEmpty())
            {
                moves.add(ThreadsForAiSidedPieces.getMoves().get(0));
                moves.add(ThreadsForAiSidedPieces.getMoves().get(1));
            }
            else
            {
                moves.set(0, ThreadsForAiSidedPieces.getMoves().get(0));
                moves.set(1, ThreadsForAiSidedPieces.getMoves().get(1));
            }
            ThreadsForAiSidedPieces.getMoves().clear(); //On vide La variable statique (très important pour ne pas perturber le prochain appel de thread)
        }
        else //Sinon
        {
            for (ThreadsForAiSidedPieces threadForSidedPieces: threadsForSidedPieces) //Pour chaque thread
            {
                if (minMax) //Si on cherche à maximiser la valeur
                {
                    minMaxValue = Math.max(minMaxValue, threadForSidedPieces.getBestBoardWorthNonStatic()); //On prend la valeur maximale
                }
                else //Sinon
                {
                    minMaxValue = Math.min(minMaxValue, threadForSidedPieces.getWorstBoardWorthNonStatic()); //On prend la valeur minimale
                }
            }
        }

        if (!original) //Si nous ne sommes pas à la racine
        {
            //On renvoie juste la valeur (maximale ou minimale) du coup
            ArrayList<Integer> minMaxArrayList = new ArrayList<Integer>();
            minMaxArrayList.add(minMaxValue);
            return minMaxArrayList;
        }

        System.out.println("Best board worth : " + minMaxValue);
        System.out.println("Best first move : " + moves.get(0));
        System.out.println("Best second move : " + moves.get(1));

        return moves; //On renvoie les deux coups à jouer
    }

    @Override
    public Image getImage() {
        return image;
    }

    @Override
    public String getColor() {
        return color;
    }
}
