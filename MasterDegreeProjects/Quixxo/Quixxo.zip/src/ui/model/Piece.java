package ui.model;

import javafx.scene.layout.BorderPane;
import javafx.scene.image.Image;

public class Piece implements Cloneable{
    private int playerNumber; //une case vaut 0 si elle n'est pas attribuée à un joueur, 1 si au joueur 1, 2 si au joueur 2;
    private int playerNumberForAI; //utilisée pour la simulation d'IA et ne pas influencer le plateau lorsqu'elle joue
    private int id; //id de la case
    private BorderPane borderPane; //BorderPane appartenant à la case
    private boolean sided; //Si la case est située sur le côté du plateau
    private Functionality functionality; //Fonctionnalité de la case
    private static Piece selectedPiece; //Case sélectionnée par l'utilisateur
    private int x; //Positionnement horizontal de la pièce
    private int y; //Positionnement vertical de la pièce
    private Image image = null;

    public Piece(BorderPane borderPaneCopy, int xCopy, int yCopy){
        this.playerNumber = 0; //Initialisation de la case à 0 par défaut
        this.playerNumberForAI = this.playerNumber;
        this.borderPane = borderPaneCopy; //Copie de la BorderPane
        this.id = Integer.parseInt(borderPaneCopy.getId()); //Id de la case équivalent à l'id de la BorderPane
        this.x = xCopy;
        this.y = yCopy;
    }

    public void setFunctionality(Functionality functionalityCopy) //Pour assigner une fonctionnalité à la case
    {
        this.functionality = functionalityCopy;
    }

    public void press() //Lorsque l'utilisateur appuie sur la case
    {
        functionality.trigger(); //On active la fonctionnalité
    }

    public void setPlayerNumber(int playerNumberCopy, Image image) { //La case change de possesseur, on fait alors toutes les modifications nécessaires
        this.playerNumber = playerNumberCopy; //On change le numéro de joueur de la case
        this.playerNumberForAI = this.playerNumber; //On change le numéro de joueur de la case pour que l'IA puisse jouer aussi
        Animations.newMoveAnimation(image, this.borderPane); //On affiche le nouveau possesseur sur la vue
        this.image = image; //On change l'image représentant à qui appartient la case
    }

    public void setPlayerNumberForAI(int playerNumberCopy) //Méthode pour que l'IA puisse jouer sans influencer le vrai plateau
    {
        this.playerNumberForAI = playerNumberCopy;
    }

    public Object clone(){ //Méthode pour cloner une case
        try {
            return super.clone();
        }
        catch (CloneNotSupportedException e){
            throw new InternalError();
        }
    }

    public static void setSelectedPiece(Piece selectedPieceCopy)
    {
        selectedPiece = selectedPieceCopy;
    }

    public static Piece getSelectedPiece()
    {
        return selectedPiece;
    }

    public int getPlayerNumber(){ return this.playerNumber; }

    public int getPlayerNumberForAI() {
        return playerNumberForAI;
    }

    public BorderPane getBorderPane() {
        return borderPane;
    }

    public void setSided(boolean sidedCopy){
        this.sided = sidedCopy;
    }

    public boolean isSided() {
        return sided;
    }

    public int getId() {
        return id;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Image getImage() {
        return image;
    }
}
