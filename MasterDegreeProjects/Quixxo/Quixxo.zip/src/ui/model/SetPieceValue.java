package ui.model;

import javafx.scene.image.Image;

//Fonctionnalité pour préparer une case à changer de valeur
public class SetPieceValue implements Functionality{
    private Piece piece;
    private int playerNumber;
    private Image image;

    //Préparation de la fonctionnalité
    public SetPieceValue(Piece pieceCopy, int playerNumberCopy, Image imageCopy)
    {
        this.piece = pieceCopy;
        this.playerNumber = playerNumberCopy;
        this.image = imageCopy;
    }

    //Activation de la fonctionnalité
    public void trigger(){
        piece.setPlayerNumber(this.playerNumber, this.image);
    }}
