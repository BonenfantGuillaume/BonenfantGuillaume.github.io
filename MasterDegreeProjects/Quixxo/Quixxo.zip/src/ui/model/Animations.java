package ui.model;

import javafx.animation.FadeTransition;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.util.Duration;
import javafx.scene.image.Image;

public class Animations {


    public static void newMoveAnimation(Image image, BorderPane borderPane) //Animation pour poser une croix ou un cercle sur une case
    {
        ImageView imageView = new ImageView(); //Création de l'image
        imageView.setImage(image); //On charge l'image du joueur
        FadeTransition transition = new FadeTransition(Duration.millis(1000), imageView); //On affiche l'image petit à petit
        transition.setFromValue(0); //Au départ l'image est transparente
        transition.setToValue(1); //Puis elle devient de plus en plus claire

        borderPane.setCenter(imageView); //On affiche l'image au milieu de la case
        transition.play(); //On exécute la transition
    }
}
