package ui.model;

public class DeselectPiece implements Functionality{
    private Piece piece;

    public DeselectPiece(Piece pieceCopy)
    {
        this.piece = pieceCopy;
    }

    public void trigger()
    {
        if(Piece.getSelectedPiece() != null) {
            //On enlève l'affichage qui servait à prévenir qu'une case est sélectionnée
            this.piece.getSelectedPiece().getBorderPane().setStyle("-fx-background-color: none");
            this.piece.getSelectedPiece().getBorderPane().setOpacity(1.0);
        }
    }
}
