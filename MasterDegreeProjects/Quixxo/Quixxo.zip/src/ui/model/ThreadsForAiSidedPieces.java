package ui.model;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public class ThreadsForAiSidedPieces implements Runnable{
    private final CountDownLatch startSignal; //Signal pour commencer l'exécution du thread
    private final CountDownLatch doneSignal; //Signal de fin d'exécution de thread (pour décrémenter le compteur)
    private Board board; //Plateau copié
    private Piece sidedPiece; //Pièce copiée
    private int playerPlaying; //Joueur a=qui joue
    private int opponent; //Son adversaire
    private int depthAI; //Profondeur restante de l'IA
    private Ai ai; //Ia (utile pour appeler récursivement la méthode aiMove)
    private static int bestBoardWorthStatic; //Meilleure valeur (pas forcément la plus grande, par exemple quand on veut minimiser on la veut la plus petite possible !)
    private int bestBoardWorthNonStatic; //Meilleure valeur (mais pas statique. Utile pour la récurrence de thread. Cette valeur est locale)
    private int worstBoardWorthNonStatic; //Pire valeur (Utilisée à la place de bestBoardWorthNonStatic quand on cherche à minimiser)
    private static ArrayList<Integer> moves = new ArrayList<Integer>(); //Les deux meilleurs coups pour l'IA. Static pour que tous les threads puissent y avoir accès et la visionner !
    public static Object lockingObject = new Object(); //Objet permettant de synchroniser les threads facilement pour ne pas qu'ils aient accès en même temps aux différentes variables (static par exemple)
    private boolean original; //Si le thread se trouve à la racine de l'arbre
    private boolean minMax; //True si on veut maximiser, false si on veut minimiser

    //Initialisation de toutes les variables
    public ThreadsForAiSidedPieces(CountDownLatch startSignal, CountDownLatch doneSignal, Board boardCopy, Piece sidedPiece, int playerPlayingCopy, int opponentCopy, ArrayList<Integer> movesCopy, int depthAICopy, Ai aiCopy, boolean originalCopy, boolean minMaxCopy) {
        this.startSignal = startSignal;
        this.doneSignal = doneSignal;
        this.board = boardCopy;
        this.sidedPiece = sidedPiece;
        this.playerPlaying = playerPlayingCopy;
        this.opponent = opponentCopy;
        this.depthAI = depthAICopy;
        this.ai = aiCopy;
        this.original = originalCopy;
        this.minMax = minMaxCopy;
        this.bestBoardWorthNonStatic = -999999;
        this.worstBoardWorthNonStatic = 99999;
    }

    //Code exécuté par le thread lorsqu'il est démarré
    public void run() {
        try {
            startSignal.await(); //Attend le signal de lancement
            doWork(); //Code à exécuter
            doneSignal.countDown(); //Une fois le thread fini, on décrémente le nombre de thread qu'il reste à exécuter
        } catch (InterruptedException ex) {
        }
    }

    public void doWork() throws InterruptedException {
        //System.out.println("Sided thread working");

        ArrayList<Piece> movablePieces = new ArrayList<Piece>(); //ArrayList des cases où l'on peut déplacer notre pièce

        //On récupère toutes les cases où l'on peut déplacer notre pièce
        if (board.getPieces().get(sidedPiece.getX()).get(0).getId() != sidedPiece.getId())
        {
            movablePieces.add(board.getPieces().get(sidedPiece.getX()).get(0));
        }
        if (board.getPieces().get(sidedPiece.getX()).get(board.getBoardSize()-1).getId() != sidedPiece.getId())
        {
            movablePieces.add(board.getPieces().get(sidedPiece.getX()).get(board.getBoardSize()-1));
        }
        if (board.getPieces().get(0).get(sidedPiece.getY()).getId() != sidedPiece.getId())
        {
            movablePieces.add(board.getPieces().get(0).get(sidedPiece.getY()));
        }
        if (board.getPieces().get(board.getBoardSize()-1).get(sidedPiece.getY()).getId() != sidedPiece.getId())
        {
            movablePieces.add(board.getPieces().get(board.getBoardSize()-1).get(sidedPiece.getY()));
        }

        //On crée des threads pour récupérer le meilleur coup possible à partir de la première case sélectionnée (sidedPiece)
        //System.out.println("Start Threads");
        CountDownLatch startSignalForMovablePieces = new CountDownLatch(1);
        CountDownLatch doneSignalForMovablePieces = new CountDownLatch(movablePieces.size()); //Nombre de threads qui doivent finir de s'exécuter avant de continuer

        ArrayList<ThreadsForAiMovablePieces> threadsForMovablePieces = new ArrayList<ThreadsForAiMovablePieces>(); //ArrayList des threads qui vont s'exécuter

        for (Piece movedPiece: movablePieces) //Pour chaque endroit où l'on peut déplacer notre pièce
        {
            Board boardTempForMovablePieces = (Board) board.clone(); //On copie le plateau (pour ne pas le modifier réellement dans tous les threads en meme temps)

            //On copie les pièces également pour que tous les threads ne touchent pas aux mêmes pièces
            Piece sidedPieceTemp = (Piece) sidedPiece.clone();
            Piece movedPieceTemp = (Piece) movedPiece.clone();
            ThreadsForAiMovablePieces thread = new ThreadsForAiMovablePieces(startSignalForMovablePieces, doneSignalForMovablePieces, boardTempForMovablePieces, sidedPieceTemp, movedPieceTemp, playerPlaying, opponent, depthAI, ai, minMax); //On crée un thread pour les cases où l'on peut déplacer notre pièce
            new Thread(thread).start(); //On crée et lance le thread
            threadsForMovablePieces.add(thread); //On ajoute le thread à l'ArrayList
        }

        startSignalForMovablePieces.countDown(); //On laisse les thread s'exécuter
        doneSignalForMovablePieces.await(); //On attend que tous les threads aient fini de s'exécuter
        //System.out.println("All threads are done");

        setMovesSynchronized(threadsForMovablePieces); //On récupère toutes ces valeurs de façon sécurisé
    }


    public void setMovesSynchronized(ArrayList<ThreadsForAiMovablePieces> threadsForMovablePieces)
    {
        synchronized (lockingObject) { //On empêche les threads d'accéder à plusieurs à cette fonction en même temps pour qu'il n'y ait pas d'intersection entre les threads (deux threads qui modifient une valeur en meme temps, surtout pour les variables static)
            for (ThreadsForAiMovablePieces thread : threadsForMovablePieces) { //Pour tous les threads créés
                if (moves.isEmpty() && original) { //Si nous sommes à la racine et que le tableau des coups à jouer est vide
                    bestBoardWorthStatic = thread.getNewBoardWorth(); //La meilleur valeur devient celle de ce thread (pour initialiser le tableau de coups)
                    this.bestBoardWorthNonStatic = thread.getNewBoardWorth(); //La meilleur valeur devient celle de ce thread
                    this.worstBoardWorthNonStatic = thread.getNewBoardWorth(); //La pire valeur devient celle de ce thread
                    moves.add(thread.getFirstMove()); //On ajoute le premier coup à jouer par l'IA
                    moves.add(thread.getSecondMove()); //On ajoute le second coup à jouer par l'IA
                }
                else if (!minMax && this.worstBoardWorthNonStatic > thread.getNewBoardWorth()) //Si on cherche à miniser la valeur de l'adversaire et que la pire valeur est plus grande que la pire valeur du thread actuel
                {
                    this.worstBoardWorthNonStatic = thread.getNewBoardWorth(); //la pire valeur (pour l'adversaire) devient la pire valeur de ce thread
                    if (original && bestBoardWorthStatic > thread.getNewBoardWorth()) //Si on est à la racine et que la meilleure valeur trouvée jusqu'ici (static) (ici la pire pour l'adversaire) est plus grande que celle de ce thread
                    {
                        //On modifie les variables static
                        bestBoardWorthStatic = thread.getNewBoardWorth(); //On modifie la meilleure valeur pour celle trouvée par le thread
                        moves.set(0, thread.getFirstMove()); //On modifie le premier coup à jouer
                        moves.set(1, thread.getSecondMove()); //On modifie le deuxième coup à jouer
                    }
                }
                else if (minMax && this.bestBoardWorthNonStatic < thread.getNewBoardWorth()) //Si on cherche à maximiser la valeur de l'IA et que la meilleure valeur (ici la plus grande) est plus petite que la valeur trouvée par le thread actuel
                {
                    this.bestBoardWorthNonStatic = thread.getNewBoardWorth(); //On change la meilleure valeur (locale) par celle de ce thread
                    if(original && bestBoardWorthStatic < thread.getNewBoardWorth()) //Si on est à la racine et que la meilleure valeur trouvée jusqu'ici (static) (ici la plus grande pour l'IA) est plus petite que celle de ce thread
                    {
                        bestBoardWorthStatic = thread.getNewBoardWorth(); //On modifie la meilleure valeur pour celle trouvée par le thread
                        moves.set(0, thread.getFirstMove()); //On modifie le premier coup à jouer
                        moves.set(1, thread.getSecondMove()); //On modifie le deuxième coup à jouer
                    }
                }
            }
        }
    }

    public static ArrayList<Integer> getMoves() {
        return moves;
    }

    public static int getBestBoardWorthStatic() {
        return bestBoardWorthStatic;
    }

    public int getBestBoardWorthNonStatic(){
        return this.bestBoardWorthNonStatic;
    }

    public int getWorstBoardWorthNonStatic(){
        return this.worstBoardWorthNonStatic;
    }
}
