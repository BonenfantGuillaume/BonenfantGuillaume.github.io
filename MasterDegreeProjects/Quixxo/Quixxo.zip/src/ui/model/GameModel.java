package ui.model;

import javafx.scene.layout.BorderPane;

import java.util.ArrayList;
import javafx.scene.image.Image;

public class GameModel {

    //plateau
    private Board board;

    //joueurs
    private PlayerType player1;
    private PlayerType player2;

    private PlayerType playerTurn; //Joueur qui joue
    private PlayerType playerNotTurn; //Joueur qui ne joue pas

    public GameModel(int depthAI, int boardSize, ArrayList<ArrayList<BorderPane>> allBorderPanes)
    {
        //Initialisation du plateau
        board = new Board(boardSize, allBorderPanes);

        //Initialisation des joueurs
        this.player1 = new Human(1);
        if(depthAI == 0)
            this.player2 = new Human(2);
        else
            this.player2 = new Ai(2, depthAI);

        this.playerTurn = player1;
        this.playerNotTurn = player2;

        setAllPiecesFunctionalities(); //on assigne toutes les fonctionnalités aux cases
    }

    public ArrayList<Piece> actionOnPiece(int pieceId) //Lorsqu'une pièce est cliquée
    {
        ArrayList<Piece> winningPieces = new ArrayList<Piece>();
        Piece pressedPiece = this.board.getPiece(pieceId);
        if (pressedPiece.isSided() && (pressedPiece.getPlayerNumber() == this.playerTurn.getPlayerNumber() || pressedPiece.getPlayerNumber() == 0) && Piece.getSelectedPiece() == null) //Si la pièce est située sur le côté et qu'il n'y a aucune pièce déjà sélectionnée
        {
            this.board.press(pieceId); //On exécute l'action assignée à la case

            //On assigne à toutes les cases situées sur le côté la fonctionnalité d'annuler l'affichage de la sélection de la case
            for (ArrayList<Piece> pieceLine: this.board.getPieces())
            {
                for (Piece piece: pieceLine)
                {
                    if(piece.isSided())
                        this.board.setFunctionality(new DeselectPiece(piece), piece.getId());
                }
            }

            //On colorie les cases à l'opposé de celle cliquée et on leur assigne une commande pour les préparer à changer de valeur
            if (this.board.getPieces().get(pressedPiece.getX()).get(0) != pressedPiece)
            {
                this.board.getPieces().get(pressedPiece.getX()).get(0).getBorderPane().setStyle("-fx-background-color: yellow");
                this.board.getPieces().get(pressedPiece.getX()).get(0).getBorderPane().setOpacity(0.5);
                this.board.getPieces().get(pressedPiece.getX()).get(0).setFunctionality(new SetPieceValue(this.board.getPieces().get(pressedPiece.getX()).get(0), this.playerTurn.getPlayerNumber(), this.playerTurn.getImage()));
            }
            if (this.board.getPieces().get(pressedPiece.getX()).get(this.board.getBoardSize()-1) != pressedPiece)
            {
                this.board.getPieces().get(pressedPiece.getX()).get(this.board.getBoardSize()-1).getBorderPane().setStyle("-fx-background-color: yellow");
                this.board.getPieces().get(pressedPiece.getX()).get(this.board.getBoardSize()-1).getBorderPane().setOpacity(0.5);
                this.board.getPieces().get(pressedPiece.getX()).get(this.board.getBoardSize()-1).setFunctionality(new SetPieceValue(this.board.getPieces().get(pressedPiece.getX()).get(this.board.getBoardSize()-1), this.playerTurn.getPlayerNumber(), this.playerTurn.getImage()));
            }
            if (this.board.getPieces().get(0).get(pressedPiece.getY()) != pressedPiece)
            {
                this.board.getPieces().get(0).get(pressedPiece.getY()).getBorderPane().setStyle("-fx-background-color: yellow");
                this.board.getPieces().get(0).get(pressedPiece.getY()).getBorderPane().setOpacity(0.5);
                this.board.getPieces().get(0).get(pressedPiece.getY()).setFunctionality(new SetPieceValue(this.board.getPieces().get(0).get(pressedPiece.getY()), this.playerTurn.getPlayerNumber(), this.playerTurn.getImage()));
            }
            if (this.board.getPieces().get(this.board.getBoardSize()-1).get(pressedPiece.getY()) != pressedPiece)
            {
                this.board.getPieces().get(this.board.getBoardSize()-1).get(pressedPiece.getY()).getBorderPane().setStyle("-fx-background-color: yellow");
                this.board.getPieces().get(this.board.getBoardSize()-1).get(pressedPiece.getY()).getBorderPane().setOpacity(0.5);
                this.board.getPieces().get(this.board.getBoardSize()-1).get(pressedPiece.getY()).setFunctionality(new SetPieceValue(this.board.getPieces().get(this.board.getBoardSize()-1).get(pressedPiece.getY()), this.playerTurn.getPlayerNumber(), this.playerTurn.getImage()));
            }
        }

        //Si la pièce est située sur le côté
        //et qu'il y a déjà une pièce sélectionnée
        //et que la pièce est différente de la pièce sélectionnée
        //et que soit
        //-la pièce et la pièce sélectionnée ont le même positionnement horizontal et que
        //  la pièce est tout à gauche du plateau OU tout à droite du plateau
        //-la pièce et la pièce sélectionnée ont le même positionnement vertical et que
        //  la pièce est tout en haut du plateau OU tout en bas du plateau
        else if (pressedPiece.isSided() && Piece.getSelectedPiece() != null && (pressedPiece != Piece.getSelectedPiece()))
        {
            if (((pressedPiece.getX() == Piece.getSelectedPiece().getX()) && (pressedPiece.getY() == 0 || pressedPiece.getY() == this.board.getBoardSize()-1)))
            {
                //System.out.println("On déplace des cases !");
                if (pressedPiece.getY() > Piece.getSelectedPiece().getY())
                {
                    for (int j = Piece.getSelectedPiece().getY(); j < pressedPiece.getY(); j++) {
                        setPieceValue(pressedPiece.getX() * this.board.getBoardSize() + j, this.board.getPieces().get(pressedPiece.getX()).get(j + 1).getPlayerNumber(), this.board.getPieces().get(pressedPiece.getX()).get(j + 1).getImage()); //on met la case comme ayant été jouée par le joueur en question
                    }
                }
                else
                {
                    for (int j = Piece.getSelectedPiece().getY(); j > pressedPiece.getY(); j--) {
                        setPieceValue(pressedPiece.getX() * this.board.getBoardSize() + j, this.board.getPieces().get(pressedPiece.getX()).get(j - 1).getPlayerNumber(), this.board.getPieces().get(pressedPiece.getX()).get(j - 1).getImage()); //on met la case comme ayant été jouée par le joueur en question
                    }
                }
                //pressedPiece.press(); //Pas nécessaire car "deselect" exécute déjà l'action
                deselect(pieceId); //On exécute la fonctionnalité de la pièce (assigner une nouvelle valeur de joueur à la pièce) et on déselectionne la pièce
                changeTurn(); //On change à quel joueur c'est le tour de jouer
                winningPieces = verifyWinner(); //On récupère les cases gagnantes s'il y en a
            }
            else if ((pressedPiece.getY() == Piece.getSelectedPiece().getY() && (pressedPiece.getX() == 0 || pressedPiece.getX() == this.board.getBoardSize()-1)))
            {
                System.out.println("On déplace des cases !");
                if (pressedPiece.getX() > Piece.getSelectedPiece().getX())
                {
                    for (int i = Piece.getSelectedPiece().getX(); i < pressedPiece.getX(); i++) {
                        setPieceValue(i * this.board.getBoardSize() + pressedPiece.getY(), this.board.getPieces().get(i+1).get(pressedPiece.getY()).getPlayerNumber(), this.board.getPieces().get(i+1).get(pressedPiece.getY()).getImage()); //on met la case comme ayant été jouée par le joueur en question
                    }
                }
                else
                {
                    for (int i = Piece.getSelectedPiece().getX(); i > pressedPiece.getX(); i--) {
                        setPieceValue(i * this.board.getBoardSize() + pressedPiece.getY(), this.board.getPieces().get(i-1).get(pressedPiece.getY()).getPlayerNumber(), this.board.getPieces().get(i-1).get(pressedPiece.getY()).getImage()); //on met la case comme ayant été jouée par le joueur en question
                    }
                }
                //pressedPiece.press(); //Pas nécessaire car "deselect" exécute déjà l'action
                deselect(pieceId); //On exécute la fonctionnalité de la pièce (assigner une nouvelle valeur de joueur à la pièce) et on déselectionne la pièce
                changeTurn(); //On change à quel joueur c'est le tour de jouer
                winningPieces = verifyWinner(); //On récupère les cases gagnantes s'il y en a
            }
            else
            {
                deselect(pieceId); //On déselectionne la case
            }
        }
        else if (pressedPiece.getPlayerNumber() == this.playerTurn.getPlayerNumber() || pressedPiece.getPlayerNumber() == 0)//Sinon on déselectionne la case sélectionnée
        {
            deselect(pieceId); //On déselectionne la case
        }
        else{
            System.out.println("Vous ne pouvez pas déplacer cette case car elle ne vous appartient pas !");
        }

        return winningPieces; //On renvoie les cases gagnantes s'il y en a
    }

    public void setAllPiecesFunctionalities() //On assigne une fonctionnalité à toutes les cases
    {
        //Initialisation de la fonctionnalité pour toutes les cases
        for (ArrayList<Piece> piecesLine: board.getPieces())
        {
            for (Piece piece: piecesLine)
            {
                if (piece.isSided()) //Si la case est située sur le côté du plate
                    this.board.setFunctionality(new SelectPiece(piece), piece.getId()); //La case est sélectionnable
                else //Sinon
                    this.board.setFunctionality(new DeselectPiece(piece), piece.getId()); //La case permet de désélectionner si une case est déjà sélectionnée
            }
        }
    }

    public void deselect(int pieceId){ //Fonction pour exécuter l'action d'une case et déselectionner toutes les autres cases (remettre à l'état de départ)
        this.board.press(pieceId); //On exécute l'action assignée à la case
        Piece.setSelectedPiece(null); //On déselectionne la case précemment sélectionnée

        //Toutes les cases situées sur le côté récupèrent leur fonction de sélection de case et un affichage neutre
        for (ArrayList<Piece> pieceLine: this.board.getPieces())
        {
            for (Piece piece: pieceLine)
            {
                if(piece.isSided()) {
                    this.board.setFunctionality(new SelectPiece(piece), piece.getId());
                    piece.getBorderPane().setStyle("-fx-background-color: none");
                    piece.getBorderPane().setOpacity(1);
                }
            }
        }
    }

    public void changeTurn() //Méthode pour changer le joueur à qui c'est le tour de jouer
    {
        playerTurn = playerNotTurn;
        if (playerNotTurn == player1)
            playerNotTurn = player2;
        else
            playerNotTurn = player1;
    }

    public ArrayList<Piece> verifyWinner() //On vérifie s'il y a un joueur gagnant
    {
        return board.verifyWinner();
    }

    public void setPieceValue(int pieceId, int playerNumber, Image image) //Pour assigner le joueur à une case
    {
        this.board.getPiece(pieceId).setPlayerNumber(playerNumber, image);
    }

    public Board getBoard() {
        return board;
    }

    public PlayerType getPlayerTurn() {
        return playerTurn;
    }

    public PlayerType getPlayerNotTurn() {
        return playerNotTurn;
    }
}
