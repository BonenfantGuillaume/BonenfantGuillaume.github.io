package ui.model;

import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;

import javafx.scene.input.MouseEvent;

import java.util.ArrayList;

public class Human extends PlayerType{
    private int playerNumber; //Numéro du joueur
    private Image image; //Image appartenant au joueur (croix ou cercle)
    private String color; //Couleur du joueur (bleu ou rouge)

    public Human(int playerNumberCopy){
        super(playerNumberCopy);
        this.playerNumber = playerNumberCopy;


        //On initialise l'image et la couleur qui correspondent au joueur
        if(this.playerNumber == 1)
        {
            this.image = new Image(getClass().getResource("../view/images/cross.png").toExternalForm(), 110.0, 110.0, true, true); //le joueur 1 possède les croix
            this.color = "blue";
        }
        else if (this.playerNumber == 2)
        {
            this.image = new Image(getClass().getResource("../view/images/circle.png").toExternalForm(), 70.0, 70.0, true, true); //le joueur 2 possède les cercles
            this.color = "red";
        }
        else
        {
            System.out.println("Joueur n'étant ni le joueur 1 ni le joueur 2 !");
        }
    }

    @Override
    public ArrayList<Integer> move(Board board, int pieceId) { //On exécute l'action demandée par le joueur
        ArrayList<Integer> moves = new ArrayList<Integer>(); //On crée l'arrayList à renvoyer représentant le coup jouer par le joueur
        moves.add(pieceId); //On ajoute le coup du joueur

        return moves; //On renvoie l'ArrayList représentant le coup du joueur
    }

    @Override
    public Image getImage() {
        return image;
    }

    @Override
    public String getColor() {
        return color;
    }
}
