package ui.model;

import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

public class ThreadsForAiMovablePieces implements Runnable {
    private final CountDownLatch startSignal; //Signal pour commencer l'exécution du thread
    private final CountDownLatch doneSignal; //Signal de fin d'exécution de thread (pour décrémenter le compteur)
    private Board board; //Plateau copié
    private Piece sidedPiece; //Pièce que l'on déplace, copiée
    private Piece movedPiece; //Case où l'on déplace la pièce, copiée
    private int playerPlaying; //Joueur qui joue
    private int opponent; //Son adversaire
    private int newBoardWorth; //Valeur du plateau
    private int depthAI; //Profondeur de l'IA
    private Ai ai; //IA (utile pour l'appel récursif)
    private boolean minMax; //True si on cherche à maximiser la valeur de l'IA, false si on cherche à minimiser la valeur de l'adversaire

    //Initialisation de toutes les variables
    public ThreadsForAiMovablePieces(CountDownLatch startSignal, CountDownLatch doneSignal, Board boardCopy, Piece sidedPieceCopy, Piece movedPieceCopy, int playerPlayingCopy, int opponentCopy, int depthAICopy, Ai aiCopy, boolean minMaxCopy) {
        this.startSignal = startSignal;
        this.doneSignal = doneSignal;
        this.board = boardCopy;
        this.sidedPiece = sidedPieceCopy;
        this.movedPiece = movedPieceCopy;
        this.playerPlaying = playerPlayingCopy;
        this.opponent = opponentCopy;
        this.depthAI = depthAICopy;
        this.ai = aiCopy;
        this.minMax = minMaxCopy;
    }

    //Code exécuté par le thread lorsqu'il est démarré
    public void run() {
        try {
            startSignal.await(); //Attend le signal de lancement
            doWork(); //Code à exécuter
            doneSignal.countDown(); //Une fois le thread fini, on décrémente le nombre de thread qu'il reste à exécuter
        } catch (InterruptedException ex) {
        }
    }

    public void doWork() throws InterruptedException {
        //System.out.println("thread working");

        //On modifie toutes les pièces entre la pièce sélectionnée et la case où on la déplace
        //Si les deux pièces se trouvent sur la même ligne et que la case où l'on déplace la pièce est sur une extrêmité
        if (((movedPiece.getX() == sidedPiece.getX()) && (movedPiece.getY() == 0 || movedPiece.getY() == this.board.getBoardSize()-1)))
        {
            if (movedPiece.getY() > sidedPiece.getY()) //Si la case où l'on déplace la pièce se situe sur l'extrêmité droite du plateau
            {
                for (int j = sidedPiece.getY(); j < movedPiece.getY(); j++) { //Pour toutes les cases entre la pièce et la case où l'on déplace la pièce (de gauche à droite)
                    //On remplace la valeur de la case par celle d'après
                    this.board.getPiece(movedPiece.getX() * this.board.getBoardSize() + j).setPlayerNumberForAI(this.board.getPieces().get(movedPiece.getX()).get(j + 1).getPlayerNumberForAI());
                }
            }
            else //Si la case se situe sur l'extrêmité gauche du plateau
            {
                for (int j = sidedPiece.getY(); j > movedPiece.getY(); j--) { //Pour toutes les cases entre la pièce et la case où l'on déplace la pièce (de droite à gauche)
                    //On remplace la valeur de la case par celle d'avant
                    this.board.getPiece(movedPiece.getX() * this.board.getBoardSize() + j).setPlayerNumberForAI(this.board.getPieces().get(movedPiece.getX()).get(j - 1).getPlayerNumberForAI());
                }
            }
            //La case à l'extrêmité porte le numéro du joueur quoi qu'il arrive
            this.board.getPiece(movedPiece.getId()).setPlayerNumberForAI(playerPlaying);
        }
        //Si les deux pièces se trouvent sur la même colonne et que la case où l'on déplace la pièce est sur une extrêmité
        else if ((movedPiece.getY() == sidedPiece.getY() && (movedPiece.getX() == 0 || movedPiece.getX() == this.board.getBoardSize()-1)))
        {
            if (movedPiece.getX() > sidedPiece.getX()) //Si la case où l'on déplace la pièce se situe sur l'extrêmité basse du plateau
            {
                for (int i = sidedPiece.getX(); i < movedPiece.getX(); i++) { //Pour toutes les cases entre la pièce et la case où l'on déplace la pièce (de haut en bas)
                    //On remplace la valeur de la case par celle d'après (de la prochaine ligne)
                    this.board.getPiece(i * this.board.getBoardSize() + movedPiece.getY()).setPlayerNumberForAI(this.board.getPieces().get(i + 1).get(movedPiece.getY()).getPlayerNumberForAI());
                }
            }
            else //Si la case où l'on déplace la pièce se situe sur l'extrêmité haute du plateau
            {
                for (int i = sidedPiece.getX(); i > movedPiece.getX(); i--) {
                    //On remplace la valeur de la case par celle d'avant (de la ligne précédente)
                    this.board.getPiece(i * this.board.getBoardSize() + movedPiece.getY()).setPlayerNumberForAI(this.board.getPieces().get(i - 1).get(movedPiece.getY()).getPlayerNumberForAI());
                }
            }
            //La case à l'extrêmité porte le numéro du joueur quoi qu'il arrive
            this.board.getPiece(movedPiece.getId()).setPlayerNumberForAI(playerPlaying);
        }

        this.newBoardWorth = boardWorth(board, playerPlaying, opponent); //On calcule la valeur du plateau après tous les changements
        if (this.newBoardWorth > 999) //Si la valeur est supérieur à 999
        {
            if (!minMax) //Si on est dans un cas de minimisation
                this.newBoardWorth = -99999; //On remplace la valeur du plateau par un grand nombre négatif (pour être sur que le thread précédent le réceptionne et comprenne que ce coup fait gagner l'adversaire)
            else //Sinon
                this.newBoardWorth = 99999; //On remplace la valeur du plateau par un grand nombre positif (pour être sur que celui ci soit pris en compte par les threads précédents)
        }
        else if (this.newBoardWorth < -999) //Si la valeur est inférieur à 999 (cela veut dire que l'adversaire gagne)
        {
            if (!minMax) //Si on est dans un cas de minimisation
                this.newBoardWorth = 99999; //On remplace la valeur du plateau par un grand nombre positif (pour être sur que celui ci ne soit pas pris en compte par les threads précédents car le joueur ne jourra pas ce coup-là hormis par erreur ou inadvertance !)
            else //Sinon
                this.newBoardWorth = -99999; //On remplace la valeur du plateau par un grand nombre négatif (pour être sur que celui ci ne soit aps pris en compte par les threads précédents car cela voudrait dire que l'IA fait gagner volontairement son adversaire !)
        }
        else if (depthAI > 1) //Sinon si l'IA n'est pas encore arrivée à sa profondeur maximale
            this.newBoardWorth = this.ai.aiMove(board, this.opponent, this.playerPlaying, this.depthAI-1, false, !minMax).get(0); //On augmente la profondeur de ! (On rappel récursivement la méthode aiMove en changeant le joueur qui joue, la profondeur et minMax
    }

    public int boardWorth(Board board, int playerPlaying, int opponent) //Méthode pour calculer la valeur d'un plateau
    {
        int worth = 0; //initialisation de la valeur à 0

        for (int i = 0; i < board.getBoardSize(); i++) //Pour chaque ligne/colonne du plateau
        {
            worth += getLineWorth(board, i, playerPlaying, opponent); //On calcule la valeur d'une ligne pour le joueur en question face à son adversaire et l'incrémente à la valeur du plateau
            worth += getColumnWorth(board, i, playerPlaying, opponent); //On calcule la valeur d'une colonne pour le joueur en question face à son adversaire et l'incrémente à la valeur du plateau
        }

        worth += getDiagWorth(board, playerPlaying, opponent); //On calcule la valeur des deux diagonales pour le joueur en question face à son adversaire et l'incrémente à la valeur du plateau

        return worth; //renvoi de la valeur du plateau
    }

    public int getLineWorth(Board board, int i, int playerPlaying, int opponent) //Méthode pour récupérer la valeur d'une ligne de plateau
    {
        int worth = 0; //Valeur d'une ligne initialisée à 0

        int playerOnePieceCounter = 0; //Nombre de cases appartenant au joueur qui joue
        int playerTwoPieceCounter = 0; //Nombre de cases appartenant à l'adversaire
        for (Piece piece : board.getPieces().get(i)) //Pour toutes les pièces de la ligne i
        {
            if (piece.getPlayerNumberForAI() == playerPlaying) //Si la pièce appartient au joueur qui joue
                playerOnePieceCounter++; //On incrémente son compteur
            else if (piece.getPlayerNumberForAI() == opponent) //Si la pièce appartient à l'adversaire
                playerTwoPieceCounter++; //On incrémente son compteur
        }

        if (playerOnePieceCounter != 5) //Si toute la ligne n'appartient pas au joueur qui joue
            worth += Math.pow(playerOnePieceCounter, 2); //On ajoute à la valeur d'une ligne le nombre de pièces appartenant au joueur à la puissance 2 (un bon moyen d'inciter le joueur à avoir le plus de pièces possibles sur une même ligne)
        else //Si toute la ligne appartient au joueur qui joue
            worth += 9999; //Le joueur gagne donc on ajoute une valeur très grande à la ligne


        if (playerTwoPieceCounter != 5) //Si toute la ligne n'appartient pas à l'adversaire
            worth -= Math.pow(playerTwoPieceCounter, 2); //On soustrait à la valeur d'une ligne le nombre de pièces appartenant à l'adversaire à la puissance 2 (un bon moyen d'inciter le joueur à ne pas laisser l'adversaire avoir trop de pièces d'affilée sur une même ligne)
        else //Si toute la ligne appartient à l'adversaire
            worth -= 9999; //Le joueur perd donc on soustrait une valeur très grande à la ligne

        return worth; //On renvoie la valeur de la ligne
    }

    public int getColumnWorth(Board board, int j, int playerPlaying, int opponent)
    {
        int worth = 0; //Valeur d'une colonne initialisée à 0

        int playerOnePieceCounter = 0; //Nombre de cases appartenant au joueur qui joue
        int playerTwoPieceCounter = 0; //Nombre de cases appartenant à l'adversaire
        for (int i = 0; i < board.getBoardSize(); i++) //Pour toutes les pièces de la colonne
        {
            if (board.getPieces().get(i).get(j).getPlayerNumberForAI() == playerPlaying) //Si la pièce appartient au joueur qui joue
                playerOnePieceCounter++; //On incrémente son compteur
            else if (board.getPieces().get(i).get(j).getPlayerNumberForAI() == opponent) //Si la pièce appartient à l'adversaire
                playerTwoPieceCounter++; //On incrémente son compteur
        }

        if (playerOnePieceCounter != 5) //Si toute la colonne n'appartient pas au joueur qui joue
            worth += Math.pow(playerOnePieceCounter, 2); //On ajoute à la valeur d'une colonne le nombre de pièces appartenant au joueur à la puissance 2 (un bon moyen d'inciter le joueur à avoir le plus de pièces possibles sur une même colonne)
        else //Si toute la colonne appartient au joueur qui joue
            worth += 9999; //Le joueur gagne donc on ajoute une valeur très grande à la ligne

        if (playerTwoPieceCounter != 5) //Si toute la colonne n'appartient pas à l'adversaire
            worth -= Math.pow(playerTwoPieceCounter, 2); //On soustrait à la valeur d'une colonne le nombre de pièces appartenant à l'adversaire à la puissance 2 (un bon moyen d'inciter le joueur à ne pas laisser l'adversaire avoir trop de pièces d'affilée sur une même colonne)
        else //Si toute la colonne appartient à l'adversaire
            worth -= 9999; //Le joueur perd donc on soustrait une valeur très grande à la ligne

        return worth; //On renvoie la valeur d'une colonne
    }

    public int getDiagWorth(Board board, int playerPlaying, int opponent)
    {
        int worth = 0; //Valeur des diagonales initialisée à 0

        int playerOnePieceCounterDiagOne = 0; //Nombre de cases appartenant au joueur qui joue pour la première diagonale
        int playerTwoPieceCounterDiagOne = 0; //Nombre de cases appartenant à l'adversaire pour la première diagonale
        int playerOnePieceCounterDiagTwo = 0; //Nombre de cases appartenant au joueur qui joue pour la deuxième diagonale
        int playerTwoPieceCounterDiagTwo = 0; //Nombre de cases appartenant à l'adversaire pour la deuxième diagonale

        for (int i = 0; i < board.getBoardSize(); i++) //Pour toutes les pièces des diagonales
        {
            //Première diagonale
            if (board.getPieces().get(i).get(i).getPlayerNumberForAI() == playerPlaying) //Si la pièce appartient au joueur qui joue
                playerOnePieceCounterDiagOne++; //On incrémente son compteur
            else if (board.getPieces().get(i).get(i).getPlayerNumberForAI() == opponent) //Si la pièce appartient à l'adversaire
                playerTwoPieceCounterDiagOne++; //On incrémente son compteur

            //Deuxième diagonale
            if (board.getPieces().get(i).get(board.getBoardSize() - 1 - i).getPlayerNumberForAI() == playerPlaying) //Si la pièce appartient au joueur qui joue
                playerOnePieceCounterDiagTwo++; //On incrémente son compteur
            else if (board.getPieces().get(i).get(board.getBoardSize() - 1 - i).getPlayerNumberForAI() == opponent) //Si la pièce appartient à l'adversaire
                playerTwoPieceCounterDiagTwo++; //On incrémente son compteur
        }

        //Première diagonale
        if (playerOnePieceCounterDiagOne != 5) //Si toute la première diagonale n'appartient pas au joueur qui joue
            worth += Math.pow(playerOnePieceCounterDiagOne, 2); //On ajoute à la valeur des diagonales le nombre de pièces appartenant au joueur à la puissance 2 (un bon moyen d'inciter le joueur à avoir le plus de pièces possibles sur une même diagonale)
        else //Si toute la première diagonale appartient au joueur qui joue
            worth += 9999; //Le joueur gagne donc on ajoute une valeur très grande à la diagonale

        if (playerTwoPieceCounterDiagOne != 5) //Si toute la première diagonale n'appartient pas à l'adversaire
            worth -= Math.pow(playerTwoPieceCounterDiagOne, 2); //On soustrait à la valeur des diagonales le nombre de pièces appartenant à l'adversaire à la puissance 2 (un bon moyen d'inciter le joueur à ne pas laisser l'adversaire avoir trop de pièces d'affilée sur une même diagonale)
        else //Si toute la première diagonale appartient à l'adversaire
            worth -= 9999; //Le joueur perd donc on soustrait une valeur très grande à la diagonale

        //Deuxième diagonale
        if (playerOnePieceCounterDiagTwo != 5) //Si toute la deuxième diagonale n'appartient pas au joueur qui joue
            worth += Math.pow(playerOnePieceCounterDiagTwo, 2); //On ajoute à la valeur des diagonales le nombre de pièces appartenant au joueur à la puissance 2 (un bon moyen d'inciter le joueur à avoir le plus de pièces possibles sur une même diagonale)
        else //Si toute la deuxième diagonale appartient au joueur qui joue
            worth += 9999; //Le joueur gagne donc on ajoute une valeur très grande à la diagonale

        if (playerTwoPieceCounterDiagTwo != 5) //Si toute la deuxième diagonale n'appartient pas à l'adversaire
            worth -= Math.pow(playerTwoPieceCounterDiagTwo, 2); //On soustrait à la valeur des diagonales le nombre de pièces appartenant à l'adversaire à la puissance 2 (un bon moyen d'inciter le joueur à ne pas laisser l'adversaire avoir trop de pièces d'affilée sur une même diagonale)
        else //Si toute la deuxième diagonale appartient à l'adversaire
            worth -= 9999; //Le joueur perd donc on soustrait une valeur très grande à la diagonale

        return worth; //On renvoie la valeur des diagonales
    }

    public int getFirstMove()
    {
        return sidedPiece.getId();
    }

    public int getSecondMove()
    {
        return movedPiece.getId();
    }

    public int getNewBoardWorth()
    {
        return newBoardWorth;
    }
}
