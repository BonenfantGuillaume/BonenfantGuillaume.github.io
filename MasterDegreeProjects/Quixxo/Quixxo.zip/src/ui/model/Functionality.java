package ui.model;

public interface Functionality {
    public void trigger(); //déclenchement d'une fonctionnalité
}
