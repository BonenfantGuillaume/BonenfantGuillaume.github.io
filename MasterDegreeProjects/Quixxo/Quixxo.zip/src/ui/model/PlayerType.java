package ui.model;

import javafx.scene.image.Image;

import javafx.scene.input.MouseEvent;

import java.util.ArrayList;

public abstract class PlayerType {
    private int playerNumber; //Numéro du joueur
    private Image image; //Image appartenant au joueur (croix ou cercle)
    private String color; //Couleur du joueur (bleu ou rouge)

    public PlayerType(int playerNumberCopy){
        this.playerNumber = playerNumberCopy;
    }

    public abstract ArrayList<Integer> move(Board board, int pieceId) throws InterruptedException; //Méthode pour renvoyer le coup jouer par le joueur

    public int getPlayerNumber() {
        return playerNumber;
    }

    public Image getImage() {
        return image;
    }

    public String getColor() {
        return color;
    }
}
