package ui.model;

import javafx.scene.layout.BorderPane;

import java.util.ArrayList;

public class Board implements Cloneable {
    private int boardSize;
    private ArrayList<ArrayList<Piece>> pieces = new ArrayList<ArrayList<Piece>>(); //Matrice représentant le plateau de jeu

    public Board(int boardSizeCopy, ArrayList<ArrayList<BorderPane>> allBorderPanes){
        this.boardSize = boardSizeCopy;

        //Initialisation de la matrice de pièces
        for(int i = 0; i < this.boardSize; i++)
        {
            pieces.add(new ArrayList<Piece>());
            for (int j = 0; j < this.boardSize; j++)
            {
                pieces.get(i).add(new Piece(allBorderPanes.get(i).get(j), i, j));

                //Possible car les cases ne se déplacent pas, seulement la valeur du jouer qui la possède change
                if (i < 1 || i == boardSize-1 || j == 0 || j == boardSize-1) //Si la pièce est sur les bords
                    pieces.get(i).get(j).setSided(true); //On la marque comme appartenant aux bords
                else //Sinon
                    pieces.get(i).get(j).setSided(false); //On la marque comme n'appartenant pas aux boards
            }
        }
    }

    public void setFunctionality(Functionality functionnality, int pieceNumber) //On assigne une fonctionnalité à une pièce
    {
        //On récupère la pièce qui nous intéresse sur le plateau et on lui assigne la fonctionnalité
        this.pieces.get(pieceNumber/pieces.size()).get(pieceNumber%pieces.size()).setFunctionality(functionnality);
    }

    public void press(int pieceNumber)
    {
        //On récupère la pièce qui nous intéresse sur le plateau et on active sa fonctionnalité
        this.pieces.get(pieceNumber/pieces.size()).get(pieceNumber%pieces.size()).press();
    }

    /*Cette fonction prend en compte les égalités ! En effet, il est possible que sur un mouvement d'une pièce, il y ait
    plusieurs lignes gagnantes ou colonnes gagnantes. S'il s'avère que les deux joueurs ont autant de "5 pièces d'affilée"
    leur appartenant l'un que l'autre, il y a alors égalité !*/
    public ArrayList<Piece> verifyWinner(){
        int winner = 0; //0 si pas de gagnant. 1 Si joueur 1 est gagnant. 2 Si joueur 2 est gagnant. 3 Si égalité.
        ArrayList<Piece> winningPieces = new ArrayList<Piece>();

        ArrayList<Integer> fiveInARowPerPlayer = new ArrayList<Integer>(); //ArrayList qui compte le nombre de "5 pièces d'affilée" pour chaque joueur.
        //Initialisation de l'ArrayList. Chaque joueur a 0 "5 pièces d'affilée" au départ

        fiveInARowPerPlayer.add(0);
        fiveInARowPerPlayer.add(0);
        int beforePlayerOne = 0;
        int beforePlayerTwo = 0;
        for (int i = 0; i < this.pieces.size(); i++)
        {
            //On s'occupe de regarder s'il y a un gagnant dans la ligne
            beforePlayerOne = fiveInARowPerPlayer.get(0);
            beforePlayerTwo = fiveInARowPerPlayer.get(1);
            fiveInARowPerPlayer = verifyLine(fiveInARowPerPlayer, i); //On regarde s'il y a un gagnant sur la ligne
            winningPieces = getWinningPiecesLine(winningPieces, fiveInARowPerPlayer, beforePlayerOne, beforePlayerTwo, i); //S'il y a un gagnant, cette méthode s'occupe d'ajouter les pièces gagnantes

            //On s'occupe de regarder s'il y a un gagnant dans la colonne
            beforePlayerOne = fiveInARowPerPlayer.get(0);
            beforePlayerTwo = fiveInARowPerPlayer.get(1);
            fiveInARowPerPlayer = verifyColumn(fiveInARowPerPlayer, i); //On regarde s'il y a un gagnant sur la colonne
            winningPieces = getWinningPiecesColumn(winningPieces, fiveInARowPerPlayer, beforePlayerOne, beforePlayerTwo, i); //S'il y a un gagnant, cette méthode s'occupe d'ajouter les pièces gagnantes
        }

        //On s'occupe de regarder s'il y a un gagnant dans la première diagonale
        beforePlayerOne = fiveInARowPerPlayer.get(0);
        beforePlayerTwo = fiveInARowPerPlayer.get(1);
        fiveInARowPerPlayer = verifyDiagonal(fiveInARowPerPlayer, true); //On regarde s'il y a un gagnant sur la premiere diagonale
        winningPieces = getWinningPiecesDiagonal(winningPieces, fiveInARowPerPlayer, beforePlayerOne, beforePlayerTwo, true); //S'il y a un gagnant, cette méthode s'occupe d'ajouter les pièces gagnantes

        //On s'occupe de regarder s'il y a un gagnant dans la deuxième diagonale
        beforePlayerOne = fiveInARowPerPlayer.get(0);
        beforePlayerTwo = fiveInARowPerPlayer.get(1);
        fiveInARowPerPlayer = verifyDiagonal(fiveInARowPerPlayer, false); //On regarde s'il y a un gagnant sur la deuxième diagonale
        winningPieces = getWinningPiecesDiagonal(winningPieces, fiveInARowPerPlayer, beforePlayerOne, beforePlayerTwo, false); //S'il y a un gagnant, cette méthode s'occupe d'ajouter les pièces gagnantes

        //On regarde si un joueur a réussi à placer 5 de ses pièces d'affilée (gagner)
        if (fiveInARowPerPlayer.get(0) > 0 || fiveInARowPerPlayer.get(1) > 0)
        {
            if (fiveInARowPerPlayer.get(0) > fiveInARowPerPlayer.get(1)) //Si le joueur 1 a plus de "5 pièces d'affilée" que le joueur 2
                winner = 1;
            else if (fiveInARowPerPlayer.get(0) < fiveInARowPerPlayer.get(1)) //Si le joueur 2 a plus de "5 pièces d'affilée" que le joueur 1
                winner = 2;
            else //S'il y a égalité
                winner = 3;
        }

        System.out.println("Winner : " + winner);

        return winningPieces;
    }

    private ArrayList<Piece> getWinningPiecesLine(ArrayList<Piece> winningPieces, ArrayList<Integer> fiveInARowPerPlayer, int beforePlayerOne, int beforePlayerTwo, int i) { //Méthode qui renvoie les pièces gagnantes d'une ligne
        if (beforePlayerOne < fiveInARowPerPlayer.get(0) || beforePlayerTwo < fiveInARowPerPlayer.get(1)) //S'il y a un gagnant (moins de "5 d'affilée avant" que ce qu'il y a maintenant)
        {
            for (Piece pieceOfLine: this.pieces.get(i)) //Pour toutes les pièces de la ligne
            {
                winningPieces.add(pieceOfLine); //On ajoute la pièce aux pièces gagnantes
            }
        }

        return winningPieces; //On renvoie les pièces gagnantes
    }

    private ArrayList<Piece> getWinningPiecesColumn(ArrayList<Piece> winningPieces, ArrayList<Integer> fiveInARowPerPlayer, int beforePlayerOne, int beforePlayerTwo, int j) { //Méthode qui renvoie les pièces gagnantes d'une colonne
        if (beforePlayerOne < fiveInARowPerPlayer.get(0) || beforePlayerTwo < fiveInARowPerPlayer.get(1)) //S'il y a un gagnant (moins de "5 d'affilée avant" que ce qu'il y a maintenant)
        {
            for (int i = 0; i < this.boardSize; i++) //Pour toutes les pièces de la colonne
            {
                winningPieces.add(getPiece(i*this.boardSize + j)); //On ajoute la pièce aux pièces gagnantes
            }
        }

        return winningPieces; //On renvoie les pièces gagnantes
    }

    //Méthode qui renvoie les pièces gagnantes d'une diagonale
    private ArrayList<Piece> getWinningPiecesDiagonal(ArrayList<Piece> winningPieces, ArrayList<Integer> fiveInARowPerPlayer, int beforePlayerOne, int beforePlayerTwo, boolean diag) { //diag récupère le numéro de la diagonale. True pour de en haut à gauche à en bas à droite. False pour en haut à droite à en bas à gauche.
        //Méthode qui renvoie les pièces gagnantes d'une colonne
        if (beforePlayerOne < fiveInARowPerPlayer.get(0) || beforePlayerTwo < fiveInARowPerPlayer.get(1)) //S'il y a un gagnant (moins de "5 d'affilée avant" que ce qu'il y a maintenant)
        {
            if (diag) { //Si on est dans la première diagonale
                for (int i = 0; i < this.boardSize; i++) //Pour toutes les pièces de la diagonale
                {
                    winningPieces.add(getPiece(i*this.boardSize + i)); //On ajoute la pièce aux pièces gagnantes
                }
            }
            else //Si on est dans la deuxième diagonale
            {
                for (int i = 0; i < this.pieces.size(); i++) //Pour toutes les pièces de la diagonale
                {
                    winningPieces.add(getPiece(i*this.boardSize + this.boardSize - i - 1)); //On ajoute la pièce aux pièces gagnantes
                }
            }
        }

        return winningPieces; //On renvoie les pièces gagnantes
    }

    //Vérifier si une ligne est gagnante
    private ArrayList<Integer> verifyLine(ArrayList<Integer> fiveInARowPerPlayer, int i) {
        int inARow = 0; //Nombre de pièces de meme type d'affilée
        int playerLooked = this.pieces.get(i).get(0).getPlayerNumber(); //Joueur qui possède la première pièce
        if (playerLooked != 0) //Si la pièce appartient bien à un joueur
        {
            for (int j = 0; j < this.pieces.get(i).size(); j++) {
                if (this.pieces.get(i).get(j).getPlayerNumber() == playerLooked) //Si la pièce regardée appartient au même joueur que la première pièce
                    inARow++; //On incrémente le nombre de pièces d'affilée
                else
                    break;
            }
        }

        //on peut peindre les cases dans ce if !
        if (inARow == 5) //Si 5 pièces d'affilée
            fiveInARowPerPlayer.set(playerLooked-1, fiveInARowPerPlayer.get(playerLooked-1)+1); //On incrémente de 1 le nombre de 5 pièces d'affilée pour le joueur en question

        return fiveInARowPerPlayer; //Renvoie de l'ArrayList mise à jour
    }

    //Vérifier si une colonne est gagnante
    private ArrayList<Integer> verifyColumn(ArrayList<Integer> fiveInARowPerPlayer, int j) {
        int inARow = 0; //Nombre de pièces de meme type d'affilée
        int playerLooked = this.pieces.get(0).get(j).getPlayerNumber(); //Joueur qui possède la première pièce
        if (playerLooked != 0) //Si la pièce appartient bien à un joueur
        {
            for (int i = 0; i < this.pieces.get(j).size(); i++)
            {
                if (this.pieces.get(i).get(j).getPlayerNumber() == playerLooked) //Si la pièce regardée appartient au même joueur que la première pièce
                    inARow++; //On incrémente le nombre de pièces d'affilée
                else
                    break;
            }
        }

        //On peut peindre les cases dans ce if !
        if (inARow == 5) //Si 5 pièces d'affilée
            fiveInARowPerPlayer.set(playerLooked-1, fiveInARowPerPlayer.get(playerLooked-1)+1); //On incrémente de 1 le nombre de 5 pièces d'affilée pour le joueur en question

        return fiveInARowPerPlayer; //Renvoie de l'ArrayList mise à jour
    }

    //Vérifier si les diagonales sont gagnantes
    private ArrayList<Integer> verifyDiagonal(ArrayList<Integer> fiveInARowPerPlayer, boolean diag) { //diag récupère le numéro de la diagonale. True pour de en haut à gauche à en bas à droite. False pour en haut à droite à en bas à gauche.
        int diagInARow = 0; //Nombre de pièces de meme type d'affilée pour la diagonale qui va de en haut à gauche à en bas à droite

        if (diag) {
            int playerLookedOne = this.pieces.get(0).get(0).getPlayerNumber(); //Joueur qui possède la première pièce de la première diagonale

            for (int i = 0; i < this.pieces.size(); i++)
            {
                if (this.pieces.get(i).get(i).getPlayerNumber() == playerLookedOne) //Si la pièce regardée appartient au même joueur que la première pièce de la ppremière diagonale
                    diagInARow++; //On incrémente le nombre de pièces d'affilée pour la première diagonale
                else
                    break;
            }
            //On peut peindre les cases dans ce if !
            if (diagInARow == 5 && playerLookedOne != 0) //Si 5 pièces d'affilée et que les pièces appartiennent bien à un joueur
                fiveInARowPerPlayer.set(playerLookedOne-1, fiveInARowPerPlayer.get(playerLookedOne-1)+1); //On incrémente de 1 le nombre de 5 d'affilée pour le joueur en question
        }
        else
        {
            int playerLookedTwo = this.pieces.get(0).get(this.pieces.size()-1).getPlayerNumber(); //Joueur qui possède la première pièce de la deuxième diagonale
            for (int i = 0; i < this.pieces.size(); i++)
            {
                if (this.pieces.get(i).get(4-i).getPlayerNumber() == playerLookedTwo) //Si la pièce regardée appartient au même joueur que la première pièce de la deuxième diagonale
                    diagInARow++; //On incrémente le nombre de pièces d'affilée pour la deuxième diagonale
                else
                    break;
            }

            //On peut peindre les cases dans ce if !
            if (diagInARow == 5 && playerLookedTwo != 0) //Si 5 pièces d'affilée et que les pièces appartiennent bien à un joueur
                fiveInARowPerPlayer.set(playerLookedTwo-1, fiveInARowPerPlayer.get(playerLookedTwo-1)+1); //On incrémente de 1 le nombre de 5 d'affilée pour le joueur en question
        }
        return fiveInARowPerPlayer; //Renvoie de l'ArrayList mise à jour
    }

    //Méthode pour cloner un plateau
    public Object clone(){
        try {
            Board tmp = (Board) super.clone(); //On clone le plateau
            tmp.pieces = (ArrayList<ArrayList<Piece>>) this.pieces.clone(); //On clone la matrice de Pièces (en profondeur)
            for (int i = 0; i < boardSize; i++)
            {
                tmp.pieces.set(i, (ArrayList<Piece>) this.pieces.get(i).clone()); //On clone les lignes de la matrice de Pièces
                for (int j = 0; j < boardSize; j++)
                {
                    tmp.pieces.get(i).set(j, (Piece) this.getPiece(i * this.boardSize + j).clone()); //On clone les pièces de chaque lignes
                }
            }
            return tmp; //On renvoie le plateau
        }
        catch (CloneNotSupportedException e){
            throw new InternalError();
        }
    }

    public ArrayList<ArrayList<Piece>> getPieces() {
        return pieces;
    }

    public int getBoardSize() {
        return boardSize;
    }

    public Piece getPiece(int id)
    {
        return this.pieces.get(id/this.boardSize).get(id%this.boardSize);
    }
}
