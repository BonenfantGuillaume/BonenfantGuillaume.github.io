package ui;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import ui.view.*;

public class MainApp extends Application {

	//Configuration de la fenetre de jeu et de la page d'accueil
	private Stage lancementStage; 
	private BorderPane rootLayout;

	
	@Override
	public void start(Stage primaryStage) {
		//On crée notre fenêtre
		this.lancementStage = primaryStage;
		this.lancementStage.setTitle("Quixxer - Accueil");
		this.lancementStage.setResizable(false); 
		
		initRootLayout();

		showHomepageView(); //On affiche la page d'accueil
	}
	
	 public void initRootLayout() { //Charger RootLayout
	        try {

	            FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
	            
	            rootLayout = (BorderPane) loader.load();
	            	            
	            Scene scene = new Scene(rootLayout);
	            lancementStage.setScene(scene);
	            lancementStage.show();
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	public void showHomepageView() //Afficher la page d'accueil
	{
		try {
			//Charger le fichier fxml associé
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("view/HomepageView.fxml")); //On charge la vue souhaitée
			AnchorPane menuOverview = (AnchorPane) loader.load();


			this.lancementStage.setTitle("Quixxer - Accueil"); //On choisit le titre de la fenêtre

			//On charge le controlleur associé a la vue
			HomepageController controller = loader.getController();
			controller.setMainApp(this);

			//On met la vue au centre de la scene
			rootLayout.setCenter(menuOverview);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	 
	 public void showGameView(int depthAI, int playerOneVictoryNumber, int playerTwoVictoryNumber) //Afficher la page de jeu
	 {
		  try {
			  //charger le fichier fxml associé
			  FXMLLoader loader = new FXMLLoader();
			  loader.setLocation(MainApp.class.getResource("view/GameView.fxml")); //On charge la vue souhaitée
			  AnchorPane playOverview = (AnchorPane) loader.load();

			  this.lancementStage.setTitle("Quixxer - Jeu"); //On choisit le titre de la fenêtre

			  //On charge le controlleur associé a la vue
			  GameController controller = loader.getController();
			  controller.setMainApp(this, depthAI, playerOneVictoryNumber, playerTwoVictoryNumber);

			  //On met la vue au centre
			  rootLayout.setCenter(playOverview);
		  }
		  catch (IOException e) {
			  e.printStackTrace();
		  }
	 }

	public void showAiDifficultyChoiceView()
	{
		try {
			//Charger le fichier fxml associé
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("view/AiDifficultyChoiceView.fxml")); //On charge la vue souhaitée
			AnchorPane menuOverview = (AnchorPane) loader.load();

			this.lancementStage.setTitle("Quixxo - Difficulté"); //On choisit le titre de la fenêtre

			//On charge le controlleur associé a la vue
			AiDifficultyChoiceController controller = loader.getController();
			controller.setMainApp(this);

			//On met la vue au centre de la scene
			rootLayout.setCenter(menuOverview);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
