from sklearn import metrics

class DistanceMeasuring:
    def execute(self, X):
        return metrics.pairwise_distances(X)
            
