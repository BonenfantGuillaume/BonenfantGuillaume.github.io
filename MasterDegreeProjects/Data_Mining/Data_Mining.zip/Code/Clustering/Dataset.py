from sklearn import datasets

class Dataset:
    def getDataset(self, datasetName): #Keywords : circles/blobs/moons
        if (datasetName == "blobs"):
            return datasets.make_blobs(n_samples = 1000, cluster_std=0.7)
        elif (datasetName == "circles"):
            return datasets.make_circles(n_samples = 1000, factor=0.5, noise=0.05)
        elif (datasetName == "moons"):
            return datasets.make_moons(n_samples = 1000, noise=0.05)
        print ("No such dataset type existing, try something else : blobs/circles/noisy_moons")
        return None
            
    def getAllDatasets(self):
        datasets = []
        datasets.append([])
        datasets[0].append(self.getDataset("circles"))
        datasets[0].append("noisy_circles")
        datasets.append([])
        datasets[1].append(self.getDataset("blobs"))
        datasets[1].append("blobs")
        datasets.append([])
        datasets[2].append(self.getDataset("moons"))
        datasets[2].append("noisy_moons")

        return datasets
            
