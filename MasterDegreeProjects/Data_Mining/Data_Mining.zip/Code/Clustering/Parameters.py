class Parameters:
    def getAllParameters(self):
        params = [] #parameters
        #parameters to run the algorithms for noisy_circles dataset in a good way
        params.append([])
        params[0].append([])
        params[0][0].append(0.15)
        params[0][0].append(15)
        params[0].append([])
        params[0][1].append(2)
        params[0].append([])
        params[0][2].append(2)

        #parameters to run the algorithms for blobs dataset in a good way
        params.append([])
        params[1].append([])
        params[1][0].append(0.5)
        params[1][0].append(20)
        params[1].append([])
        params[1][1].append(3)
        params[1].append([])
        params[1][2].append(3)

        #parameters to run the algorithms for noisy_moons dataset in a good way
        params.append([])
        params[2].append([])
        params[2][0].append(0.2)
        params[2][0].append(20)
        params[2].append([])
        params[2][1].append(2)
        params[2].append([])
        params[2][2].append(2)

        return params
            
