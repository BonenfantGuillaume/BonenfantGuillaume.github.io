from sklearn.cluster import KMeans

class MyKMeans :
    #KMeans algorithm
    def execute(self, X, **kwargs):
        nClusters = 2
        if ("params" in kwargs):
            if (kwargs["params"] != None):
                nClusters = kwargs["params"][0]
        return KMeans(n_clusters = nClusters).fit(X)
