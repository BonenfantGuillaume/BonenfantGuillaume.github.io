from sklearn.cluster import DBSCAN 

class MyDBSCAN :
    #DBSCAN algorithm
    def execute(self, X, **kwargs):
        epsilon = 0.2
        minSamples = 20
        if ("params" in kwargs):
            if (kwargs["params"] != None):
                epsilon = kwargs["params"][0]
                minSamples = kwargs["params"][1]
        return DBSCAN(eps = epsilon, min_samples = minSamples).fit(X)
