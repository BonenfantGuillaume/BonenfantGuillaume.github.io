from sklearn.cluster import SpectralClustering 

class MySpectralClustering :
    #Spectral clustering algorithm
    def execute(self, X, **kwargs):
        nClusters = 2
        if ("params" in kwargs):
            if (kwargs["params"] != None):
                nClusters = kwargs["params"][0]
        return SpectralClustering(n_clusters=nClusters, affinity='nearest_neighbors', n_neighbors = 20).fit(X)
