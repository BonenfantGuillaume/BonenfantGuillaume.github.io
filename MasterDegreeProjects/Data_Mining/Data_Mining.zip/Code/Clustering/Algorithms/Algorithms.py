from Clustering.Algorithms import DBSCAN, KMeans, SpectralClustering

class Algorithms :
    def getAllAlgorithms(self):
        clusteringAlgorithms = []
        clusteringAlgorithms.append([])
        clusteringAlgorithms[0].append(DBSCAN.MyDBSCAN())
        clusteringAlgorithms[0].append("DBSCAN")
        clusteringAlgorithms.append([])
        clusteringAlgorithms[1].append(KMeans.MyKMeans())
        clusteringAlgorithms[1].append("KMeans")
        clusteringAlgorithms.append([])
        clusteringAlgorithms[2].append(SpectralClustering.MySpectralClustering())
        clusteringAlgorithms[2].append("Spectral Clustering")
        
        return clusteringAlgorithms
