import numpy as np
import matplotlib.pyplot as plt
from pandas import DataFrame

class ClusteringPipe :
    def execute(self, datasets, clusteringAlgorithms, qualityMeasures, **kwargs):
        distanceMeasuringAlgorithms = []
        if ("distanceAlgorithms" in kwargs):
            distanceMeasuringAlgorithms = kwargs["distanceAlgorithms"]

        for i in range(len(datasets)):
            cpt = 0
            print("Using", datasets[i][1], "dataset :\n")
            for j in range(len(distanceMeasuringAlgorithms)):
                print("Distance measuring algorithm :", distanceMeasuringAlgorithms[j][1])
                distanceMeasuringAlgorithms[j][0].execute(datasets[i][0])
            for algo in clusteringAlgorithms:
                print("Algorithm :", algo[1])
                params = None
                if ("params" in kwargs):
                    if (kwargs["params"] != None):
                        params = kwargs["params"][i][cpt]

                clustering = algo[0].execute(datasets[i][0], params = params)
                labels = clustering.labels_
                for j in range(len(qualityMeasures)):
                    if (qualityMeasures[j][2] == False):
                        count = np.count_nonzero(labels == 0)
                        if (count == len(labels)):
                            print("One only cluster : can not process non ground truth score")
                        else :
                            print(qualityMeasures[j][1], "score : ", qualityMeasures[j][0].execute(datasets[i][0], labels))
                    else :
                        print(qualityMeasures[j][1], "score : ", qualityMeasures[j][0].execute(datasets[i][2], labels))


                #uncomment for data visualization
##                cluster = clustering.labels_
##                df = DataFrame(dict(x=clusterings[i][0][:,0], y=clusterings[i][0][:,1], label=cluster))
##                colors = {-1: 'black', 0: 'red', 1:'blue', 2:'green', 3:'orange'}
##                fig, ax = plt.subplots(figsize=(8, 8))
##                grouped = df.groupby('label')
##                for key, group in grouped :
##                    group.plot(ax = ax, kind='scatter', x='x', y='y', label=key, color=colors[key])
##                plt.xlabel('X_1')
##                plt.ylabel('X_2')
##                plt.show()
                cpt += 1
                print()
            print("\n\n")

