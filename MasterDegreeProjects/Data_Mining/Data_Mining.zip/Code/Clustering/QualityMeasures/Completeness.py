from sklearn.metrics import completeness_score

class MyCompleteness :
    #Completeness score
    def execute(self, ground_truth, labels):
        return completeness_score(ground_truth, labels)
