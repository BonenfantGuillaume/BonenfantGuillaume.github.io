from sklearn.metrics import jaccard_score

class MyJaccard :
    #Jaccard score
    #Doesn't work for some reasons (or at least not in every cases)
    def execute(self, ground_truth, labels):
        return jaccard_score(ground_truth, labels, average = "micro")
