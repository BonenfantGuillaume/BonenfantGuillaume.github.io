from Clustering.QualityMeasures import Silhouette, Completeness, Jaccard, RandScore

class QualityMeasures:
    def getAllQualityMeasures(self):
        #Quality measures
        clusteringQualityMeasures = [] #Quality measure algorithms
        clusteringQualityMeasures.append([])
        clusteringQualityMeasures[0].append(Silhouette.MySilhouette())
        clusteringQualityMeasures[0].append("Silhouette")
        clusteringQualityMeasures[0].append(False)
        clusteringQualityMeasures.append([])
        clusteringQualityMeasures[1].append(Completeness.MyCompleteness())
        clusteringQualityMeasures[1].append("Completeness")
        clusteringQualityMeasures[1].append(True)
        clusteringQualityMeasures.append([])
        #clusteringQualityMeasures[2].append(Jaccard.MyJaccard())
        #clusteringQualityMeasures[2].append("Jaccard")
        #clusteringQualityMeasures[2].append(True)
        clusteringQualityMeasures[2].append(RandScore.MyRandScore())
        clusteringQualityMeasures[2].append("Rand")
        clusteringQualityMeasures[2].append(True)

        return clusteringQualityMeasures

    def getQualityMeasure(self, measureName): #Possible keys : Silhouette/Completeness/Randscore
        clusteringQualityMeasure = [] #Quality measure algorithm
        if(measureName == "Silhouette"):
            clusteringQualityMeasure.append(Silhouette.MySilhouette())
            clusteringQualityMeasure.append("Silhouette")
            clusteringQualityMeasure.append(False)
        elif(measureName == "Completeness"):
            clusteringQualityMeasure.append(Completeness.MyCompleteness())
            clusteringQualityMeasure.append("Completeness")
            clusteringQualityMeasure.append(True)
        elif(measureName == "Randscore"):
            clusteringQualityMeasure.append(RandScore.MyRandScore())
            clusteringQualityMeasure.append("Rand")
            clusteringQualityMeasure.append(True)
        else:
            clusteringQualityMeasure = None

        return clusteringQualityMeasure

