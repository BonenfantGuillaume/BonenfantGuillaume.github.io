from sklearn.metrics import rand_score

class MyRandScore :
    #Randscore
    def execute(self, ground_truth, labels):
        return rand_score(ground_truth, labels)
