from sklearn.metrics import silhouette_score

class MySilhouette :
    #Silhouette score
    def execute(self, data, labels):
        return silhouette_score(data, labels)
