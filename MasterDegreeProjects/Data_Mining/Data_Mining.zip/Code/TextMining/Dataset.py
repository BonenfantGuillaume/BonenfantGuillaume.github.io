class Dataset:
    def getDataset(self): #Dataset sorted alphabetically 
        f = open("./TextMining/Data/corpus.txt", "r")
        Lines = f.readlines()

        lineCpt = 0
        matrix = []
        wordsMap = {}
        for i in  range(len(Lines)):
            matrix.append([])
        for line in Lines:
            line = line.replace("\n", "")
            words = line.split(" ")
            for word in words:
                if (word != ""):
                    if (word not in wordsMap):
                        place = 0
                        for key in wordsMap:
                            if (key <= word):
                                place +=1
                            else:
                                wordsMap[key] += 1
                        wordsMap[word] = place
                        for i in range (len(Lines)):
                            matrix[i].insert(place, 0)
                    matrix[lineCpt][wordsMap[word]] += 1
            lineCpt += 1

        return matrix, wordsMap

    def getDatasetFast(self): #Unsorted dataset
        f = open("./TextMining/Data/corpus.txt", "r")
        Lines = f.readlines()

        lineCpt = 0
        matrix = []
        wordsMap = {}
        for i in  range(len(Lines)):
            matrix.append([])

        wordsNumber = 0
        for line in Lines:
            line = line.replace("\n", "")
            words = line.split(" ")
            for word in words:
                if (word != ""):
                    if (word not in wordsMap):
                        wordsMap[word] = wordsNumber
                        wordsNumber += 1
                        for i in range (len(Lines)):
                            matrix[i].append(0)
                    matrix[lineCpt][wordsMap[word]] += 1
            lineCpt += 1

        return matrix, wordsMap








        
