from sklearn.feature_extraction.text import TfidfTransformer
import numpy as np

class MyScikitVSM:
    def execute(self, wordsPerFileMatrix):
        wordsPerFileArray = np.array(wordsPerFileMatrix)
        tfidf_transformer = TfidfTransformer(use_idf=True)
        tfidf = tfidf_transformer.fit_transform(wordsPerFileArray)
        
        tfidf = tfidf.toarray()

        valuesToReturn = []
        valuesToReturn.append(tfidf)
        valuesToReturn.append("ScikitVSM")
        return valuesToReturn
