import numpy as np
import math

class VectorSpaceModel:
    def execute(self, matrix):
        tfidfMatrix = []
        occurrenceMap = []
        for i in range (len(matrix)):
            tfidfMatrix.append([])
        for j in range (len(matrix[0])):
            occurrenceMap.append(0)
            for i in range (len(matrix)):
                if (matrix[i][j] != 0):
                    occurrenceMap[j] += 1
            for i in range(len(matrix)):
                tfidfMatrix[i].append(matrix[i][j] * math.log(len(matrix)/occurrenceMap[j]))

        tfidf = np.array(tfidfMatrix)
        
        valuesToReturn = []
        valuesToReturn.append(tfidf)
        valuesToReturn.append("MyVSM")
        return valuesToReturn
