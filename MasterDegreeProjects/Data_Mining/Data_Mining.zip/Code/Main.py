#Clustering imports
from Clustering import Dataset as ClusteringDataset
from Clustering.Algorithms import DBSCAN, KMeans, SpectralClustering
from Clustering.QualityMeasures import Silhouette, Completeness, Jaccard, RandScore
from Clustering import Pipe as ClusteringPipe
from Clustering.Algorithms import Algorithms as ClusteringAlgorithms
from Clustering import Parameters as ClusteringParameters
from Clustering.QualityMeasures import QualityMeasures as ClusteringQualityMeasures
from Clustering import DistanceMeasuring

#Dimensionnality Reduction imports
from DimensionnalityReduction import Dataset as DRDataset
from DimensionnalityReduction.Algorithms import PCA, MDS, FeatureAgglomeration
from DimensionnalityReduction.Quality import trustworthiness, continuity, neigh_hit, norm_stress, shep_corr
from DimensionnalityReduction import Pipe as DRPipe
from DimensionnalityReduction import DRClusteringPipe as DRCPipe
from DimensionnalityReduction.Algorithms import Algorithms as DRAlgorithms
from DimensionnalityReduction.Quality import QualityMeasures as DRQualityMeasuresFile
from DimensionnalityReduction import Parameters as DRParametersFile

#Network imports
from Networks import Dataset as NetworkDataset
from Networks.NodeMeasures import NodeMeasures
from Networks.EdgeMeasures import EdgeMeasures
from Networks.Communities import Communities as CommunitiesAlgorithms
from Networks import Pipe as NetworkPipe
from sknetwork.data import house
from sknetwork.ranking import Betweenness
from sknetwork.data import house, bow_tie, karate_club, miserables, painters, hourglass, star_wars, movie_actor
import networkx as nx

#TextMining imports
from TextMining import Dataset as TextMiningDataset
from TextMining.Algorithms import VectorSpaceModel, ScikitVSM
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer

#Other imports
import csv
import os
import warnings
import numpy as np
from pandas import DataFrame
from sklearn import datasets
from sklearn import decomposition


warnings.simplefilter('ignore')




########################
########################
########################
########################
#Clustering

#distanceMeasures algorithm
distanceMeasuringAlgorithms = []
distanceMeasuringAlgorithms.append([])
distanceMeasuringAlgorithms[0].append(DistanceMeasuring.DistanceMeasuring())
distanceMeasuringAlgorithms[0].append("Euclidean distance measures")

#clusteringAlgorithms ran by the pipe
clusteringAlgorithms = ClusteringAlgorithms.Algorithms().getAllAlgorithms()


#datasets.
realDatasets = ClusteringDataset.Dataset().getAllDatasets()


#parameters
params = ClusteringParameters.Parameters().getAllParameters() 


#Quality measures
clusteringQualityMeasures = ClusteringQualityMeasures.QualityMeasures().getAllQualityMeasures() #Quality measure algorithms


#clusterings
clusterings = [] #list filled with every clusterings from each dataset
for i in range(len(realDatasets)):
    clusterings.append([])
    clusterings[i].append(realDatasets[i][0][0])
    clusterings[i].append(realDatasets[i][1])
    clusterings[i].append(realDatasets[i][0][1])



#Pipe
clusteringPipe = ClusteringPipe.ClusteringPipe() #Pipe for clustering and qualityMeasures
clusteringPipe.execute(clusterings, clusteringAlgorithms, clusteringQualityMeasures, params = params, distanceAlgorithms = distanceMeasuringAlgorithms)






########################
########################
########################
########################
#Dimensionnality Reduction

#Datasets
DRDatasets = DRDataset.Dataset().getAllDatasets()


#Algorithms
DRAlgorithms = DRAlgorithms.Algorithms().getAllAlgorithms()


#Quality Measures
DRQualityMeasures = DRQualityMeasuresFile.QualityMeasures().getAllQualityMeasures()



drPipe = DRPipe.DRPipe() #Pipe that executes DR and its quality measures
drPipe.execute(DRDatasets, DRAlgorithms, DRQualityMeasures)



DRParams = DRParametersFile.Parameters().getAllParameters()

qualityMeasuresObj = ClusteringQualityMeasures.QualityMeasures()
#QualityMeasures for both DR and clustering
qualityMeasures = []


#/!\When not using DRParams :
#qualityMeasures.append([qualityMeasuresObj.getQualityMeasure("Completeness"), qualityMeasuresObj.getQualityMeasure("Randscore")])

#/!\When using DRParams :
qualityMeasures.append(qualityMeasuresObj.getAllQualityMeasures())


qualityMeasures.append(DRQualityMeasures)


drcPipe = DRCPipe.DRCPipe() #Pipe that executes DR, quality measure of the DR and then processes a clustering pipe for each DR
drcPipe.execute(DRDatasets, DRAlgorithms, qualityMeasures, clusteringAlgorithms, params = DRParams)






########################
########################
########################
########################
#Networks



print("Networks :")

#graphs
graphs = NetworkDataset.Dataset().getAllDatasetsFromFiles()
#graphs = NetworkDataset.Dataset().getAllDatasets()

#nodeMeasures
nodeMeasures = NodeMeasures.NodeMeasures().getAllNodeMeasures()

#edgeMeasures
edgeMeasures = EdgeMeasures.EdgeMeasures().getAllEdgeMeasures()

#graph with communities
graphCommunities = CommunitiesAlgorithms.Communities().getAllCommunities()


networkPipe = NetworkPipe.NetworkPipe()
networkPipe.execute(graphs, nodeMeasures, edgeMeasures, graphCommunities)

        





########################
########################
########################
########################
#TextMining



print("TextMining :")
print("It might take a little time...")

#text mining algorithms
textMiningAlgorithms = []
textMiningAlgorithms.append([])
textMiningAlgorithms[0].append(VectorSpaceModel.VectorSpaceModel())
textMiningAlgorithms[0].append("My VSM")
textMiningAlgorithms.append([])
textMiningAlgorithms[1].append(ScikitVSM.MyScikitVSM())
textMiningAlgorithms[1].append("Scikit learn VSM")

#text matrix
wordsPerFileMatrix, wordsMap = TextMiningDataset.Dataset().getDataset()

#text mining pipe
for i in range(len(textMiningAlgorithms)):
    tfidf, fileName = textMiningAlgorithms[i][0].execute(wordsPerFileMatrix)
    tfidf = np.round(tfidf, decimals=3)
    np.savetxt("OutputData/" + fileName + ".csv", tfidf, delimiter=",", fmt='%f')
    print("Data saved in Code/OutputData/" + fileName + ".csv")






