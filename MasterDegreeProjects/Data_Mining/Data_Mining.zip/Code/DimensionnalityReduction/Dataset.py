from sklearn import datasets

class Dataset:
    def getDataset(self, datasetName):
        if (datasetName == "blobs"):
            return datasets.make_blobs(n_samples = 1000, cluster_std=0.7, n_features=20)
        elif (datasetName == "regression"):
            return datasets.make_regression(n_samples=1000, n_features=5)
        elif (datasetName == "classification"):
            return datasets.make_multilabel_classification(n_samples=1000, n_features=10, n_labels=10)
        elif (datasetName == "sCurve"):
            return datasets.make_s_curve(n_samples=1000, noise=0.0)
        print ("No such dataset type existing, try something else : blobs/circles/classification")
        return None
            
    def getAllDatasets(self): #Possible keys : blobs/regression/sCurve
        DRDatasets = []
        DRDatasets.append([])
        DRDatasets[0].append(self.getDataset("blobs"))
        DRDatasets[0].append("blobs")
        DRDatasets.append([])
        DRDatasets[1].append(self.getDataset("regression"))
        DRDatasets[1].append("regression")
        #DRDatasets.append([])
        #DRDatasets[2].append(self.getDataset("classification"))
        #DRDatasets[2].append("classification")
        DRDatasets.append([])
        DRDatasets[2].append(self.getDataset("sCurve"))
        DRDatasets[2].append("sCurve")

        return DRDatasets
        
