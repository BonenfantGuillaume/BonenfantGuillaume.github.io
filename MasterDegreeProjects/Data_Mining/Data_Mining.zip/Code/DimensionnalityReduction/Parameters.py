class Parameters:
    def getAllParameters(self):
        DRParams = []

        #blobs params
        DRParams.append([])
        DRParams[0].append([])
        DRParams[0][0].append(0.5)
        DRParams[0][0].append(15)
        DRParams[0].append([])
        DRParams[0][1].append(3)
        DRParams[0].append([])
        DRParams[0][2].append(3)

        #regression params
        DRParams.append([])
        DRParams[1].append([])
        DRParams[1][0].append(1)
        DRParams[1][0].append(20)
        DRParams[1].append([])
        DRParams[1][1].append(3)
        DRParams[1].append([])
        DRParams[1][2].append(3)

        #multi_label_classification params
        DRParams.append([])
        DRParams[2].append([])
        DRParams[2][0].append(1)
        DRParams[2][0].append(20)
        DRParams[2].append([])
        DRParams[2][1].append(3)
        DRParams[2].append([])
        DRParams[2][2].append(3)

        return DRParams
            
