from Clustering import Pipe as ClusteringPipe

class DRCPipe :
    def execute(self, datasets, algorithms, qualityMeasures, clusteringAlgorithms, **kwargs):
        pipe = ClusteringPipe.ClusteringPipe()
        params = None
        if ("params" in kwargs):
            params = kwargs["params"]
        for i in range(len(datasets)):
            clusteringsForPipe = []
            clusteringParams = []
            cpt = 0
            print("Using", datasets[i][1], "dataset :\n")
            for j in range(len(algorithms)):
                print("Algorithm :", algorithms[j][1])
                clusteringsForPipe.append([])
                clusteringsForPipe[j].append(algorithms[j][0].execute(datasets[i][0][0]))
                for k in range(len(qualityMeasures[1])):
                    if (qualityMeasures[1][k][1] == "NormalizedStress"):
                        print("NormalizedStress :", qualityMeasures[1][k][0].compute(datasets[i][0][0], clusteringsForPipe[j][0], chunk_size=2))
                    else :
                        print(qualityMeasures[1][k][1], ":", qualityMeasures[1][k][0].compute(datasets[i][0][0], clusteringsForPipe[j][0], k=20))
                clusteringsForPipe[j].append(algorithms[j][1])
                clusteringsForPipe[j].append(datasets[i][0][1])
                if (params != None):
                    clusteringParams.append(params[i])
                cpt += 1
                print()
            if (params == None):
                clusteringParams = None
            pipe.execute(clusteringsForPipe, clusteringAlgorithms, qualityMeasures[0], params = clusteringParams)
            print("\n\n")
