class DRPipe :
    def execute(self, datasets, algorithms, qualityMeasures):
        for i in range(len(datasets)):
            cpt = 0
            print("Using", datasets[i][1], "dataset :\n")
            for algo in algorithms:
                print("Algorithm :", algo[1])
                clustering = algo[0].execute(datasets[i][0][0])
                for j in range(len(qualityMeasures)):
                    if (qualityMeasures[j][1] == "NormalizedStress"):
                        print("NormalizedStress :", qualityMeasures[j][0].compute(datasets[i][0][0], clustering, chunk_size=2))
                    else :
                        print(qualityMeasures[j][1], ":", qualityMeasures[j][0].compute(datasets[i][0][0], clustering, k=20))
                cpt += 1
                print()
            print("\n\n")
            


