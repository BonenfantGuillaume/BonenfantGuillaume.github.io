from sklearn import cluster

class MyAgglo :
    #Feature Agglomeration algorithm
    def execute(self, X):
        agglo = cluster.FeatureAgglomeration(n_clusters = 2)
        return agglo.fit_transform(X)
