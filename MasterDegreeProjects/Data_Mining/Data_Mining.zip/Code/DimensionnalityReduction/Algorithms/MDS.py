from sklearn.manifold import MDS

class MyMDS :
    #MDS algorithm
    def execute(self, X):
        embedding = MDS(n_components=2)
        return embedding.fit_transform(X)
