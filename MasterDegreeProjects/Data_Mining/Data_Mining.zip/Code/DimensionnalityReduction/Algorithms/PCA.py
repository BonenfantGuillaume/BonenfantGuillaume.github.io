from sklearn import decomposition

class MyPCA :
    #PCA algorithm
    def execute(self, X):
        pca = decomposition.PCA(n_components=2)
        return pca.fit_transform(X)
