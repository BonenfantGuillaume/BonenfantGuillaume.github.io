from DimensionnalityReduction.Algorithms import PCA, MDS, FeatureAgglomeration

class Algorithms:
    def getAllAlgorithms(self):
        DRAlgorithms = []
        DRAlgorithms.append([])
        DRAlgorithms[0].append(PCA.MyPCA())
        DRAlgorithms[0].append("PCA")
        DRAlgorithms.append([])
        DRAlgorithms[1].append(FeatureAgglomeration.MyAgglo())
        DRAlgorithms[1].append("Feature Agglomeration")
        DRAlgorithms.append([])
        DRAlgorithms[2].append(MDS.MyMDS())
        DRAlgorithms[2].append("MDS")

        return DRAlgorithms
        
