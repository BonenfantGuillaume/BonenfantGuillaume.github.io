from DimensionnalityReduction.Quality import trustworthiness, continuity, neigh_hit, norm_stress, shep_corr

class QualityMeasures:
    def getAllQualityMeasures(self):
        DRQualityMeasures = []
        DRQualityMeasures.append([])
        DRQualityMeasures[0].append(norm_stress.NormalizedStress())
        DRQualityMeasures[0].append("NormalizedStress")
        DRQualityMeasures.append([])
        DRQualityMeasures[1].append(trustworthiness.Trustworthiness())
        DRQualityMeasures[1].append("Trustworthiness")
        DRQualityMeasures.append([])
        DRQualityMeasures[2].append(continuity.Continuity())
        DRQualityMeasures[2].append("Continuity")

        return DRQualityMeasures
        
