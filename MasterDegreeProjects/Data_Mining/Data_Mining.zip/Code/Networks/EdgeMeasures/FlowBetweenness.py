import networkx as nx

class MyFlowBetweenness:
    def execute(self, graph):
        G = nx.from_numpy_array(graph)
        return nx.edge_current_flow_betweenness_centrality(G)
