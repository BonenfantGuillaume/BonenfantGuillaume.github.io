from Networks.EdgeMeasures import Betweenness
from Networks.EdgeMeasures import FlowBetweenness

class EdgeMeasures:
    def getAllEdgeMeasures(self):
        edgeMeasures = []
        edgeMeasures.append([])
        edgeMeasures[0].append(Betweenness.MyBetweenness())
        edgeMeasures[0].append("Betweenness")
        edgeMeasures.append([])
        edgeMeasures[1].append(FlowBetweenness.MyFlowBetweenness())
        edgeMeasures[1].append("Flow Betweenness")
        return edgeMeasures
