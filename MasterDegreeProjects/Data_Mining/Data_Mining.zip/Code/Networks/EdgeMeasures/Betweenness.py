import networkx as nx

class MyBetweenness:
    def execute(self, graph):
        G = nx.from_numpy_array(graph)
        return nx.edge_betweenness_centrality(G)
