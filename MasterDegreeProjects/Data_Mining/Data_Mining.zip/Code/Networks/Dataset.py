import pandas as pd
from sknetwork.data import from_edge_list
from sknetwork.data import house, bow_tie, karate_club, miserables, painters, hourglass, star_wars, movie_actor

class Dataset:
    def getDatasetFromFile(self, datasetName): #Keywords : karate/les_miserables/three_communities
        graph = None
        if (datasetName == "les_miserables" or datasetName == "karate" or datasetName == "three_communities"):
            df = pd.read_csv("Networks/Data/" + datasetName + ".edgelist", sep=' ', names=['from', 'to'])
            edgelist = list(df.itertuples(index=False))

            graph = []
            graph.append(from_edge_list(edgelist, matrix_only = False))
            graph.append(datasetName)
        return graph

    def getAllDatasetsFromFiles(self):
        datasets = []
        datasets.append(self.getDatasetFromFile("les_miserables"))
        datasets.append(self.getDatasetFromFile("karate"))
        datasets.append(self.getDatasetFromFile("three_communities"))
        return datasets

    def getDataset(self, datasetName): #Keywords : karate/les_miserables/painters
        graph = None
        if (datasetName == "les_miserables"):
            graph = []
            graph.append(miserables(metadata=True))
            graph.append("les_miserables")
        elif (datasetName == "karate"):
            graph = []
            graph.append(karate_club(metadata=True))
            graph.append("karate")
        elif (datasetName == "painters"):
            graph = []
            graph.append(painters(metadata=True))
            graph.append("painters")
        return graph

    def getAllDatasets(self):
        datasets = []
        datasets.append(self.getDataset("les_miserables"))
        datasets.append(self.getDataset("karate"))
        datasets.append(self.getDataset("painters"))
        return datasets
