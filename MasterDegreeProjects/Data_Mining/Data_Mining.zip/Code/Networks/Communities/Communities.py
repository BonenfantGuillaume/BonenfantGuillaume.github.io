from Networks.Communities import Girvan
from Networks.Communities import LabelPropagation
from Networks.Communities import Louvain

class Communities:
    def getAllCommunities(self):
        graphCommunities = []
        graphCommunities.append([])
        graphCommunities[0].append(Girvan.Girvan())
        graphCommunities[0].append("Girvan")
        graphCommunities.append([])
        graphCommunities[1].append(LabelPropagation.LabelPropagation())
        graphCommunities[1].append("Label Propagation")
        graphCommunities.append([])
        graphCommunities[2].append(Louvain.Louvain())
        graphCommunities[2].append("Louvain")
        return graphCommunities
