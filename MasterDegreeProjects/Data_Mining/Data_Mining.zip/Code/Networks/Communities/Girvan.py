from networkx.algorithms.community.centrality import girvan_newman

class Girvan:
    def execute(self, G):
        return girvan_newman(G)
