from networkx.algorithms.community import label_propagation_communities

class LabelPropagation:
    def execute(self, G):
        return list(label_propagation_communities(G))
