import networkx.algorithms.community as nx_comm

class Louvain:
    def execute(self, G):
        return nx_comm.louvain_communities(G)
