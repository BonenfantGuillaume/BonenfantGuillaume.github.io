import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

class NetworkPipe :
    def execute(self, graphs, nodeMeasures, edgeMeasures, graphCommunities):
        for i in range(len(graphs)):
            print("dataset :", graphs[i][1])
            for j in range(len(nodeMeasures)):
                print("Node measure :", nodeMeasures[j][1])
                scores = nodeMeasures[j][0].execute(graphs[i][0]["adjacency"])
                scores = np.round(scores, 6)
                if ("names" in graphs[i][0]):
                    for k in range(len(scores)):
                        print(graphs[i][0]["names"][k], scores[k])
                else :
                    for k in range(len(scores)):
                        print(k, ":", scores[k])
                print()
            print()
            
            for j in range(len(edgeMeasures)):
                print("Edge measure :", edgeMeasures[j][1])
                edgeValue = edgeMeasures[j][0].execute(graphs[i][0]["adjacency"])
                if ("names" in graphs[i][0]):
                    for key in edgeValue:
                        print("(" + graphs[i][0]["names"][key[0]] + ",", graphs[i][0]["names"][key[1]] + ") :", edgeValue[key]*100)
                else :
                    for key in edgeValue:
                        print(key, ":", edgeValue[key]*100)
                print()
            print()

            G = nx.from_numpy_array(graphs[i][0]["adjacency"])
            for j in range(len(graphCommunities)):
                print("Community method :", graphCommunities[j][1])
                communities = graphCommunities[j][0].execute(G)
                node_groups = []

                if(str(type(communities)) == "<class 'generator'>"):
                    for com in next(communities):
                        node_groups.append(list(com))
                else:
                    for com in communities:
                        node_groups.append(com)

                print("Communities : ")
                for k in range(len(node_groups)):
                    print("Community", k, ":", node_groups[k])
                    
                colors = ["red", "blue", "green", "orange", "pink", "yellow", "cyan", "magenta"]
                color_map = []
                for node in G:
                    for k in range(len(node_groups)):
                        if node in node_groups[k]:
                            color_map.append(colors[k])
                nx.draw(G, node_color=color_map, with_labels=True)
                plt.show()

                print()
            print()

