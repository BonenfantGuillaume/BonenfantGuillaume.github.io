from sknetwork.ranking import PageRank

class MyPageRank:
    def execute(self, graph):
        pagerank = PageRank(damping_factor = 0.85, n_iter = 50, tol= 10e-10)
        return pagerank.fit_predict(graph)
