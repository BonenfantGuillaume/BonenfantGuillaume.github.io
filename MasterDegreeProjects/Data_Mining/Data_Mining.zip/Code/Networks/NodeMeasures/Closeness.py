from sknetwork.ranking import Closeness

class MyCloseness:
    def execute(self, graph):
        closeness = Closeness()
        return closeness.fit_predict(graph)
