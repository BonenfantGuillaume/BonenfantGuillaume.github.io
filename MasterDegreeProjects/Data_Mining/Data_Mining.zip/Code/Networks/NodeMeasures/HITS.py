from sknetwork.ranking import HITS

class MyHITS:
    def execute(self, graph):
        hits = HITS()
        return hits.fit_predict(graph)
