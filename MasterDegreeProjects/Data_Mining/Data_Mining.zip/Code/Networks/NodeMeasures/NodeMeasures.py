from Networks.NodeMeasures import PageRank as MyPagerank
from Networks.NodeMeasures import Closeness, HITS

class NodeMeasures:
    def getAllNodeMeasures(self):
        nodeMeasures = []
        nodeMeasures.append([])
        nodeMeasures[0].append(MyPagerank.MyPageRank())
        nodeMeasures[0].append("Pagerank")
        nodeMeasures.append([])
        nodeMeasures[1].append(Closeness.MyCloseness())
        nodeMeasures[1].append("Closeness")
        nodeMeasures.append([])
        nodeMeasures[2].append(HITS.MyHITS())
        nodeMeasures[2].append("HITS")
        return nodeMeasures
