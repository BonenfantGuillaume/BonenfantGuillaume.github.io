To run the program :
	- You need to install several packages :
		- Scikit learn packages
		- Scikit network packages
		- networkx
		- pandas
		- Matplotlib
	- In your console, go to the "Code" directory
	- Execute Main.py with the command : "py ./Main.py"
	- Wait for the program to execute !

That's all you need to know to execute the program !


Notes :
To make the Main file clearer, every used parameters for pipes have been created in other files. For example, for the clustering parameters, you can find all the parameters in the "Parameters" file.
You can either change the parameters you want in these files or directly write the parameters you want in the main (but it might get messy with a lot of lines just for that).
The parameters have to be in the order of the algorithms executed for the clustering.

The text mining pipe is in the main. The output is a csv-format file that you can find in the directory Code/OutputData