const express = require('express'); // définit expressJS

const bodyParser = require('body-parser'); // définit le middleware permettant de parser les données envoyées par la méthode post

const session = require('express-session'); // définit le middleware express-session

const MongoDBStore = require('connect-mongodb-session')(session);// définit le middleware connect-mongodb-session pour gérer le stockage des informations de sessions gérées par express-session

const MongoClient = require('mongodb').MongoClient; // définit le middleware mongodb à charger et crée l’instance MongoClient

// spécification du Data Source Name (DSN) de mongoDB => BD://host:port/db
const dsnMongoDB = "mongodb://pedago.univ-avignon.fr/db";

const pgClient = require('pg'); // définit le middleware pg à charger

const crypto = require('crypto'); // définit le middleware pg à charger

const app = express(); // appel à expressJS

app.use(express.static(__dirname + '/monAppliMean/dist/monAppliMean/'));

app.use(bodyParser.urlencoded({extended: true})); // Charge le middleware bodyParser dans la pile pour lire les données au format HTML (&, =, %)
app.use(bodyParser.json({limit: '10mb'})); // Charge le middleware dans la pile pour lire les données au format JSON

app.use(session({ // charge le middleware express-session dans la pile
		secret: 'ma phrase secrete',
		saveUninitialized: false, // Session créée uniquement à la première sauvegarde de données
		resave: false, // pas de session sauvegardée si pas de modif
		store : new MongoDBStore({ // instance de connect-mongodb-session
			uri: "mongodb://pedago.univ-avignon.fr/db",
			collection: 'mySession3133',
			touchAfter: 24 * 3600 // 1 sauvegarde toutes les 24h hormis si données MAJ
		}),
	cookie : {maxAge : 24 * 3600 * 1000} // millisecond valeur par défaut  { path: '/', httpOnly: true, secure: false, maxAge: null }
}));

var server=app.listen(3133, function() {  //Spécification du port d’écoute de Node pour les requêtes HTTP
console.log('listening on 3133'); // Message dans la console Node
});

app.get('/', function (request, response) { // Path, callback (fonction anonyme)
	response.sendFile(__dirname + '/monAppliMean/dist/monAppliMean/index.html')  // termine le cycle par l’envoi de la réponse  home/nas-wks01/users/uapv1902758/Donnees_itinerantes/Mes\ Documents/CERIGame/index.htm
});

app.post('/login', function (request, response) {	
	var login = request.body.Login; //récupération du login
	var pass = request.body.Pass; //récupération du mot de passe

	//récupération des informations pour l'utilisateur 'login'
	sql = "select * from fredouil.users where identifiant = '" + login + "';";

	// instance de connexion avec toutes les informations de la BD
	var pool = new pgClient.Pool({user:'uapv1902758', host: 'pedago01c.univ-avignon.fr', database: 'etd', password: 'SbPq9m', port: 5432});

	responseData = new Object(); //données renvoyées au service
	
	// Connexion à la base => objet de connexion : client
	pool.connect(function(err, client, done) {
		if(err) {console.log('Error connecting to pg server' + err.stack);} 
		else{
			console.log('Connection established with pg db server')
			
			// Exécution de la requête SQL et traitement du résultat
			client.query(sql, (err, result) => {
				//requête échouée => affichage de l'erreur
				if(err){
					console.log('Erreur d\'exécution de la requete' + err.stack);
				} 
				
				// requête réussie => traitement du résultat
				for (const row of result.rows) 
				{
					if((row != null) && (row.motpasse == crypto.createHash("sha1").update(pass).digest("hex"))){ //si la ligne possède le bon mot de passe
						request.session.isConnected = true;
						request.session.login = row.identifiant;
						responseData.data = row; //on stocke les données de l'utilisateur
						responseData.statusMsg = 'Connexion réussie : bonjour '+ row.nom;
						responseData.statusResp = true;
					}
					
					else{
						console.log('Connexion échouée : informations de connexion incorrecte'); 
						responseData.statusMsg='Connexion échouée : informations de connexion incorrecte';
					}
					
				}
				response.json(responseData);
			});
			client.release(); //connexion libérée
		}
	});
});

app.post('/modify', function (request, response) {
	console.log("modification d'une information utilisateur");
	var nouvelleModification = request.body.nouvelleModification; //valeur de la donnée à modifier
	var donneeAModifier = request.body.donneeAModifier; //donnée à modifier
	var id = request.body.id; //id de l'utilisateur
	
	if (donneeAModifier == "motpasse") // on crypte le mot de passe
	{
		nouvelleModification = crypto.createHash("sha1").update(nouvelleModification).digest("hex")
	}

	sql = "UPDATE fredouil.users set " + donneeAModifier + " = '" + nouvelleModification + "' where id = " + id + ";"; //requete sql
	console.log(sql);
	// instance de connexion avec toutes les informations de la BD
	var pool = new pgClient.Pool({user:'uapv1902758', host: 'pedago01c.univ-avignon.fr', database: 'etd', password: 'SbPq9m', port: 5432});

	responseData = new Object(); //données renvoyées au service
	
	// Connexion à la base => objet de connexion : client
	pool.connect(function(err, client, done) {
		if(err) {console.log('Error connecting to pg server' + err.stack);} 
		else{
			console.log('Connection established with pg db server');
			
			// Exécution de la requête SQL et traitement du résultat
			client.query(sql, (err, result) => {
				//requête échouée => affichage de l'erreur
				if(err){
					console.log('Erreur d\'exécution de la requete' + err.stack);
				} 
		
				// requête réussie => traitement du résultat
				else{
					responseData.statusMsg = 'Modification réussie';
					responseData.statusResp = true;
					console.log(responseData.statusMsg);
				}
				
				response.json(responseData);
			});
			client.release(); //connexion libérée
		}
	});
});


app.post('/quizz', function (request, response) {
	var req = request.body.req; //récupération de la requete
	
	responseData = new Object(); //données renvoyées au service
	responseData.statusResp = false;
					
	// Connexion MongoDB
	MongoClient.connect(dsnMongoDB, { useNewUrlParser: true, useUnifiedTopology: true }, function(err, mongoClient) {
		if(err) {return console.log('erreur connexion base de données'); }
		if(mongoClient) {
			
			if (req[0] == "theme") //si la requete concerne les thèmes
			{
				mongoClient.db().collection('quizz').find({}, {projection: { "thème": 1}}).toArray(function(err, data){ //on récupère le quizz avec les thèmes du quizzz
					if(err) return console.log('erreur base de données');
					if(data){  
						responseData.statusResp = true;
						console.log('requete ok');
						console.log(data);
						responseData.data = data; //on stocke les thèmes
						// fermeture de la connexion
						mongoClient.close();
					}
					
					response.json(responseData);
				});
			}
			
			else if (req[0] == "questions") //si la requete concerne les questions
			{
				mongoClient.db().collection('quizz').find({"thème": req[1]}, {projection: { "quizz": 1}}).toArray(function(err, data){ //on récupère le quizz avec pour thème req[1]
					if(err) return console.log('erreur base de données');
					if(data){  
						responseData.statusResp = true;
						console.log('requete ok');
						console.log(data[0]);
						responseData.data = data; //on stocke le quizz
						// fermeture de la connexion
						mongoClient.close();
					}
					
					response.json(responseData);
				});				
			}
		}
	});
	
	//response.sendFile(__dirname + '/monAppliMean/dist/monAppliMean/index.html')  // termine le cycle par l’envoi de la réponse  home/nas-wks01/users/uapv1902758/Donnees_itinerantes/Mes\ Documents/CERIGame/index.htm
});

app.post('/result', function (request, response) {
	console.log("stockage du résultat");
	
	//on stocke toutes les données pour sauvegarder un nouveau score
	var id_user = request.body.id_user;
	var date_jeu = request.body.date_jeu;
	var niveau_jeu = request.body.niveau_jeu;
	var nb_reponses_corr = request.body.nb_reponses_corr;
	var temps = request.body.temps;
	var score = request.body.score;

	//premiere requete sql pour insérer le score dans la base de donnée
	sql = "INSERT INTO fredouil.historique (id_user, date_jeu, niveau_jeu, nb_reponses_corr, temps, score) VALUES (" + id_user + ", '" + date_jeu + "', " + niveau_jeu + ", " + nb_reponses_corr + ", " + temps + ", " + score + ");"; //requete sql pour sauvegarder le score
	console.log(sql);

	//deuxieme requete sql pour vérifier si c'est un nouveau record ou non
	sql2 = "SELECT count(*) from fredouil.historique where id_user = " + id_user + " and score > " + score + ";"; //requete sql pour savoir si il y a des scores meilleurs que celui là
	console.log(sql2);

	// instance de connexion avec toutes les informations de la BD
	var pool = new pgClient.Pool({user:'uapv1902758', host: 'pedago01c.univ-avignon.fr', database: 'etd', password: '2C1ptE', port: 5432});

	responseData = new Object();
	
	// Connexion à la base => objet de connexion : client
	pool.connect(function(err, client, done) {
		if(err) {console.log('Error connecting to pg server' + err.stack);} 
		else{
			console.log('Connection established with pg db server');
			
			// Exécution de la premiere requête SQL et traitement du résultat
			client.query(sql, (err, result) => { //exécution de la premiere requete
				//requête échouée => affichage de l'erreur
				if(err){
					console.log('Erreur d\'exécution de la premiere requete' + err.stack);
				} 
		
				// requête réussie => traitement du résultat
				else{
					responseData.statusMsg = 'Ajout réussi';
					responseData.statusResp = true;
					console.log(responseData.statusMsg);
				}
				
				// Exécution de la deuxieme requête SQL et traitement du résultat
				client.query(sql2, (err2, result2) => { //execution de la deuxieme requete
					//requête échouée => affichage de l'erreur
					if(err2){
						console.log('Erreur d\'exécution de la deuxieme requete' + err2.stack);
					} 
				
					// requête réussie => traitement du résultat
					else{
						responseData.statusMsg2 = 'Vérification réussie';
						responseData.statusResp2 = true;
						responseData.counter = result2.rows[0].count; //on stocke le nombre de scores meilleurs que celui exécuté
						console.log(responseData.statusMsg2);
					}
					
					response.json(responseData);					
				});
			});
			client.release(); //connexion libérée
		}
	});
});

app.post('/top10', function (request, response) {
	console.log("TOP10");
	
	sql = "SELECT * FROM (SELECT id_user, score, identifiant, ROW_NUMBER() OVER(PARTITION BY id_user ORDER BY score DESC) rn FROM fredouil.historique JOIN fredouil.users ON fredouil.historique.id_user = fredouil.users.id) a WHERE rn = 1 ORDER BY score DESC LIMIT 10;"; //requete pour récupérer le top 10 des meilleurs joueurs de CERIGame
	console.log(sql);
	// instance de connexion avec toutes les informations de la BD
	var pool = new pgClient.Pool({user:'uapv1902758', host: 'pedago01c.univ-avignon.fr', database: 'etd', password: 'SbPq9m', port: 5432});

	responseData = new Object(); //données renvoyées au service
	
	// Connexion à la base => objet de connexion : client
	pool.connect(function(err, client, done) {
		if(err) {console.log('Error connecting to pg server' + err.stack);} 
		else{
			console.log('Connection established with pg db server')
			
			// Exécution de la requête SQL et traitement du résultat
			client.query(sql, (err, result) => {
				//requête échouée => affichage de l'erreur
				if(err){
					console.log('Erreur d\'exécution de la requete' + err.stack);
				} 
				
				else if(result != null){
					responseData.data = result.rows; //on stocke les données du top 10
					console.log(responseData.data);
					responseData.statusMsg = "Récupération du Top 10 réussie !";
					responseData.statusResp = true;
				}
				
				else{
					console.log('Récupération du Top 10 échouée !'); 
					responseData.statusMsg='Récupération du Top 10 échouée !';
				}
					
				response.json(responseData);
			});
			client.release(); //connexion libérée
		}
	});
});


app.post('/historique', function (request, response) {
	console.log("affichage historique");
	
	var id_user = request.body.id_user;
	
	//requete sql pour récupérer l'historique utilisateur
	sql = "SELECT * from fredouil.historique where id_user = " + id_user + " order by score DESC;";
	console.log(sql);

	// instance de connexion avec toutes les informations de la BD
	var pool = new pgClient.Pool({user:'uapv1902758', host: 'pedago01c.univ-avignon.fr', database: 'etd', password: 'SbPq9m', port: 5432});

	responseData = new Object();
	
	// Connexion à la base => objet de connexion : client
	pool.connect(function(err, client, done) {
		if(err) {console.log('Error connecting to pg server' + err.stack);} 
		else{
			console.log('Connection established with pg db server');
			
			// Exécution de la requête SQL et traitement du résultat
			client.query(sql, (err, result) => { //exécution de la premiere requete
				//requête échouée => affichage de l'erreur
				if(err){
					console.log('Erreur d\'exécution de la premiere requete' + err.stack);
				} 
		
				// requête réussie => traitement du résultat
				else{
					responseData.statusMsg = 'Récupération historique réussie';
					responseData.statusResp = true;
					responseData.data = result.rows;
					console.log("result.rows : " + result.rows[0]);
					console.log(responseData.statusMsg);
				}
				
				response.json(responseData);					
			});
			client.release(); //connexion libérée
		}
	});
});
