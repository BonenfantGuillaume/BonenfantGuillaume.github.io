import { Component, OnInit } from '@angular/core';

import { Input, Output, EventEmitter } from '@angular/core'; // déclaration des modules Input Output EventEmitter

@Component({
  selector: 'app-quizz-header',
  templateUrl: './quizz-header.component.html',
  styleUrls: ['./quizz-header.component.css']
})

export class QuizzHeaderComponent implements OnInit {
	@Input() public seen : boolean; //si la notification a été vue
	@Input() public notification : boolean;  //si il y a une notification
	public message : string; //message de la notification

	constructor() { 
		this.seen = false;
		this.notification = false;
		this.message = "";
	}
	
	ngOnInit(): void {
	}

	isConnected(): string { //renvoie un booleen indiquant si l'utilisateur est connecté
		return (localStorage.getItem('isConnected') || "");
	}

	//Pour envoyer le message et les notifications au Body
	@Output() newMessageEvent = new EventEmitter<string>();
	@Output() newSeenEvent = new EventEmitter<boolean>();

	newMessage(messageSent: string): void { //Un message de nottification arrive !
		this.message = messageSent; //message recu
		this.notification = true; //notification recue
		this.seen = false; //notification pas encore vue
		this.newMessageEvent.emit(this.message); //envoie du message au Body
	}
	
	notificationSeen(): void { //notification vue
		this.seen = true; //notification vue
		this.notification = false; //plus de notification à voir
		
		this.newSeenEvent.emit();// envoie de la vue de la notification au Body
	}

}
