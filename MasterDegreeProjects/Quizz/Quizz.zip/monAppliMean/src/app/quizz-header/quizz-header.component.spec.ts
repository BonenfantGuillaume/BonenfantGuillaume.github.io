import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizzHeaderComponent } from './quizz-header.component';

describe('QuizzHeaderComponent', () => {
  let component: QuizzHeaderComponent;
  let fixture: ComponentFixture<QuizzHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuizzHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuizzHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
