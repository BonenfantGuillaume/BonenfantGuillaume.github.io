import { Component, OnInit } from '@angular/core';

import { ModificationService } from '../modification.service';
import { HistoriqueService } from '../historique.service';

import { HttpClientModule } from '@angular/common/http';

import { Output, EventEmitter } from '@angular/core'; // déclaration des modules Output EventEmitter

import { Global } from '../global';

@Component({
  selector: 'app-quizz-profile',
  templateUrl: './quizz-profile.component.html',
  styleUrls: ['./quizz-profile.component.css']
})

export class QuizzProfileComponent implements OnInit {
	//toutes les données que l'on utilise pour l'affichage du profil
	public prenom : string;
	public nom : string;
	public naissance : string;
	public identifiant : string;
	public humeur : string;
	public avatar : string;
	
	public historiqueDisplayed : boolean;
	public modification : boolean;
	public modificationAvatar : boolean;
	public modificationHumeur : boolean;
	public modificationPass : boolean;
	public nouvelAvatar : string; //valeur de la modification
	public nouvelleHumeur : string; //valeur de la modification
	public nouveauPasse : string; //valeur de la modification
	
	public historique : string[][] = []; //historique des parties
	
	constructor(public _mod : ModificationService, public _hist : HistoriqueService, public _VarGlob : Global) {
		//récupération des données locales de connexion
		this.prenom = (localStorage.getItem('prenom') || "");
		this.nom = (localStorage.getItem('nom') || "");
		this.naissance = (localStorage.getItem('naissance') || "");
		this.identifiant = (localStorage.getItem('identifiant') || "");
		this.humeur = (localStorage.getItem('humeur') || "");
		this.avatar = (localStorage.getItem('avatar') || "");

		//gérer les modifications de profil
		this.historiqueDisplayed = false;
		this.modification = false;
		this.modificationAvatar = false;
		this.modificationHumeur = false;
		this.modificationPass = false;
		this.nouvelAvatar = "";
		this.nouvelleHumeur = "";
		this.nouveauPasse = "";
		setTimeout(() => {this.historiqueRequest()}, 1000);
	}
	
	ngOnInit(): void {
	}

	clear(): void {
		localStorage.clear();
		this.newMessageEvent.emit("Déconnexion réussie, Au revoir !");
	}
	
	changeModification(): void{ //apparaitre/disparaitre la modification du profil
		this.modification = !this.modification;
	}

	changeHistorique(): void{ //apparaitre/disparaitre l'historique
		this.historiqueDisplayed = !this.historiqueDisplayed;
	}
	
	changeModificationSelect(event: any){ //savoir quel paramètre est modifié
		this.modificationAvatar = false;
		this.modificationHumeur = false;
		this.modificationPass = false;
		
		switch (event.value) {
			case "Avatar" :
				this.modificationAvatar = true;
				break;
			case "Humeur" :
				this.modificationHumeur = true;
				break;
			case "Pass" :
				this.modificationPass = true;
				break;
		}
	}
	
	@Output() newMessageEvent = new EventEmitter<string>();

	//fonction pour modifier le profil
	ModifyProfile(donneeAModifier: string): void {
		var nouvelleModification : string = "";
		switch (donneeAModifier) {
			case "avatar" : 
				nouvelleModification = this.nouvelAvatar;
				break;
			case "humeur" : 
				nouvelleModification = this.nouvelleHumeur;
				break;
			case "motpasse" : 
				nouvelleModification = this.nouveauPasse;
				break;
		}
		
		var id_user : number = (Number(localStorage.getItem('id')) || -1)
		if (nouvelleModification != "" && id_user != -1) //si l'utilisateur est connecté
		{
			this._mod.ModifyProfile(nouvelleModification, donneeAModifier).subscribe( //appel du service pour modifier le profil
				data => {
					this._VarGlob.isModified = data; //récupère le booléen du service modification, vrai si la personne a été correctement modifiée
					
					if(this._VarGlob.isModified == true){ //si la personne a été modifiée correctement
						//envoie du message de notification
						switch (donneeAModifier) {
							case "avatar" :
								this.newMessageEvent.emit("Modification réussie : Vous avez un nouvel avatar !");
								this.avatar = nouvelleModification;
								break;
							case "humeur" :
								this.newMessageEvent.emit("Modification réussie : Vous avez une nouvelle humeur !");
								this.humeur = nouvelleModification;
								break;
							case "motpasse" :
								this.newMessageEvent.emit("Modification réussie : Vous avez un nouveau mot de passe !");
								break;
						}
					}
					else //si la personne n'a pas été modifié correctement
					{
						this.newMessageEvent.emit("Modification échouée !");// envoie du message d'échec				
					}
				},
				
				error => {
				}
			);
		}
	}

	//fonction pour récupérer l'historique du joueur
	historiqueRequest(): void {
		var id_user : number = (Number(localStorage.getItem('id')) || -1)
		if (id_user != -1)
		{
			this._hist.historiqueRequest(id_user).subscribe(
				data => {
					if(data){ //si l'historique a été chargé correctement
						let dataReceived2 : any = this._VarGlob.historique; //réception des données
						
						for (const singleHist of dataReceived2)
						{
							singleHist.date_jeu = singleHist.date_jeu.replace("T", " ").replace("Z", ""); //réception et mise en forme de la date de jeu
							this.historique.push([singleHist.date_jeu, singleHist.niveau_jeu, singleHist.nb_reponses_corr, singleHist.temps, singleHist.score]); //ajout à la liste historique
						}
					}
					else //si l'historique n'a pas pu être chargé correctement
					{
						//do nothing
					}
				},
				
				error => {
				}
			);
		}
	}
}
