import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizzProfileComponent } from './quizz-profile.component';

describe('QuizzProfileComponent', () => {
  let component: QuizzProfileComponent;
  let fixture: ComponentFixture<QuizzProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuizzProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuizzProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
