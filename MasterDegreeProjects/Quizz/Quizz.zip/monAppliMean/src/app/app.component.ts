//Utilisation d'un service
import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
	title = 'CERIgame';

	public notification: boolean; //nouvelle notification ou non
	public seen: boolean; //notification vue ou non
	public message: string; //message de la notification
	
	constructor() { 
		//pas de notification par défaut
		this.notification = false;
		this.seen = false;
		this.message = "";
	}
	
  	newMessage(messageSent: string): void { //Un message de nottification arrive !
		this.message = messageSent; //message recu
		this.notification = true; //notification recue
		this.seen = false; //notification pas encore vue
	}
	
	notificationSeen(): void { //notification vue
		this.seen = true; //notification vue
		this.notification = false; //plus de notification à voir
	}
}

