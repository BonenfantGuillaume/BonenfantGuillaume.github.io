import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

@Injectable()
export class Global {
	isLogged = new Object();
	isModified = new Object();
	login = new Object();
	data = new Object();
	topTen: string[][] = [];
	betterScores: number = 1;
	historique = new Object();
}