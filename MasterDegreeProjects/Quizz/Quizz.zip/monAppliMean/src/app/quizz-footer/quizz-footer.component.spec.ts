import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizzFooterComponent } from './quizz-footer.component';

describe('QuizzFooterComponent', () => {
  let component: QuizzFooterComponent;
  let fixture: ComponentFixture<QuizzFooterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuizzFooterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuizzFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
