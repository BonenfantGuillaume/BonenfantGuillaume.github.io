import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quizz-footer',
  templateUrl: './quizz-footer.component.html',
  styleUrls: ['./quizz-footer.component.css']
})
export class QuizzFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
