import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError, Subscriber } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

@Injectable()
export class AuthentificationService{

	constructor(private _http: HttpClient) { 
	
	}

	//Tester la connexion de l'utilisateur
	IsLogged() : boolean {
		if(localStorage.getItem('isConnected') == 'true')
			return true;
		else
			return false;
	};
	
	// la méthode renvoie un observable principal et un booléen en données
	//fonction permettant de connecter l'utilisateur
	VerifyId(user : string, password : string) : Observable<boolean> {
		var trueId : boolean = false;
		
		// la méthode renvoie un observable et un booléen en données
		return Observable.create((observer: Subscriber<boolean>) => {
			this._http.post<any>('http://pedago.univ-avignon.fr:3133/login/',{Login : user, Pass : password}).subscribe( //connexion à la page login
				data => { // succes de l’observable httpClient, de la connexion à login
					if(data.statusResp){ //si la connexion a réussi
						//on stocke toutes les données de l'utilisateur en local
						localStorage.setItem('isConnected', 'true');
						localStorage.setItem('identifiant', data.data.identifiant);
						localStorage.setItem('nom', data.data.nom);
						localStorage.setItem('prenom', data.data.prenom);
						localStorage.setItem('naissance', data.data.date_naissance.replace("T", " ").replace("Z", ""));
						localStorage.setItem('avatar', data.data.avatar);
						localStorage.setItem('humeur', data.data.humeur);
						localStorage.setItem('statut', data.data.statut_connexion);
						localStorage.setItem('id', data.data.id);
						trueId = true; //connexion réussie
					}
					else{
						trueId = false; //connexion échouée
					}
				},
				
				error => {// erreur de l’observable httpClient
					console.error('une erreur est survenue!', error);
					trueId = false;
				},
				() => {// terminaison de l’observable httpClient
					observer.next(trueId); // renvoi des données pour l’observable principal
				}
			);
		});
	}
}