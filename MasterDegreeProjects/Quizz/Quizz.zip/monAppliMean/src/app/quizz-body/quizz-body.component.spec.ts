import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizzBodyComponent } from './quizz-body.component';

describe('QuizzBodyComponent', () => {
  let component: QuizzBodyComponent;
  let fixture: ComponentFixture<QuizzBodyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuizzBodyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuizzBodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
