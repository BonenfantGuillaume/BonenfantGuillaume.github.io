import { Component, OnInit } from '@angular/core';

import { Input } from '@angular/core';

import { MongoRequestService } from '../mongo-request.service'; //service pour envoyer une requete pour récupérer les thèmes et les questions
import { AjoutScoreService } from '../ajout-score.service'; //service pour ajouter un score et regarder si c'est un nouveau record
import { ToptenService } from '../topten.service'; //service pour récupérer le top10 de joueurs

import { HttpClientModule } from '@angular/common/http';

import { Output, EventEmitter } from '@angular/core'; // déclaration des modules Output EventEmitter

import { Global } from '../global';

@Component({
  selector: 'app-quizz-body',
  templateUrl: './quizz-body.component.html',
  styleUrls: ['./quizz-body.component.css']
})

export class QuizzBodyComponent implements OnInit {
	
	@Input() notification: boolean; //notification recue
	@Input() seen: boolean; //notification vue
	@Input() message: string; //message de notification
	themes: string[] = []; //récupération des thèmes
	part: string; //variable qui sert à savoir où on en est dans l'exécution du quizz
	chosenTheme: string; //thème choisi par l'utilisateur
	chosenDifficulty: string; //difficulté choisie par l'utilisateur
	nbrAnswers: number; //nombre de réponses (dépend de la difficulté choisie)
	questions: string[] = []; //questions qui correspondent au thème
	answers: string[][] = []; //réponses possibles pour chaque question
	rightAnswer: string[] = []; //réponses correctes pour chaque question 
	anecdotes: string[] = []; //anecdote sur la question
	questionIndexes: number[] = []; //les numéros des questions qui sont choisies (aléatoirement)
	displayedAnswers: string[] = []; //les réponses à afficher, choisies aléatoirement, entre 2 et 4 en fonction de la difficulté
	userAnswers: string[] = [];	//réponses choisies par l'utilisateur
	numeroQuestion: number; //numero de la question actuelle
	nbrQuestions: number; //nombre de questions en tout (10)
	userRightAnswers: number; //nombre de bonnes réponses données par l'utilisateur
	timeTaken: number; //temps pris par l'utilisateur pour faire le quizz, en secondes
	scoreFinal: number; //score final de l'utilisateur
	topTen: string[][] = []; //top10 des meilleurs joueurs de CERIGame et leur score
	betterScores: number; //nombre de scores meilleurs que celui qui vient d'etre réalisé (utile pour savoir si c'est un nouveau record)

	//initialisation de toutes les variables
	constructor(public _req : MongoRequestService, public _VarGlob : Global, public _ajout : AjoutScoreService, public _top : ToptenService) { 
		this.notification = false;
		this.seen = false;
		this.message = '';
		this.part = "jouer"; //pour proposer à l'utilisateur de jouer
		this.chosenTheme = '';
		this.chosenDifficulty = '';
		this.nbrQuestions = 0;
		this.nbrAnswers = 0;
		this.numeroQuestion = 0;
		this.userRightAnswers = 0;
		this.timeTaken = 0;
		this.scoreFinal = 0;
		this.topTenRequest(); //on initialise le top 10
		this.betterScores = 1;
	}

	ngOnInit(): void {
	}
	
	choseTheme(req: string): void {
		let reqToSend: string[] = [req]; //on transforme en un tableau de string car cela permet de factoriser le service de requetes
		this.sendRequest(reqToSend); //envoie de la requete
	}
	
	chosenThemeFct(event: any){
		this.chosenTheme = event.value; //variable qui récupère le thème choisi par l'utilisateur (communique avec le front-end)
	}
	
	choseDifficulty(): void {
		if(this.chosenTheme != '' && this.chosenTheme != "Thème")
		{
			this.part = "difficulté"; //on passe au choix de la difficulté
		}
	}
	
	startQuizz(difficulty: string): void {
		this.chosenDifficulty = difficulty;
		switch (this.chosenDifficulty) {
			case "facile":
				this.nbrAnswers = 2; //2 réponses en facile
				this.displayedAnswers = ["", ""]; //2 réponses à afficher
				break;
			case "moyen":
				this.nbrAnswers = 3; //3 réponses en moyen
				this.displayedAnswers = ["", "", ""]; //3 réponses à afficher
				break;
			case "difficile":
				this.nbrAnswers = 4; //4 réponses en difficile
				this.displayedAnswers = ["", "", "", ""]; //4 réponses à afficher
				break;
		}

		let reqToSend: string[] = ["questions", this.chosenTheme]; //on prépare la requête à envoyer
		this.sendRequest(reqToSend); //on envoie une requête pour récupérer les questions du thème sauvegardé
	}
	
	sendRequest(req: string[]): void {
		let dataReceived : any; //réception des données
		
		this._req.sendRequest(req).subscribe(//envoie de la rquete
			data => { //on récupère les informations du service
				
				if(data){ //si la personne s'est connectée correctement
					//do things
					dataReceived = this._VarGlob.data; //on récupère les données
					if (req[0] == "theme") //si la requête concerne le thème
					{
						for (var i = 0; i < dataReceived.data.length; i++)
						{
							this.themes.push(dataReceived.data[i]["thème"]); //on récupère tous les thèmes
						}
						this.part = "themes"; // on affiche le choix du thème à l'utilisateur
					}
					else if (req[0] == "questions") //si la requête concerne les questions
					{
						for (var i = 0; i < dataReceived.data[0]["quizz"].length; i++)
						{
							this.questions.push(dataReceived.data[0]["quizz"][i]["question"]); //on récupère toutes les questions
							this.answers.push(dataReceived.data[0]["quizz"][i]["propositions"]); //on récupère toutes les réponses
							this.rightAnswer.push(dataReceived.data[0]["quizz"][i]["réponse"]); //on récupère toutes les bonnes réponses
							this.anecdotes.push(dataReceived.data[0]["quizz"][i]["anecdote"]); //on récupère toutes les anecdotes
						}
						this.preparingQuestions(); //on prépare les questions
						this.nouvelleQuestion(); //on prépare la première question
						this.part = "start"; //affichage de lancement du quizz imménent !
						setTimeout(() => {this.part = "quizz"}, 3000); //on commence le quizz après 3 secondes
						setTimeout(() => {this.timer()}, 4000); //on lance le timer 4 secondes après pour que tout soit bien initialisé
					}
				}
				else //si la personne ne s'est pas connectée correctement
				{
					//do nothing
				}
			},
			
			error => {
			}
		);
	}
	
	public preparingQuestions(): void {
		this.nbrQuestions = 5; //nombre minimum de questions
		
		if(this.questions.length >= 10) //si il y a + de 10 questions
		{
			this.nbrQuestions = 10;
		}
				
		var i = 0;
		while (i != this.nbrQuestions) //tant qu'il n'y a pas le bon nombre de questions nécessaires pour le quizz
		{
			var qtTaken = Math.floor(Math.random() * (this.questions.length)); //on choisie une question aléatoire sur toutes celles récupérées
			//alert(qtTaken);
			if (!this.questionIndexes.includes(qtTaken)) //si la question n'est pas déjà choisie
			{
				this.questionIndexes.push(qtTaken); //on rajoute l'index de la question choisie
				i++; //on incrémente i
			}
		}
	}
	
	public nouvelleQuestion(): void {
		var placementBonneReponse = Math.floor(Math.random() * (this.nbrAnswers)); //on donne une place aléatoire à la bonne réponse
		this.displayedAnswers[placementBonneReponse] = this.rightAnswer[this.questionIndexes[this.numeroQuestion]]; //on place la bonne réponse
		
		var i = 0; //place de l'affichage
		while (i < this.nbrAnswers) //i correspond à une place pour la question
		{
			if (i == placementBonneReponse) //si la place est celle de la bonne réponse
			{
				i++; //on incrémente i
			}
			else //sinon
			{
				var answerTaken = Math.floor(Math.random() * (this.nbrAnswers)); //on choisit une réponse aléatoire
				while (this.displayedAnswers.includes(this.answers[this.questionIndexes[this.numeroQuestion]][answerTaken])) //tant que la question choisie a déjà été stockée
				{
					answerTaken = Math.floor(Math.random() * (this.nbrAnswers)); //on récupère une autre réponse
				}
				this.displayedAnswers[i] = this.answers[this.questionIndexes[this.numeroQuestion]][answerTaken]; //on récupère la réponse à afficher
				i++; // on incrémente i
			}
		}
	}
	
	public questionSuivante(chosenAnswer: number): void { //choix de la prochaine question
		this.userAnswers.push(this.displayedAnswers[chosenAnswer]); //on stocke la réponse de l'utilisateur
		if(this.userAnswers.length < this.nbrQuestions) //si l'utilisateur n'est pas encore arrivé à sa 10ème question
		{
			this.numeroQuestion++; //on incrémente le numéro de la question
			this.nouvelleQuestion(); //on choisit une nouvelle question
		}
		else
		{
			this.endOfQuizz(); //sinon on finit le quizz
		}
	}
	
	public endOfQuizz(): void { //fin du quizz
		this.calculerResultat(); //on calcule le résultat de l'utilisateur
		this.part = "resultats"; //on affiche le résultat à l'utilisateur
		this.ajoutScore(); //on ajoute le score de l'utilisateur à la base de données et on récupère si son score est un nouveau record
		this.notification = true; //On notifie l'utilisateur de son nouveau score
		this.seen = false; //L'utilisateur n'a pas encore vu cette notification
		if (this.betterScores == 0) //si il n'a jamais fait un meilleur score que celui qui vient d'etre fait
		{
			this.message = "Vous avez battu votre record avec un score de " + this.scoreFinal + " points et " + this.userRightAnswers + "/" + this.nbrQuestions + " bonnes réponses en " + this.timeTaken + " secondes ! Félicitations !"; //on prépare le message de notification à envoyer
		}
		else //si il a déjà fait un ou des scores supérieurs ou égaux à celui-ci
		{
			this.message = "Vous avez trouvé " + this.userRightAnswers + "/" + this.nbrQuestions + " bonnes réponses en " + this.timeTaken + " secondes !\n"
			+ "Votre score final est de " + this.scoreFinal + " points."; //On prépare le message de notification à envoyer
		}
		this.newNotification(this.message); //ajout de la nouvelle notification
	}
	
	public calculerResultat(): void {
		for (var i = 0; i < this.nbrQuestions; i++) //pour chaque question
		{
			if (this.userAnswers[i] == this.rightAnswer[this.questionIndexes[i]]) //si l'utilisateur a choisi la bonne réponse
			{
				this.userRightAnswers++; //on incrémente son nombe de bonnes réponses
			}
		}
		
		//Math.pow(bonnes réponses, 2) * 1 ou 2 ou 4 en fonction de la difficulté * 2.6 - secondes écoulées
		//On vérifie la difficulté choisie. Si c'est facile, on multiplie le score final par 1, si c'est moyen par 2, si c'est difficile par 4. On encourage de cette façon l'utilisateur à augmenter la difficulté.
		//Je mets le nombre de réponses puissance 2 car c'est une bonne puissance pour encourager l'utilisateur à faire en priorité des bonnes réponses plutôt qu'à se précipiter. De cette façon, cela crée également une différence conséquente entre trouver 9 bonnes réponses plutôt que 10 ! En effet, la différence entre un bon joueur et un joueur moyen se joue dans la dernière question souvent cruciale !
		//Le multiplicateur 2.6 est là pour que l'utilisateur ait 1000 points s'il trouve toutes les bonnes réponses en 40 secondes en difficulté maximale.
		//On soustrait à la fin par le nombre de secondes écoulées, une façon de ne pas trop pénaliser qqun qui prend du temps.
		if(this.chosenDifficulty == "facile")
		{
			this.scoreFinal = Math.floor(Math.pow(this.userRightAnswers, 2)*1*2.6-this.timeTaken); //stockage du score final
		}
		if(this.chosenDifficulty == "moyen")
		{
			this.scoreFinal = Math.floor(Math.pow(this.userRightAnswers, 2)*2*2.6-this.timeTaken); //stockage du score final
		}
		if(this.chosenDifficulty == "difficile")
		{
			this.scoreFinal = Math.floor(Math.pow(this.userRightAnswers, 2)*4*2.6-this.timeTaken); //stockage du score final
		}
	}
	

	
	ajoutScore(): void {
		var userId = Number((localStorage.getItem('id') || -1)); //on récupère l'id de l'utilisateur qui a fait le score
		if (userId != -1) //si l'utilisateur est bien connecté
		{
			const today: Date = new Date(); //récupération de la date actuelle
			var dateAsString = today.getDate() + "/" + (today.getMonth()+1) + "/" + today.getFullYear() + " " + (today.getHours()<10?'0':'') + today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes();
			var niveauJeu = 0;
			switch (this.chosenDifficulty) { //récupération du niveau de difficulté
				case "facile":
					niveauJeu = 1;
					break;
				case "moyen":
					niveauJeu = 2;
					break;
				case "difficile":
					niveauJeu = 3;
					break;
			}
			
			this._ajout.ajoutScore(userId, dateAsString, niveauJeu, this.userRightAnswers, this.timeTaken, this.scoreFinal).subscribe( //envoie de la requête pour sauvegarder le score et récupérer si c'est un nouveau record pour l'utilisateur
				data => {
					
					if(data){ //si le score est un nouveau record
						//do things
						this.betterScores = this._VarGlob.betterScores;
					}
					else //si ce n'est pas un nouveau record
					{
						//do nothing
					}
				},
				
				error => {
				}
			);
		}
	}
	
	@Output() newNotificationEvent = new EventEmitter<string>(); //emetteur de notification
	
	newNotification(mess: string) {
		this.newNotificationEvent.emit(mess); //émission de notification pour que le header soit modifié en conséquences
	}
	
	public rejouer(str: string) { //on réinitialise toutes les variables pour rejouer
		this.nbrQuestions = 0;
		this.nbrAnswers = 0;
		this.numeroQuestion = 0;
		this.userRightAnswers = 0;
		this.timeTaken = 0;
		this.scoreFinal = 0;
		this.choseTheme(str);
		this.questions = [];
		this.answers = [];
		this.rightAnswer = [];
		this.anecdotes = [];
		this.questionIndexes = [];
		this.displayedAnswers = [];
		this.userAnswers = [];	
		this.themes = [];
		this.betterScores = 1;
	}
	
	
	//Topten
	topTenRequest(): void { //requete pour récupérer le top 10 des meilleurs joueurs
		this._top.topTenRequest().subscribe(
			data => {
				
				if(data){ //si le top 10 a été récupéré correctement
					//do things
				}
				else //sinon
				{
					//do nothing
				}
				
				this.topTen = this._VarGlob.topTen; //récupération du top 10
			},
			
			error => {
			}
		);
	}	
	
	
	
	//timer
	//fin du fichier
	/////////////////////////
	public timer(): void {
		//récupération de la balise à modifier le texte
		let timeDisplayed: HTMLElement = document.getElementById('timer') as HTMLElement;

		//récupération des boutons pour savoir lorsque l'utilisateur a choisi une réponse (potentiellement la dernière où il faut arrêter le chronomètre)
		let stop1: HTMLElement = document.getElementById('stop1') as HTMLElement;
		let stop2: HTMLElement = document.getElementById('stop2') as HTMLElement;
		let stop3: HTMLElement = document.getElementById('stop3') as HTMLElement;
		let stop4: HTMLElement = document.getElementById('stop4') as HTMLElement;

		//récupération de "this" actuel
		let self = this;

		//variables de temps à afficher
		var sec = 1;
		var min = 0;
		var hrs = 0;
		let t: any;

		function tick(){ //incrémentation d'une seconde
			sec++; //incrémentation d'une seconde
			if (sec == 60) { //si cela fait 1 minute
				sec = 0; //on remet les secondes à 0
				min++; //on augmente le minutes
				if (min == 60) { //si cela fait 1 heure
					min = 0; //on remet les minutes à 0
					hrs++; //on incrémente l'heure
				}
			}
		}
		
		function add() { //incrémentation d'une seconde et affichage
			tick(); //incrémentation d'une seconde
			if (timeDisplayed != null) //on affiche le temps
			{
				timeDisplayed.textContent = (hrs > 9 ? hrs : "0" + hrs) 
						 + ":" + (min > 9 ? min : "0" + min)
						 + ":" + (sec > 9 ? sec : "0" + sec);
			}
			repeat(); //on recommence le processus
		}
		
		function repeat() { //processus d'incrémentation d'une seconde
			timeDisplayed = document.getElementById('timer') as HTMLElement; //on afiche le temps écoulé
			t = setTimeout(add, 1000); //au bout d'une seconde on incrémente le temps
			self.timeTaken = hrs * 3600 + min * 60 + sec; //on actualise le temps pour le composant lui même
		}

		function stopChronometer() { //potentiel arrêt du chronomètre
			if (self.userAnswers.length == self.nbrQuestions) //si l'utilisateur a autant de réponses qu'il n'y a de questions en tout dans le quizz
			{
				clearTimeout(t); //on arrête le chronomètre
			}			
		}
		
		//on commence le chronomètre
		repeat();
		
		//code non factorisé, j'ai eu des problèmes en essayant de récupérer les 4 boutons en une seule variable sous forme de tableau
		//lorsque l'on clique sur un bouton, on regarde si il faut arrêter le chronomètre
		stop1.onclick = function() {
			stopChronometer();
		}
		stop2.onclick = function() {
			stopChronometer();
		}
		stop3.onclick = function() {
			stopChronometer();
		}
		stop4.onclick = function() {
			stopChronometer();
		}
	}
}
