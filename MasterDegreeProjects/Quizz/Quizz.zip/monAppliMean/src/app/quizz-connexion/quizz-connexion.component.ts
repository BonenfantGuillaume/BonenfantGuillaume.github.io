import { Component, OnInit } from '@angular/core';

import { AuthentificationService } from '../authentification.service';

import { HttpClientModule } from '@angular/common/http';

import { Output, EventEmitter } from '@angular/core'; // déclaration des modules Output EventEmitter

import { Global } from '../global';

@Component({
  selector: 'app-quizz-connexion',
  templateUrl: './quizz-connexion.component.html',
  styleUrls: ['./quizz-connexion.component.css']
})

export class QuizzConnexionComponent implements OnInit {

	public username : string; //identifiant de l'utilisateur
	public password : string; //mot de passe de l'utilisateur
	
	constructor( public _auth : AuthentificationService, public _VarGlob : Global) { //Injection du service dans le constructeur du composant
		this.username = "";
		this.password = "";
	}
	
	ngOnInit(): void {
	}

	@Output() newMessageEvent = new EventEmitter<string>();
	
	VerifyId(): void {
		this._auth.VerifyId(this.username, this.password).subscribe(
			data => {
				this._VarGlob.isLogged = data; //récupère le booléen du service authentification, vrai si la personne s'est correctement connectée
				
				if(this._VarGlob.isLogged == true){ //si la personne s'est connectée correctement
					this._VarGlob.login = this.username;
					const today: Date = new Date(); //récupération de la date actuelle
					var lastConnexion = today.getDate() + "/" + (today.getMonth()+1) + "/" + today.getFullYear() + " " + (today.getHours()<10?'0':'') + today.getHours() + ":" + (today.getMinutes()<10?'0':'') + today.getMinutes();
					localStorage.setItem('derniereConnexion', lastConnexion);
					
					//envoie du message de notification
					this.newMessageEvent.emit("Connexion réussie : bonjour " + this.username + "\ndernière connexion : " + lastConnexion);
				}
				else //si la personne ne s'est pas connectée correctement
				{
					this.newMessageEvent.emit("Connexion échouée !");// envoie du message d'échec				
				}
			},
			
			error => {
			}
		);
	}
	
}