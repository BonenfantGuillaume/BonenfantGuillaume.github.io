import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizzConnexionComponent } from './quizz-connexion.component';

describe('QuizzConnexionComponent', () => {
  let component: QuizzConnexionComponent;
  let fixture: ComponentFixture<QuizzConnexionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuizzConnexionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuizzConnexionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
