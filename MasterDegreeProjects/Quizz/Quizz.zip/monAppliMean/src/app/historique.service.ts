import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError, Subscriber } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Global } from './global';

@Injectable({
  providedIn: 'root'
})

export class HistoriqueService {

	constructor(private _http: HttpClient, public _VarGlob : Global) { 
	
	}
  
	// la méthode renvoie un observable principal et un booléen en données
	//fonction permettant la récupération de l'historique des parties de l'utilisateur
	historiqueRequest(id_user: number) : Observable<boolean> {
		var hasWorked : boolean = false;
		// la méthode renvoie un observable et un booléen en données
		return Observable.create((observer: Subscriber<boolean>) => {
			this._http.post<any>('http://pedago.univ-avignon.fr:3133/historique/',{id_user: id_user}).subscribe( //connexion à la page historique
				data => { // succes de l’observable httpClient, de la connexion à historique
					if(data.statusResp){ //si la récupération a réussi
						hasWorked = true; //récupération réussie
						
						this._VarGlob.historique = data.data;						
					}
					else{
						hasWorked = false; //récupération échouée
					}
				},
				
				error => {// erreur de l’observable httpClient
					console.error('une erreur est survenue!', error);
					hasWorked = false;
				},
				() => {// terminaison de l’observable httpClient
					observer.next(hasWorked); // renvoi des données pour l’observable principal
				}
			);
		});
	}
}
