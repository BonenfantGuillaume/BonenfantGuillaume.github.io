import { TestBed } from '@angular/core/testing';

import { AjoutScoreService } from './ajout-score.service';

describe('AjoutScoreService', () => {
  let service: AjoutScoreService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AjoutScoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
