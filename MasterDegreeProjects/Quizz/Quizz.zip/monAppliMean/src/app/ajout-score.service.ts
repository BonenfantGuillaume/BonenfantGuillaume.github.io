import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError, Subscriber } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Global } from './global';

@Injectable({
  providedIn: 'root'
})

@Injectable()
export class AjoutScoreService {

	constructor(private _http: HttpClient, public _VarGlob : Global) { 
		
	}
	
	
	// la méthode renvoie un observable principal et un booléen en données
	//fonction permettant d'ajouter le score à la base de donnée et de récupérer le nombre de scores meilleurs que celui qui vient d'être fait
	ajoutScore(id_user: number, date_jeu: string, niveau_jeu: number, nb_reponses_corr: number, temps: number, score: number) : Observable<boolean> {
		var hasWorked : boolean = false;
		// la méthode renvoie un observable et un booléen en données
		return Observable.create((observer: Subscriber<boolean>) => {
			this._http.post<any>('http://pedago.univ-avignon.fr:3133/result/',{id_user: id_user, date_jeu: date_jeu, niveau_jeu: niveau_jeu, nb_reponses_corr: nb_reponses_corr, temps: temps, score: score}).subscribe( //connexion à la page results
				data => { // succes de l’observable httpClient, de la connexion à result
					if(data.statusResp2){ //si le score est un nouveau record
						hasWorked = true; //nouveau record exécuté
						this._VarGlob.betterScores = data.counter; //on met en variable globale qu'il n'y a aucun meilleur score
					}
					else{
						hasWorked = false; //pas de nouveau record exécuté
					}
				},
				
				error => {// erreur de l’observable httpClient
					console.error('une erreur est survenue!', error);
					hasWorked = false;
				},
				() => {// terminaison de l’observable httpClient
					observer.next(hasWorked); // renvoi des données pour l’observable principal
				}
			);
		});
	}
}
