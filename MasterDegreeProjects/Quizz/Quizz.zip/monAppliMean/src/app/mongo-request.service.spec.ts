import { TestBed } from '@angular/core/testing';

import { MongoRequestService } from './mongo-request.service';

describe('MongoRequestService', () => {
  let service: MongoRequestService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MongoRequestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
