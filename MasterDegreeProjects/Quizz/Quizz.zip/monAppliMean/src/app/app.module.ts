// Imports des modules Angular
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

// Import de mes services
import { AuthentificationService } from './authentification.service';
import { ModificationService } from './modification.service';
import { MongoRequestService } from './mongo-request.service';
import { AjoutScoreService } from './ajout-score.service';
import { ToptenService } from './topten.service';
import { HistoriqueService } from './historique.service';

// Imports  JavaScript/TypeScript des composants propres à l’application
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { QuizzHeaderComponent } from './quizz-header/quizz-header.component';
import { QuizzBodyComponent } from './quizz-body/quizz-body.component';
import { QuizzConnexionComponent } from './quizz-connexion/quizz-connexion.component';
import { QuizzFooterComponent } from './quizz-footer/quizz-footer.component';
import { QuizzProfileComponent } from './quizz-profile/quizz-profile.component';

@NgModule({
  declarations: [
    AppComponent,
    QuizzHeaderComponent,
    QuizzBodyComponent,
    QuizzConnexionComponent,
    QuizzFooterComponent,
	QuizzProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
	HttpClientModule,
	FormsModule
  ],
  providers: [AuthentificationService, ModificationService, MongoRequestService, AjoutScoreService, ToptenService, HistoriqueService],
  bootstrap: [AppComponent]
})
export class AppModule { }
