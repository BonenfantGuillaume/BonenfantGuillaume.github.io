import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError, Subscriber } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

@Injectable()
export class ModificationService {

	constructor(private _http: HttpClient) { 
	
	}

	// la méthode renvoie un observable principal et un booléen en données
	//fonction permettant de modifier un utilisateur
	ModifyProfile(nouvelleModification : string, donneeAModifier : string) : Observable<boolean> {
		var modificationDone : boolean = false;
		var id_user : number = (Number(localStorage.getItem('id')) || -1)
		
		// la méthode renvoie un observable et un booléen en données
		return Observable.create((observer: Subscriber<boolean>) => {
			this._http.post<any>('http://pedago.univ-avignon.fr:3133/modify/',{nouvelleModification : nouvelleModification, donneeAModifier : donneeAModifier, id : id_user}).subscribe( //connexion à la page modify
				data => { // succes de l’observable httpClient, de la connexion à modify
					if(data.statusResp){ //si la modification a réussi
						//on stocke la donnée modifiée en local
						localStorage.setItem(donneeAModifier, nouvelleModification);
						modificationDone = true; //connexion réussie
					}
					else{
						modificationDone = false; //connexion échouée
					}
				},
				
				error => {// erreur de l’observable httpClient
					console.error('une erreur est survenue!', error);
					modificationDone = false;
				},
				() => {// terminaison de l’observable httpClient
					observer.next(modificationDone); // renvoi des données pour l’observable principal
				}
			);
		});
	}}
