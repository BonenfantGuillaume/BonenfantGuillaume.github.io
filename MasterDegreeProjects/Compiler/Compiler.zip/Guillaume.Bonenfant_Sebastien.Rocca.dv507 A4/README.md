#  4DV507 Code Transformation and Interpretation  - assignment 3

**Made by Bonenfant Guillaume (gb222nz@student.lnu.se) and Rocca Sébastien (sr223iw@student.lnu.se).**

`Expressions.g4` file is available in `./src`.

Tests files are available in the `/Samples` and `/Samples/Tests` folders.

Source code is available in `./src`.

This is every assignments up to the 3 (included).

## Assignment 1 

In this assignment we worked on the ANTLR gramar, available in `src/LanguageExpressions.g4`

## Assignment 2 

For this assignment we : 

- Built the Symbol table based on the parsing of the syntax tree (available in `src/SymbolTableListener.java`). 
- Checked the different identifiers and their status if they're declared, assigned or not double (in `src/CheckRefListener.java`)
- Type checked every identifiers when needed (in assignation, calls...) (in `src/ParamListVisitor.java`)

## Assignment 3

For this assignment, the Python code translator is done in `src/PythonCodeGeneratorVisitor.java`  

## Assignment 4 

For this assignment, the ASM code translator is done in `src/AsmCodeGeneratorVisitor.java` 

The generated file name is always `hello.class` (best naming for test purposes). 