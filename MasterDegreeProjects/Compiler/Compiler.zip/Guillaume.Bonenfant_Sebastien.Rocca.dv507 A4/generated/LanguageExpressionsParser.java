// Generated from /home/sebastien/IdeaProjects/Guillaume.Bonenfant_Sebastien.Rocca.dv507.A2/src/LanguageExpressions.g4 by ANTLR 4.9.2
    // Define name of package for generated Java files. 
    package generated;  

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class LanguageExpressionsParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, ASSIGN=9, 
		PLUS=10, MINUS=11, MULT=12, DIV=13, LRB=14, RRB=15, LCB=16, RCB=17, AND=18, 
		LOWER=19, UPPER=20, EQUAL=21, DOT=22, FLOAT=23, INT=24, INTARRDECL=25, 
		FLOATARRDECL=26, BOOLARRDECL=27, CHARARRDECL=28, INTDECL=29, STRINGDECL=30, 
		CHARDECL=31, BOOL=32, BOOLDECL=33, FLOATDECL=34, WHILE=35, IF=36, ELSE=37, 
		PRINT=38, PRINTLN=39, FCTTYPE=40, CHAR=41, STRING=42, ID=43, SC=44, WS=45, 
		LINECOMMENT=46;
	public static final int
		RULE_start = 0, RULE_functionExp = 1, RULE_main = 2, RULE_fctParams = 3, 
		RULE_block = 4, RULE_stat = 5, RULE_whileExp = 6, RULE_ifEx = 7, RULE_elseifExp = 8, 
		RULE_elseExp = 9, RULE_functionCall = 10, RULE_printExp = 11, RULE_returnExp = 12, 
		RULE_conditionSigns = 13, RULE_expr = 14, RULE_idCall = 15, RULE_anyType = 16, 
		RULE_anyTypeArr = 17, RULE_rBExpr = 18, RULE_intType = 19, RULE_boolType = 20, 
		RULE_floatType = 21, RULE_charType = 22, RULE_stringType = 23, RULE_intDecl = 24, 
		RULE_floatDecl = 25, RULE_boolDecl = 26, RULE_charDecl = 27, RULE_stringDecl = 28, 
		RULE_intArrDecl = 29, RULE_floatArrDecl = 30, RULE_boolArrDecl = 31, RULE_charArrDecl = 32, 
		RULE_anyTypeDecl = 33, RULE_declaration = 34, RULE_assign = 35, RULE_assign2 = 36, 
		RULE_args = 37;
	private static String[] makeRuleNames() {
		return new String[] {
			"start", "functionExp", "main", "fctParams", "block", "stat", "whileExp", 
			"ifEx", "elseifExp", "elseExp", "functionCall", "printExp", "returnExp", 
			"conditionSigns", "expr", "idCall", "anyType", "anyTypeArr", "rBExpr", 
			"intType", "boolType", "floatType", "charType", "stringType", "intDecl", 
			"floatDecl", "boolDecl", "charDecl", "stringDecl", "intArrDecl", "floatArrDecl", 
			"boolArrDecl", "charArrDecl", "anyTypeDecl", "declaration", "assign", 
			"assign2", "args"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'void'", "'void main()'", "','", "'return'", "'.length'", "'['", 
			"']'", "'new '", "'='", "'+'", "'-'", "'*'", "'/'", "'('", "')'", "'{'", 
			"'}'", "'&&'", "'<'", "'>'", "'=='", "'.'", null, null, null, null, null, 
			null, null, null, null, null, null, null, "'while'", "'if'", "'else'", 
			"'print'", "'println'", null, null, null, null, "';'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, "ASSIGN", "PLUS", 
			"MINUS", "MULT", "DIV", "LRB", "RRB", "LCB", "RCB", "AND", "LOWER", "UPPER", 
			"EQUAL", "DOT", "FLOAT", "INT", "INTARRDECL", "FLOATARRDECL", "BOOLARRDECL", 
			"CHARARRDECL", "INTDECL", "STRINGDECL", "CHARDECL", "BOOL", "BOOLDECL", 
			"FLOATDECL", "WHILE", "IF", "ELSE", "PRINT", "PRINTLN", "FCTTYPE", "CHAR", 
			"STRING", "ID", "SC", "WS", "LINECOMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "LanguageExpressions.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public LanguageExpressionsParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class StartContext extends ParserRuleContext {
		public MainContext main() {
			return getRuleContext(MainContext.class,0);
		}
		public List<FunctionExpContext> functionExp() {
			return getRuleContexts(FunctionExpContext.class);
		}
		public FunctionExpContext functionExp(int i) {
			return getRuleContext(FunctionExpContext.class,i);
		}
		public StartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_start; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StartContext start() throws RecognitionException {
		StartContext _localctx = new StartContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_start);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << INTARRDECL) | (1L << FLOATARRDECL) | (1L << BOOLARRDECL) | (1L << CHARARRDECL) | (1L << INTDECL) | (1L << STRINGDECL) | (1L << CHARDECL) | (1L << BOOLDECL) | (1L << FLOATDECL))) != 0)) {
				{
				{
				setState(76);
				functionExp();
				}
				}
				setState(81);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(82);
			main();
			setState(86);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << INTARRDECL) | (1L << FLOATARRDECL) | (1L << BOOLARRDECL) | (1L << CHARARRDECL) | (1L << INTDECL) | (1L << STRINGDECL) | (1L << CHARDECL) | (1L << BOOLDECL) | (1L << FLOATDECL))) != 0)) {
				{
				{
				setState(83);
				functionExp();
				}
				}
				setState(88);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionExpContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(LanguageExpressionsParser.ID, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public FctParamsContext fctParams() {
			return getRuleContext(FctParamsContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public AnyTypeDeclContext anyTypeDecl() {
			return getRuleContext(AnyTypeDeclContext.class,0);
		}
		public FunctionExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionExp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFunctionExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFunctionExp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFunctionExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionExpContext functionExp() throws RecognitionException {
		FunctionExpContext _localctx = new FunctionExpContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_functionExp);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(91);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTARRDECL:
			case FLOATARRDECL:
			case BOOLARRDECL:
			case CHARARRDECL:
			case INTDECL:
			case STRINGDECL:
			case CHARDECL:
			case BOOLDECL:
			case FLOATDECL:
				{
				setState(89);
				anyTypeDecl();
				}
				break;
			case T__0:
				{
				setState(90);
				match(T__0);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(93);
			match(ID);
			setState(94);
			match(LRB);
			setState(95);
			fctParams();
			setState(96);
			match(RRB);
			setState(97);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MainContext extends ParserRuleContext {
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public MainContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_main; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterMain(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitMain(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitMain(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MainContext main() throws RecognitionException {
		MainContext _localctx = new MainContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_main);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(99);
			match(T__1);
			setState(100);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FctParamsContext extends ParserRuleContext {
		public List<AnyTypeDeclContext> anyTypeDecl() {
			return getRuleContexts(AnyTypeDeclContext.class);
		}
		public AnyTypeDeclContext anyTypeDecl(int i) {
			return getRuleContext(AnyTypeDeclContext.class,i);
		}
		public List<TerminalNode> ID() { return getTokens(LanguageExpressionsParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(LanguageExpressionsParser.ID, i);
		}
		public FctParamsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fctParams; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFctParams(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFctParams(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFctParams(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FctParamsContext fctParams() throws RecognitionException {
		FctParamsContext _localctx = new FctParamsContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_fctParams);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(105);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << INTARRDECL) | (1L << FLOATARRDECL) | (1L << BOOLARRDECL) | (1L << CHARARRDECL) | (1L << INTDECL) | (1L << STRINGDECL) | (1L << CHARDECL) | (1L << BOOLDECL) | (1L << FLOATDECL))) != 0)) {
				{
				setState(102);
				anyTypeDecl();
				setState(103);
				match(ID);
				}
			}

			setState(113);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__2) {
				{
				{
				setState(107);
				match(T__2);
				setState(108);
				anyTypeDecl();
				setState(109);
				match(ID);
				}
				}
				setState(115);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockContext extends ParserRuleContext {
		public TerminalNode LCB() { return getToken(LanguageExpressionsParser.LCB, 0); }
		public TerminalNode RCB() { return getToken(LanguageExpressionsParser.RCB, 0); }
		public List<StatContext> stat() {
			return getRuleContexts(StatContext.class);
		}
		public StatContext stat(int i) {
			return getRuleContext(StatContext.class,i);
		}
		public BlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_block; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockContext block() throws RecognitionException {
		BlockContext _localctx = new BlockContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_block);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(116);
			match(LCB);
			setState(120);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__3) | (1L << INTARRDECL) | (1L << FLOATARRDECL) | (1L << BOOLARRDECL) | (1L << CHARARRDECL) | (1L << INTDECL) | (1L << STRINGDECL) | (1L << CHARDECL) | (1L << BOOLDECL) | (1L << FLOATDECL) | (1L << WHILE) | (1L << IF) | (1L << PRINT) | (1L << PRINTLN) | (1L << ID))) != 0)) {
				{
				{
				setState(117);
				stat();
				}
				}
				setState(122);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(123);
			match(RCB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatContext extends ParserRuleContext {
		public StatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stat; }
	 
		public StatContext() { }
		public void copyFrom(StatContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class IfStatContext extends StatContext {
		public IfExContext ifEx() {
			return getRuleContext(IfExContext.class,0);
		}
		public List<ElseifExpContext> elseifExp() {
			return getRuleContexts(ElseifExpContext.class);
		}
		public ElseifExpContext elseifExp(int i) {
			return getRuleContext(ElseifExpContext.class,i);
		}
		public ElseExpContext elseExp() {
			return getRuleContext(ElseExpContext.class,0);
		}
		public IfStatContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIfStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIfStat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIfStat(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrintStatContext extends StatContext {
		public PrintExpContext printExp() {
			return getRuleContext(PrintExpContext.class,0);
		}
		public PrintStatContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterPrintStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitPrintStat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitPrintStat(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FunctionStatContext extends StatContext {
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public TerminalNode SC() { return getToken(LanguageExpressionsParser.SC, 0); }
		public FunctionStatContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFunctionStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFunctionStat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFunctionStat(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ReturnStatContext extends StatContext {
		public ReturnExpContext returnExp() {
			return getRuleContext(ReturnExpContext.class,0);
		}
		public ReturnStatContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterReturnStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitReturnStat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitReturnStat(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class DeclStatContext extends StatContext {
		public DeclarationContext declaration() {
			return getRuleContext(DeclarationContext.class,0);
		}
		public DeclStatContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterDeclStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitDeclStat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitDeclStat(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignStatContext extends StatContext {
		public AssignContext assign() {
			return getRuleContext(AssignContext.class,0);
		}
		public AssignStatContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterAssignStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitAssignStat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitAssignStat(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class WhileStatContext extends StatContext {
		public WhileExpContext whileExp() {
			return getRuleContext(WhileExpContext.class,0);
		}
		public WhileStatContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterWhileStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitWhileStat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitWhileStat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatContext stat() throws RecognitionException {
		StatContext _localctx = new StatContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_stat);
		try {
			int _alt;
			setState(143);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				_localctx = new WhileStatContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(125);
				whileExp();
				}
				break;
			case 2:
				_localctx = new IfStatContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(126);
				ifEx();
				setState(130);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(127);
						elseifExp();
						}
						} 
					}
					setState(132);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
				}
				setState(134);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
				case 1:
					{
					setState(133);
					elseExp();
					}
					break;
				}
				}
				break;
			case 3:
				_localctx = new DeclStatContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(136);
				declaration();
				}
				break;
			case 4:
				_localctx = new AssignStatContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(137);
				assign();
				}
				break;
			case 5:
				_localctx = new PrintStatContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(138);
				printExp();
				}
				break;
			case 6:
				_localctx = new FunctionStatContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(139);
				functionCall();
				setState(140);
				match(SC);
				}
				break;
			case 7:
				_localctx = new ReturnStatContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(142);
				returnExp();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileExpContext extends ParserRuleContext {
		public WhileExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileExp; }
	 
		public WhileExpContext() { }
		public void copyFrom(WhileExpContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class WhileNonBlockContext extends WhileExpContext {
		public TerminalNode WHILE() { return getToken(LanguageExpressionsParser.WHILE, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public WhileNonBlockContext(WhileExpContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterWhileNonBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitWhileNonBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitWhileNonBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class WhileBlockContext extends WhileExpContext {
		public TerminalNode WHILE() { return getToken(LanguageExpressionsParser.WHILE, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public WhileBlockContext(WhileExpContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterWhileBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitWhileBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitWhileBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhileExpContext whileExp() throws RecognitionException {
		WhileExpContext _localctx = new WhileExpContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_whileExp);
		try {
			setState(157);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				_localctx = new WhileNonBlockContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(145);
				match(WHILE);
				setState(146);
				match(LRB);
				setState(147);
				expr(0);
				setState(148);
				match(RRB);
				setState(149);
				stat();
				}
				break;
			case 2:
				_localctx = new WhileBlockContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(151);
				match(WHILE);
				setState(152);
				match(LRB);
				setState(153);
				expr(0);
				setState(154);
				match(RRB);
				setState(155);
				block();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfExContext extends ParserRuleContext {
		public IfExContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifEx; }
	 
		public IfExContext() { }
		public void copyFrom(IfExContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class IfNonBlockContext extends IfExContext {
		public TerminalNode IF() { return getToken(LanguageExpressionsParser.IF, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public IfNonBlockContext(IfExContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIfNonBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIfNonBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIfNonBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IfBlockContext extends IfExContext {
		public TerminalNode IF() { return getToken(LanguageExpressionsParser.IF, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public IfBlockContext(IfExContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIfBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIfBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIfBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfExContext ifEx() throws RecognitionException {
		IfExContext _localctx = new IfExContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_ifEx);
		try {
			setState(171);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				_localctx = new IfNonBlockContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(159);
				match(IF);
				setState(160);
				match(LRB);
				setState(161);
				expr(0);
				setState(162);
				match(RRB);
				setState(163);
				stat();
				}
				break;
			case 2:
				_localctx = new IfBlockContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(165);
				match(IF);
				setState(166);
				match(LRB);
				setState(167);
				expr(0);
				setState(168);
				match(RRB);
				setState(169);
				block();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseifExpContext extends ParserRuleContext {
		public ElseifExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseifExp; }
	 
		public ElseifExpContext() { }
		public void copyFrom(ElseifExpContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ElseifBlockContext extends ElseifExpContext {
		public TerminalNode ELSE() { return getToken(LanguageExpressionsParser.ELSE, 0); }
		public TerminalNode IF() { return getToken(LanguageExpressionsParser.IF, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public ElseifBlockContext(ElseifExpContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterElseifBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitElseifBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitElseifBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ElseifNonBlockContext extends ElseifExpContext {
		public TerminalNode ELSE() { return getToken(LanguageExpressionsParser.ELSE, 0); }
		public TerminalNode IF() { return getToken(LanguageExpressionsParser.IF, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public ElseifNonBlockContext(ElseifExpContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterElseifNonBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitElseifNonBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitElseifNonBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseifExpContext elseifExp() throws RecognitionException {
		ElseifExpContext _localctx = new ElseifExpContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_elseifExp);
		try {
			setState(187);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				_localctx = new ElseifNonBlockContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(173);
				match(ELSE);
				setState(174);
				match(IF);
				setState(175);
				match(LRB);
				setState(176);
				expr(0);
				setState(177);
				match(RRB);
				setState(178);
				stat();
				}
				break;
			case 2:
				_localctx = new ElseifBlockContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(180);
				match(ELSE);
				setState(181);
				match(IF);
				setState(182);
				match(LRB);
				setState(183);
				expr(0);
				setState(184);
				match(RRB);
				setState(185);
				block();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseExpContext extends ParserRuleContext {
		public ElseExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseExp; }
	 
		public ElseExpContext() { }
		public void copyFrom(ElseExpContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ElseNonBlockContext extends ElseExpContext {
		public TerminalNode ELSE() { return getToken(LanguageExpressionsParser.ELSE, 0); }
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public ElseNonBlockContext(ElseExpContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterElseNonBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitElseNonBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitElseNonBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ElseBlockContext extends ElseExpContext {
		public TerminalNode ELSE() { return getToken(LanguageExpressionsParser.ELSE, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public ElseBlockContext(ElseExpContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterElseBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitElseBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitElseBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseExpContext elseExp() throws RecognitionException {
		ElseExpContext _localctx = new ElseExpContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_elseExp);
		try {
			setState(193);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				_localctx = new ElseNonBlockContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(189);
				match(ELSE);
				setState(190);
				stat();
				}
				break;
			case 2:
				_localctx = new ElseBlockContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(191);
				match(ELSE);
				setState(192);
				block();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionCallContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(LanguageExpressionsParser.ID, 0); }
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ArgsContext args() {
			return getRuleContext(ArgsContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public FunctionCallContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionCall; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFunctionCall(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFunctionCall(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFunctionCall(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionCallContext functionCall() throws RecognitionException {
		FunctionCallContext _localctx = new FunctionCallContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_functionCall);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(195);
			match(ID);
			setState(196);
			match(LRB);
			setState(197);
			args();
			setState(198);
			match(RRB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PrintExpContext extends ParserRuleContext {
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public TerminalNode SC() { return getToken(LanguageExpressionsParser.SC, 0); }
		public TerminalNode PRINT() { return getToken(LanguageExpressionsParser.PRINT, 0); }
		public TerminalNode PRINTLN() { return getToken(LanguageExpressionsParser.PRINTLN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode STRING() { return getToken(LanguageExpressionsParser.STRING, 0); }
		public PrintExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_printExp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterPrintExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitPrintExp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitPrintExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrintExpContext printExp() throws RecognitionException {
		PrintExpContext _localctx = new PrintExpContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_printExp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(200);
			_la = _input.LA(1);
			if ( !(_la==PRINT || _la==PRINTLN) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(201);
			match(LRB);
			setState(204);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
			case 1:
				{
				setState(202);
				expr(0);
				}
				break;
			case 2:
				{
				setState(203);
				match(STRING);
				}
				break;
			}
			setState(206);
			match(RRB);
			setState(207);
			match(SC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReturnExpContext extends ParserRuleContext {
		public TerminalNode SC() { return getToken(LanguageExpressionsParser.SC, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ReturnExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_returnExp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterReturnExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitReturnExp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitReturnExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ReturnExpContext returnExp() throws RecognitionException {
		ReturnExpContext _localctx = new ReturnExpContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_returnExp);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(209);
			match(T__3);
			{
			setState(210);
			expr(0);
			}
			setState(211);
			match(SC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConditionSignsContext extends ParserRuleContext {
		public TerminalNode LOWER() { return getToken(LanguageExpressionsParser.LOWER, 0); }
		public TerminalNode UPPER() { return getToken(LanguageExpressionsParser.UPPER, 0); }
		public TerminalNode EQUAL() { return getToken(LanguageExpressionsParser.EQUAL, 0); }
		public ConditionSignsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditionSigns; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterConditionSigns(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitConditionSigns(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitConditionSigns(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionSignsContext conditionSigns() throws RecognitionException {
		ConditionSignsContext _localctx = new ConditionSignsContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_conditionSigns);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(213);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LOWER) | (1L << UPPER) | (1L << EQUAL))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class NewExprContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public IntDeclContext intDecl() {
			return getRuleContext(IntDeclContext.class,0);
		}
		public BoolDeclContext boolDecl() {
			return getRuleContext(BoolDeclContext.class,0);
		}
		public FloatDeclContext floatDecl() {
			return getRuleContext(FloatDeclContext.class,0);
		}
		public CharDeclContext charDecl() {
			return getRuleContext(CharDeclContext.class,0);
		}
		public NewExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterNewExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitNewExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitNewExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LengthExprContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public LengthExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterLengthExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitLengthExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitLengthExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TableExprContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TableExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterTableExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitTableExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitTableExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FctExprContext extends ExprContext {
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public FctExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFctExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFctExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFctExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ArrayExprContext extends ExprContext {
		public TerminalNode LCB() { return getToken(LanguageExpressionsParser.LCB, 0); }
		public TerminalNode RCB() { return getToken(LanguageExpressionsParser.RCB, 0); }
		public List<AnyTypeArrContext> anyTypeArr() {
			return getRuleContexts(AnyTypeArrContext.class);
		}
		public AnyTypeArrContext anyTypeArr(int i) {
			return getRuleContext(AnyTypeArrContext.class,i);
		}
		public ArrayExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterArrayExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitArrayExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitArrayExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PlusMinusExprContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode PLUS() { return getToken(LanguageExpressionsParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(LanguageExpressionsParser.MINUS, 0); }
		public PlusMinusExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterPlusMinusExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitPlusMinusExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitPlusMinusExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CondExprContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ConditionSignsContext conditionSigns() {
			return getRuleContext(ConditionSignsContext.class,0);
		}
		public CondExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterCondExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitCondExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitCondExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AnyTypeExprContext extends ExprContext {
		public AnyTypeContext anyType() {
			return getRuleContext(AnyTypeContext.class,0);
		}
		public AnyTypeExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterAnyTypeExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitAnyTypeExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitAnyTypeExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class MultDivExprContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode MULT() { return getToken(LanguageExpressionsParser.MULT, 0); }
		public TerminalNode DIV() { return getToken(LanguageExpressionsParser.DIV, 0); }
		public MultDivExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterMultDivExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitMultDivExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitMultDivExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RbExprContext extends ExprContext {
		public RBExprContext rBExpr() {
			return getRuleContext(RBExprContext.class,0);
		}
		public RbExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterRbExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitRbExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitRbExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IdExprContext extends ExprContext {
		public IdCallContext idCall() {
			return getRuleContext(IdCallContext.class,0);
		}
		public IdExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIdExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIdExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIdExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 28;
		enterRecursionRule(_localctx, 28, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(243);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,17,_ctx) ) {
			case 1:
				{
				_localctx = new RbExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(216);
				rBExpr();
				}
				break;
			case 2:
				{
				_localctx = new FctExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(217);
				functionCall();
				}
				break;
			case 3:
				{
				_localctx = new NewExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(218);
				match(T__7);
				setState(223);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case INTDECL:
					{
					setState(219);
					intDecl();
					}
					break;
				case BOOLDECL:
					{
					setState(220);
					boolDecl();
					}
					break;
				case FLOATDECL:
					{
					setState(221);
					floatDecl();
					}
					break;
				case CHARDECL:
					{
					setState(222);
					charDecl();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(225);
				match(T__5);
				setState(226);
				expr(0);
				setState(227);
				match(T__6);
				}
				break;
			case 4:
				{
				_localctx = new ArrayExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(229);
				match(LCB);
				setState(231);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << FLOAT) | (1L << INT) | (1L << BOOL) | (1L << CHAR))) != 0)) {
					{
					setState(230);
					anyTypeArr();
					}
				}

				setState(237);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__2) {
					{
					{
					setState(233);
					match(T__2);
					setState(234);
					anyTypeArr();
					}
					}
					setState(239);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(240);
				match(RCB);
				}
				break;
			case 5:
				{
				_localctx = new AnyTypeExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(241);
				anyType();
				}
				break;
			case 6:
				{
				_localctx = new IdExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(242);
				idCall();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(264);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(262);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
					case 1:
						{
						_localctx = new MultDivExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(245);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(246);
						_la = _input.LA(1);
						if ( !(_la==MULT || _la==DIV) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(247);
						expr(11);
						}
						break;
					case 2:
						{
						_localctx = new PlusMinusExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(248);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(249);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(250);
						expr(10);
						}
						break;
					case 3:
						{
						_localctx = new CondExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(251);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(252);
						conditionSigns();
						setState(253);
						expr(9);
						}
						break;
					case 4:
						{
						_localctx = new LengthExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(255);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						{
						setState(256);
						match(T__4);
						}
						}
						break;
					case 5:
						{
						_localctx = new TableExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(257);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						{
						setState(258);
						match(T__5);
						setState(259);
						expr(0);
						setState(260);
						match(T__6);
						}
						}
						break;
					}
					} 
				}
				setState(266);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class IdCallContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(LanguageExpressionsParser.ID, 0); }
		public IdCallContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_idCall; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIdCall(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIdCall(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIdCall(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdCallContext idCall() throws RecognitionException {
		IdCallContext _localctx = new IdCallContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_idCall);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(267);
			match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AnyTypeContext extends ParserRuleContext {
		public IntTypeContext intType() {
			return getRuleContext(IntTypeContext.class,0);
		}
		public BoolTypeContext boolType() {
			return getRuleContext(BoolTypeContext.class,0);
		}
		public FloatTypeContext floatType() {
			return getRuleContext(FloatTypeContext.class,0);
		}
		public CharTypeContext charType() {
			return getRuleContext(CharTypeContext.class,0);
		}
		public StringTypeContext stringType() {
			return getRuleContext(StringTypeContext.class,0);
		}
		public AnyTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anyType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterAnyType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitAnyType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitAnyType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnyTypeContext anyType() throws RecognitionException {
		AnyTypeContext _localctx = new AnyTypeContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_anyType);
		try {
			setState(274);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				enterOuterAlt(_localctx, 1);
				{
				setState(269);
				intType();
				}
				break;
			case BOOL:
				enterOuterAlt(_localctx, 2);
				{
				setState(270);
				boolType();
				}
				break;
			case FLOAT:
				enterOuterAlt(_localctx, 3);
				{
				setState(271);
				floatType();
				}
				break;
			case CHAR:
				enterOuterAlt(_localctx, 4);
				{
				setState(272);
				charType();
				}
				break;
			case STRING:
				enterOuterAlt(_localctx, 5);
				{
				setState(273);
				stringType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AnyTypeArrContext extends ParserRuleContext {
		public IntTypeContext intType() {
			return getRuleContext(IntTypeContext.class,0);
		}
		public BoolTypeContext boolType() {
			return getRuleContext(BoolTypeContext.class,0);
		}
		public CharTypeContext charType() {
			return getRuleContext(CharTypeContext.class,0);
		}
		public FloatTypeContext floatType() {
			return getRuleContext(FloatTypeContext.class,0);
		}
		public AnyTypeArrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anyTypeArr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterAnyTypeArr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitAnyTypeArr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitAnyTypeArr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnyTypeArrContext anyTypeArr() throws RecognitionException {
		AnyTypeArrContext _localctx = new AnyTypeArrContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_anyTypeArr);
		try {
			setState(280);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				enterOuterAlt(_localctx, 1);
				{
				setState(276);
				intType();
				}
				break;
			case BOOL:
				enterOuterAlt(_localctx, 2);
				{
				setState(277);
				boolType();
				}
				break;
			case CHAR:
				enterOuterAlt(_localctx, 3);
				{
				setState(278);
				charType();
				}
				break;
			case FLOAT:
				enterOuterAlt(_localctx, 4);
				{
				setState(279);
				floatType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RBExprContext extends ParserRuleContext {
		public TerminalNode LRB() { return getToken(LanguageExpressionsParser.LRB, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RRB() { return getToken(LanguageExpressionsParser.RRB, 0); }
		public RBExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rBExpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterRBExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitRBExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitRBExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RBExprContext rBExpr() throws RecognitionException {
		RBExprContext _localctx = new RBExprContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_rBExpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(282);
			match(LRB);
			setState(283);
			expr(0);
			setState(284);
			match(RRB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntTypeContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(LanguageExpressionsParser.INT, 0); }
		public IntTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_intType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIntType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIntType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIntType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntTypeContext intType() throws RecognitionException {
		IntTypeContext _localctx = new IntTypeContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_intType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(286);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BoolTypeContext extends ParserRuleContext {
		public TerminalNode BOOL() { return getToken(LanguageExpressionsParser.BOOL, 0); }
		public BoolTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterBoolType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitBoolType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitBoolType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BoolTypeContext boolType() throws RecognitionException {
		BoolTypeContext _localctx = new BoolTypeContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_boolType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(288);
			match(BOOL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FloatTypeContext extends ParserRuleContext {
		public TerminalNode FLOAT() { return getToken(LanguageExpressionsParser.FLOAT, 0); }
		public FloatTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_floatType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFloatType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFloatType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFloatType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FloatTypeContext floatType() throws RecognitionException {
		FloatTypeContext _localctx = new FloatTypeContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_floatType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(290);
			match(FLOAT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CharTypeContext extends ParserRuleContext {
		public TerminalNode CHAR() { return getToken(LanguageExpressionsParser.CHAR, 0); }
		public CharTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_charType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterCharType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitCharType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitCharType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CharTypeContext charType() throws RecognitionException {
		CharTypeContext _localctx = new CharTypeContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_charType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(292);
			match(CHAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringTypeContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(LanguageExpressionsParser.STRING, 0); }
		public StringTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterStringType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitStringType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitStringType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringTypeContext stringType() throws RecognitionException {
		StringTypeContext _localctx = new StringTypeContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_stringType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(294);
			match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntDeclContext extends ParserRuleContext {
		public TerminalNode INTDECL() { return getToken(LanguageExpressionsParser.INTDECL, 0); }
		public IntDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_intDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIntDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIntDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIntDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntDeclContext intDecl() throws RecognitionException {
		IntDeclContext _localctx = new IntDeclContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_intDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(296);
			match(INTDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FloatDeclContext extends ParserRuleContext {
		public TerminalNode FLOATDECL() { return getToken(LanguageExpressionsParser.FLOATDECL, 0); }
		public FloatDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_floatDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFloatDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFloatDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFloatDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FloatDeclContext floatDecl() throws RecognitionException {
		FloatDeclContext _localctx = new FloatDeclContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_floatDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(298);
			match(FLOATDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BoolDeclContext extends ParserRuleContext {
		public TerminalNode BOOLDECL() { return getToken(LanguageExpressionsParser.BOOLDECL, 0); }
		public BoolDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterBoolDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitBoolDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitBoolDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BoolDeclContext boolDecl() throws RecognitionException {
		BoolDeclContext _localctx = new BoolDeclContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_boolDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(300);
			match(BOOLDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CharDeclContext extends ParserRuleContext {
		public TerminalNode CHARDECL() { return getToken(LanguageExpressionsParser.CHARDECL, 0); }
		public CharDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_charDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterCharDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitCharDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitCharDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CharDeclContext charDecl() throws RecognitionException {
		CharDeclContext _localctx = new CharDeclContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_charDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(302);
			match(CHARDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringDeclContext extends ParserRuleContext {
		public TerminalNode STRINGDECL() { return getToken(LanguageExpressionsParser.STRINGDECL, 0); }
		public StringDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterStringDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitStringDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitStringDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringDeclContext stringDecl() throws RecognitionException {
		StringDeclContext _localctx = new StringDeclContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_stringDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(304);
			match(STRINGDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntArrDeclContext extends ParserRuleContext {
		public TerminalNode INTARRDECL() { return getToken(LanguageExpressionsParser.INTARRDECL, 0); }
		public IntArrDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_intArrDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterIntArrDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitIntArrDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitIntArrDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntArrDeclContext intArrDecl() throws RecognitionException {
		IntArrDeclContext _localctx = new IntArrDeclContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_intArrDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(306);
			match(INTARRDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FloatArrDeclContext extends ParserRuleContext {
		public TerminalNode FLOATARRDECL() { return getToken(LanguageExpressionsParser.FLOATARRDECL, 0); }
		public FloatArrDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_floatArrDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterFloatArrDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitFloatArrDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitFloatArrDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FloatArrDeclContext floatArrDecl() throws RecognitionException {
		FloatArrDeclContext _localctx = new FloatArrDeclContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_floatArrDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(308);
			match(FLOATARRDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BoolArrDeclContext extends ParserRuleContext {
		public TerminalNode BOOLARRDECL() { return getToken(LanguageExpressionsParser.BOOLARRDECL, 0); }
		public BoolArrDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolArrDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterBoolArrDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitBoolArrDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitBoolArrDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BoolArrDeclContext boolArrDecl() throws RecognitionException {
		BoolArrDeclContext _localctx = new BoolArrDeclContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_boolArrDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(310);
			match(BOOLARRDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CharArrDeclContext extends ParserRuleContext {
		public TerminalNode CHARARRDECL() { return getToken(LanguageExpressionsParser.CHARARRDECL, 0); }
		public CharArrDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_charArrDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterCharArrDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitCharArrDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitCharArrDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CharArrDeclContext charArrDecl() throws RecognitionException {
		CharArrDeclContext _localctx = new CharArrDeclContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_charArrDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(312);
			match(CHARARRDECL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AnyTypeDeclContext extends ParserRuleContext {
		public IntDeclContext intDecl() {
			return getRuleContext(IntDeclContext.class,0);
		}
		public BoolDeclContext boolDecl() {
			return getRuleContext(BoolDeclContext.class,0);
		}
		public FloatDeclContext floatDecl() {
			return getRuleContext(FloatDeclContext.class,0);
		}
		public CharDeclContext charDecl() {
			return getRuleContext(CharDeclContext.class,0);
		}
		public StringDeclContext stringDecl() {
			return getRuleContext(StringDeclContext.class,0);
		}
		public IntArrDeclContext intArrDecl() {
			return getRuleContext(IntArrDeclContext.class,0);
		}
		public FloatArrDeclContext floatArrDecl() {
			return getRuleContext(FloatArrDeclContext.class,0);
		}
		public BoolArrDeclContext boolArrDecl() {
			return getRuleContext(BoolArrDeclContext.class,0);
		}
		public CharArrDeclContext charArrDecl() {
			return getRuleContext(CharArrDeclContext.class,0);
		}
		public AnyTypeDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anyTypeDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterAnyTypeDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitAnyTypeDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitAnyTypeDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnyTypeDeclContext anyTypeDecl() throws RecognitionException {
		AnyTypeDeclContext _localctx = new AnyTypeDeclContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_anyTypeDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(323);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTDECL:
				{
				setState(314);
				intDecl();
				}
				break;
			case BOOLDECL:
				{
				setState(315);
				boolDecl();
				}
				break;
			case FLOATDECL:
				{
				setState(316);
				floatDecl();
				}
				break;
			case CHARDECL:
				{
				setState(317);
				charDecl();
				}
				break;
			case STRINGDECL:
				{
				setState(318);
				stringDecl();
				}
				break;
			case INTARRDECL:
				{
				setState(319);
				intArrDecl();
				}
				break;
			case FLOATARRDECL:
				{
				setState(320);
				floatArrDecl();
				}
				break;
			case BOOLARRDECL:
				{
				setState(321);
				boolArrDecl();
				}
				break;
			case CHARARRDECL:
				{
				setState(322);
				charArrDecl();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclarationContext extends ParserRuleContext {
		public AnyTypeDeclContext anyTypeDecl() {
			return getRuleContext(AnyTypeDeclContext.class,0);
		}
		public Assign2Context assign2() {
			return getRuleContext(Assign2Context.class,0);
		}
		public TerminalNode ID() { return getToken(LanguageExpressionsParser.ID, 0); }
		public TerminalNode SC() { return getToken(LanguageExpressionsParser.SC, 0); }
		public DeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitDeclaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitDeclaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeclarationContext declaration() throws RecognitionException {
		DeclarationContext _localctx = new DeclarationContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_declaration);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(325);
			anyTypeDecl();
			setState(329);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
			case 1:
				{
				setState(326);
				assign2();
				}
				break;
			case 2:
				{
				setState(327);
				match(ID);
				setState(328);
				match(SC);
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignContext extends ParserRuleContext {
		public IdCallContext idCall() {
			return getRuleContext(IdCallContext.class,0);
		}
		public TerminalNode ASSIGN() { return getToken(LanguageExpressionsParser.ASSIGN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode SC() { return getToken(LanguageExpressionsParser.SC, 0); }
		public AssignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterAssign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitAssign(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitAssign(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignContext assign() throws RecognitionException {
		AssignContext _localctx = new AssignContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_assign);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(331);
			idCall();
			setState(336);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__5) {
				{
				setState(332);
				match(T__5);
				{
				setState(333);
				expr(0);
				}
				setState(334);
				match(T__6);
				}
			}

			setState(338);
			match(ASSIGN);
			setState(339);
			expr(0);
			setState(340);
			match(SC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Assign2Context extends ParserRuleContext {
		public TerminalNode ID() { return getToken(LanguageExpressionsParser.ID, 0); }
		public TerminalNode ASSIGN() { return getToken(LanguageExpressionsParser.ASSIGN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode SC() { return getToken(LanguageExpressionsParser.SC, 0); }
		public Assign2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assign2; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterAssign2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitAssign2(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitAssign2(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Assign2Context assign2() throws RecognitionException {
		Assign2Context _localctx = new Assign2Context(_ctx, getState());
		enterRule(_localctx, 72, RULE_assign2);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(342);
			match(ID);
			setState(347);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__5) {
				{
				setState(343);
				match(T__5);
				{
				setState(344);
				expr(0);
				}
				setState(345);
				match(T__6);
				}
			}

			setState(349);
			match(ASSIGN);
			setState(350);
			expr(0);
			setState(351);
			match(SC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArgsContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ArgsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_args; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).enterArgs(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LanguageExpressionsListener ) ((LanguageExpressionsListener)listener).exitArgs(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LanguageExpressionsVisitor ) return ((LanguageExpressionsVisitor<? extends T>)visitor).visitArgs(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArgsContext args() throws RecognitionException {
		ArgsContext _localctx = new ArgsContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_args);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(362);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__7:
			case LRB:
			case LCB:
			case FLOAT:
			case INT:
			case BOOL:
			case CHAR:
			case STRING:
			case ID:
				{
				setState(353);
				expr(0);
				setState(358);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__2) {
					{
					{
					setState(354);
					match(T__2);
					setState(355);
					expr(0);
					}
					}
					setState(360);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case RRB:
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 14:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 10);
		case 1:
			return precpred(_ctx, 9);
		case 2:
			return precpred(_ctx, 8);
		case 3:
			return precpred(_ctx, 7);
		case 4:
			return precpred(_ctx, 6);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\60\u016f\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\3\2\7\2P\n\2\f\2\16\2S\13"+
		"\2\3\2\3\2\7\2W\n\2\f\2\16\2Z\13\2\3\3\3\3\5\3^\n\3\3\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\4\3\4\3\4\3\5\3\5\3\5\5\5l\n\5\3\5\3\5\3\5\3\5\7\5r\n\5\f\5\16"+
		"\5u\13\5\3\6\3\6\7\6y\n\6\f\6\16\6|\13\6\3\6\3\6\3\7\3\7\3\7\7\7\u0083"+
		"\n\7\f\7\16\7\u0086\13\7\3\7\5\7\u0089\n\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7"+
		"\5\7\u0092\n\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\5\b\u00a0"+
		"\n\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\5\t\u00ae\n\t\3\n"+
		"\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\5\n\u00be\n\n\3\13"+
		"\3\13\3\13\3\13\5\13\u00c4\n\13\3\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\5"+
		"\r\u00cf\n\r\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\17\3\17\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\5\20\u00e2\n\20\3\20\3\20\3\20\3\20\3\20\3\20"+
		"\5\20\u00ea\n\20\3\20\3\20\7\20\u00ee\n\20\f\20\16\20\u00f1\13\20\3\20"+
		"\3\20\3\20\5\20\u00f6\n\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\7\20\u0109\n\20\f\20\16\20\u010c"+
		"\13\20\3\21\3\21\3\22\3\22\3\22\3\22\3\22\5\22\u0115\n\22\3\23\3\23\3"+
		"\23\3\23\5\23\u011b\n\23\3\24\3\24\3\24\3\24\3\25\3\25\3\26\3\26\3\27"+
		"\3\27\3\30\3\30\3\31\3\31\3\32\3\32\3\33\3\33\3\34\3\34\3\35\3\35\3\36"+
		"\3\36\3\37\3\37\3 \3 \3!\3!\3\"\3\"\3#\3#\3#\3#\3#\3#\3#\3#\3#\5#\u0146"+
		"\n#\3$\3$\3$\3$\5$\u014c\n$\3%\3%\3%\3%\3%\5%\u0153\n%\3%\3%\3%\3%\3&"+
		"\3&\3&\3&\3&\5&\u015e\n&\3&\3&\3&\3&\3\'\3\'\3\'\7\'\u0167\n\'\f\'\16"+
		"\'\u016a\13\'\3\'\5\'\u016d\n\'\3\'\2\3\36(\2\4\6\b\n\f\16\20\22\24\26"+
		"\30\32\34\36 \"$&(*,.\60\62\64\668:<>@BDFHJL\2\6\3\2()\3\2\25\27\3\2\16"+
		"\17\3\2\f\r\2\u017e\2Q\3\2\2\2\4]\3\2\2\2\6e\3\2\2\2\bk\3\2\2\2\nv\3\2"+
		"\2\2\f\u0091\3\2\2\2\16\u009f\3\2\2\2\20\u00ad\3\2\2\2\22\u00bd\3\2\2"+
		"\2\24\u00c3\3\2\2\2\26\u00c5\3\2\2\2\30\u00ca\3\2\2\2\32\u00d3\3\2\2\2"+
		"\34\u00d7\3\2\2\2\36\u00f5\3\2\2\2 \u010d\3\2\2\2\"\u0114\3\2\2\2$\u011a"+
		"\3\2\2\2&\u011c\3\2\2\2(\u0120\3\2\2\2*\u0122\3\2\2\2,\u0124\3\2\2\2."+
		"\u0126\3\2\2\2\60\u0128\3\2\2\2\62\u012a\3\2\2\2\64\u012c\3\2\2\2\66\u012e"+
		"\3\2\2\28\u0130\3\2\2\2:\u0132\3\2\2\2<\u0134\3\2\2\2>\u0136\3\2\2\2@"+
		"\u0138\3\2\2\2B\u013a\3\2\2\2D\u0145\3\2\2\2F\u0147\3\2\2\2H\u014d\3\2"+
		"\2\2J\u0158\3\2\2\2L\u016c\3\2\2\2NP\5\4\3\2ON\3\2\2\2PS\3\2\2\2QO\3\2"+
		"\2\2QR\3\2\2\2RT\3\2\2\2SQ\3\2\2\2TX\5\6\4\2UW\5\4\3\2VU\3\2\2\2WZ\3\2"+
		"\2\2XV\3\2\2\2XY\3\2\2\2Y\3\3\2\2\2ZX\3\2\2\2[^\5D#\2\\^\7\3\2\2][\3\2"+
		"\2\2]\\\3\2\2\2^_\3\2\2\2_`\7-\2\2`a\7\20\2\2ab\5\b\5\2bc\7\21\2\2cd\5"+
		"\n\6\2d\5\3\2\2\2ef\7\4\2\2fg\5\n\6\2g\7\3\2\2\2hi\5D#\2ij\7-\2\2jl\3"+
		"\2\2\2kh\3\2\2\2kl\3\2\2\2ls\3\2\2\2mn\7\5\2\2no\5D#\2op\7-\2\2pr\3\2"+
		"\2\2qm\3\2\2\2ru\3\2\2\2sq\3\2\2\2st\3\2\2\2t\t\3\2\2\2us\3\2\2\2vz\7"+
		"\22\2\2wy\5\f\7\2xw\3\2\2\2y|\3\2\2\2zx\3\2\2\2z{\3\2\2\2{}\3\2\2\2|z"+
		"\3\2\2\2}~\7\23\2\2~\13\3\2\2\2\177\u0092\5\16\b\2\u0080\u0084\5\20\t"+
		"\2\u0081\u0083\5\22\n\2\u0082\u0081\3\2\2\2\u0083\u0086\3\2\2\2\u0084"+
		"\u0082\3\2\2\2\u0084\u0085\3\2\2\2\u0085\u0088\3\2\2\2\u0086\u0084\3\2"+
		"\2\2\u0087\u0089\5\24\13\2\u0088\u0087\3\2\2\2\u0088\u0089\3\2\2\2\u0089"+
		"\u0092\3\2\2\2\u008a\u0092\5F$\2\u008b\u0092\5H%\2\u008c\u0092\5\30\r"+
		"\2\u008d\u008e\5\26\f\2\u008e\u008f\7.\2\2\u008f\u0092\3\2\2\2\u0090\u0092"+
		"\5\32\16\2\u0091\177\3\2\2\2\u0091\u0080\3\2\2\2\u0091\u008a\3\2\2\2\u0091"+
		"\u008b\3\2\2\2\u0091\u008c\3\2\2\2\u0091\u008d\3\2\2\2\u0091\u0090\3\2"+
		"\2\2\u0092\r\3\2\2\2\u0093\u0094\7%\2\2\u0094\u0095\7\20\2\2\u0095\u0096"+
		"\5\36\20\2\u0096\u0097\7\21\2\2\u0097\u0098\5\f\7\2\u0098\u00a0\3\2\2"+
		"\2\u0099\u009a\7%\2\2\u009a\u009b\7\20\2\2\u009b\u009c\5\36\20\2\u009c"+
		"\u009d\7\21\2\2\u009d\u009e\5\n\6\2\u009e\u00a0\3\2\2\2\u009f\u0093\3"+
		"\2\2\2\u009f\u0099\3\2\2\2\u00a0\17\3\2\2\2\u00a1\u00a2\7&\2\2\u00a2\u00a3"+
		"\7\20\2\2\u00a3\u00a4\5\36\20\2\u00a4\u00a5\7\21\2\2\u00a5\u00a6\5\f\7"+
		"\2\u00a6\u00ae\3\2\2\2\u00a7\u00a8\7&\2\2\u00a8\u00a9\7\20\2\2\u00a9\u00aa"+
		"\5\36\20\2\u00aa\u00ab\7\21\2\2\u00ab\u00ac\5\n\6\2\u00ac\u00ae\3\2\2"+
		"\2\u00ad\u00a1\3\2\2\2\u00ad\u00a7\3\2\2\2\u00ae\21\3\2\2\2\u00af\u00b0"+
		"\7\'\2\2\u00b0\u00b1\7&\2\2\u00b1\u00b2\7\20\2\2\u00b2\u00b3\5\36\20\2"+
		"\u00b3\u00b4\7\21\2\2\u00b4\u00b5\5\f\7\2\u00b5\u00be\3\2\2\2\u00b6\u00b7"+
		"\7\'\2\2\u00b7\u00b8\7&\2\2\u00b8\u00b9\7\20\2\2\u00b9\u00ba\5\36\20\2"+
		"\u00ba\u00bb\7\21\2\2\u00bb\u00bc\5\n\6\2\u00bc\u00be\3\2\2\2\u00bd\u00af"+
		"\3\2\2\2\u00bd\u00b6\3\2\2\2\u00be\23\3\2\2\2\u00bf\u00c0\7\'\2\2\u00c0"+
		"\u00c4\5\f\7\2\u00c1\u00c2\7\'\2\2\u00c2\u00c4\5\n\6\2\u00c3\u00bf\3\2"+
		"\2\2\u00c3\u00c1\3\2\2\2\u00c4\25\3\2\2\2\u00c5\u00c6\7-\2\2\u00c6\u00c7"+
		"\7\20\2\2\u00c7\u00c8\5L\'\2\u00c8\u00c9\7\21\2\2\u00c9\27\3\2\2\2\u00ca"+
		"\u00cb\t\2\2\2\u00cb\u00ce\7\20\2\2\u00cc\u00cf\5\36\20\2\u00cd\u00cf"+
		"\7,\2\2\u00ce\u00cc\3\2\2\2\u00ce\u00cd\3\2\2\2\u00cf\u00d0\3\2\2\2\u00d0"+
		"\u00d1\7\21\2\2\u00d1\u00d2\7.\2\2\u00d2\31\3\2\2\2\u00d3\u00d4\7\6\2"+
		"\2\u00d4\u00d5\5\36\20\2\u00d5\u00d6\7.\2\2\u00d6\33\3\2\2\2\u00d7\u00d8"+
		"\t\3\2\2\u00d8\35\3\2\2\2\u00d9\u00da\b\20\1\2\u00da\u00f6\5&\24\2\u00db"+
		"\u00f6\5\26\f\2\u00dc\u00e1\7\n\2\2\u00dd\u00e2\5\62\32\2\u00de\u00e2"+
		"\5\66\34\2\u00df\u00e2\5\64\33\2\u00e0\u00e2\58\35\2\u00e1\u00dd\3\2\2"+
		"\2\u00e1\u00de\3\2\2\2\u00e1\u00df\3\2\2\2\u00e1\u00e0\3\2\2\2\u00e2\u00e3"+
		"\3\2\2\2\u00e3\u00e4\7\b\2\2\u00e4\u00e5\5\36\20\2\u00e5\u00e6\7\t\2\2"+
		"\u00e6\u00f6\3\2\2\2\u00e7\u00e9\7\22\2\2\u00e8\u00ea\5$\23\2\u00e9\u00e8"+
		"\3\2\2\2\u00e9\u00ea\3\2\2\2\u00ea\u00ef\3\2\2\2\u00eb\u00ec\7\5\2\2\u00ec"+
		"\u00ee\5$\23\2\u00ed\u00eb\3\2\2\2\u00ee\u00f1\3\2\2\2\u00ef\u00ed\3\2"+
		"\2\2\u00ef\u00f0\3\2\2\2\u00f0\u00f2\3\2\2\2\u00f1\u00ef\3\2\2\2\u00f2"+
		"\u00f6\7\23\2\2\u00f3\u00f6\5\"\22\2\u00f4\u00f6\5 \21\2\u00f5\u00d9\3"+
		"\2\2\2\u00f5\u00db\3\2\2\2\u00f5\u00dc\3\2\2\2\u00f5\u00e7\3\2\2\2\u00f5"+
		"\u00f3\3\2\2\2\u00f5\u00f4\3\2\2\2\u00f6\u010a\3\2\2\2\u00f7\u00f8\f\f"+
		"\2\2\u00f8\u00f9\t\4\2\2\u00f9\u0109\5\36\20\r\u00fa\u00fb\f\13\2\2\u00fb"+
		"\u00fc\t\5\2\2\u00fc\u0109\5\36\20\f\u00fd\u00fe\f\n\2\2\u00fe\u00ff\5"+
		"\34\17\2\u00ff\u0100\5\36\20\13\u0100\u0109\3\2\2\2\u0101\u0102\f\t\2"+
		"\2\u0102\u0109\7\7\2\2\u0103\u0104\f\b\2\2\u0104\u0105\7\b\2\2\u0105\u0106"+
		"\5\36\20\2\u0106\u0107\7\t\2\2\u0107\u0109\3\2\2\2\u0108\u00f7\3\2\2\2"+
		"\u0108\u00fa\3\2\2\2\u0108\u00fd\3\2\2\2\u0108\u0101\3\2\2\2\u0108\u0103"+
		"\3\2\2\2\u0109\u010c\3\2\2\2\u010a\u0108\3\2\2\2\u010a\u010b\3\2\2\2\u010b"+
		"\37\3\2\2\2\u010c\u010a\3\2\2\2\u010d\u010e\7-\2\2\u010e!\3\2\2\2\u010f"+
		"\u0115\5(\25\2\u0110\u0115\5*\26\2\u0111\u0115\5,\27\2\u0112\u0115\5."+
		"\30\2\u0113\u0115\5\60\31\2\u0114\u010f\3\2\2\2\u0114\u0110\3\2\2\2\u0114"+
		"\u0111\3\2\2\2\u0114\u0112\3\2\2\2\u0114\u0113\3\2\2\2\u0115#\3\2\2\2"+
		"\u0116\u011b\5(\25\2\u0117\u011b\5*\26\2\u0118\u011b\5.\30\2\u0119\u011b"+
		"\5,\27\2\u011a\u0116\3\2\2\2\u011a\u0117\3\2\2\2\u011a\u0118\3\2\2\2\u011a"+
		"\u0119\3\2\2\2\u011b%\3\2\2\2\u011c\u011d\7\20\2\2\u011d\u011e\5\36\20"+
		"\2\u011e\u011f\7\21\2\2\u011f\'\3\2\2\2\u0120\u0121\7\32\2\2\u0121)\3"+
		"\2\2\2\u0122\u0123\7\"\2\2\u0123+\3\2\2\2\u0124\u0125\7\31\2\2\u0125-"+
		"\3\2\2\2\u0126\u0127\7+\2\2\u0127/\3\2\2\2\u0128\u0129\7,\2\2\u0129\61"+
		"\3\2\2\2\u012a\u012b\7\37\2\2\u012b\63\3\2\2\2\u012c\u012d\7$\2\2\u012d"+
		"\65\3\2\2\2\u012e\u012f\7#\2\2\u012f\67\3\2\2\2\u0130\u0131\7!\2\2\u0131"+
		"9\3\2\2\2\u0132\u0133\7 \2\2\u0133;\3\2\2\2\u0134\u0135\7\33\2\2\u0135"+
		"=\3\2\2\2\u0136\u0137\7\34\2\2\u0137?\3\2\2\2\u0138\u0139\7\35\2\2\u0139"+
		"A\3\2\2\2\u013a\u013b\7\36\2\2\u013bC\3\2\2\2\u013c\u0146\5\62\32\2\u013d"+
		"\u0146\5\66\34\2\u013e\u0146\5\64\33\2\u013f\u0146\58\35\2\u0140\u0146"+
		"\5:\36\2\u0141\u0146\5<\37\2\u0142\u0146\5> \2\u0143\u0146\5@!\2\u0144"+
		"\u0146\5B\"\2\u0145\u013c\3\2\2\2\u0145\u013d\3\2\2\2\u0145\u013e\3\2"+
		"\2\2\u0145\u013f\3\2\2\2\u0145\u0140\3\2\2\2\u0145\u0141\3\2\2\2\u0145"+
		"\u0142\3\2\2\2\u0145\u0143\3\2\2\2\u0145\u0144\3\2\2\2\u0146E\3\2\2\2"+
		"\u0147\u014b\5D#\2\u0148\u014c\5J&\2\u0149\u014a\7-\2\2\u014a\u014c\7"+
		".\2\2\u014b\u0148\3\2\2\2\u014b\u0149\3\2\2\2\u014cG\3\2\2\2\u014d\u0152"+
		"\5 \21\2\u014e\u014f\7\b\2\2\u014f\u0150\5\36\20\2\u0150\u0151\7\t\2\2"+
		"\u0151\u0153\3\2\2\2\u0152\u014e\3\2\2\2\u0152\u0153\3\2\2\2\u0153\u0154"+
		"\3\2\2\2\u0154\u0155\7\13\2\2\u0155\u0156\5\36\20\2\u0156\u0157\7.\2\2"+
		"\u0157I\3\2\2\2\u0158\u015d\7-\2\2\u0159\u015a\7\b\2\2\u015a\u015b\5\36"+
		"\20\2\u015b\u015c\7\t\2\2\u015c\u015e\3\2\2\2\u015d\u0159\3\2\2\2\u015d"+
		"\u015e\3\2\2\2\u015e\u015f\3\2\2\2\u015f\u0160\7\13\2\2\u0160\u0161\5"+
		"\36\20\2\u0161\u0162\7.\2\2\u0162K\3\2\2\2\u0163\u0168\5\36\20\2\u0164"+
		"\u0165\7\5\2\2\u0165\u0167\5\36\20\2\u0166\u0164\3\2\2\2\u0167\u016a\3"+
		"\2\2\2\u0168\u0166\3\2\2\2\u0168\u0169\3\2\2\2\u0169\u016d\3\2\2\2\u016a"+
		"\u0168\3\2\2\2\u016b\u016d\3\2\2\2\u016c\u0163\3\2\2\2\u016c\u016b\3\2"+
		"\2\2\u016dM\3\2\2\2\36QX]ksz\u0084\u0088\u0091\u009f\u00ad\u00bd\u00c3"+
		"\u00ce\u00e1\u00e9\u00ef\u00f5\u0108\u010a\u0114\u011a\u0145\u014b\u0152"+
		"\u015d\u0168\u016c";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}