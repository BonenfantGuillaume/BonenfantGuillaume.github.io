// Generated from /home/sebastien/IdeaProjects/Guillaume.Bonenfant_Sebastien.Rocca.dv507.A2/src/LanguageExpressions.g4 by ANTLR 4.9.2
    // Define name of package for generated Java files. 
    package generated;  

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link LanguageExpressionsParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface LanguageExpressionsVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#start}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart(LanguageExpressionsParser.StartContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#functionExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#main}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMain(LanguageExpressionsParser.MainContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#fctParams}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFctParams(LanguageExpressionsParser.FctParamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(LanguageExpressionsParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code whileStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStat(LanguageExpressionsParser.WhileStatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStat(LanguageExpressionsParser.IfStatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code declStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclStat(LanguageExpressionsParser.DeclStatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignStat(LanguageExpressionsParser.AssignStatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code printStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintStat(LanguageExpressionsParser.PrintStatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code functionStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionStat(LanguageExpressionsParser.FunctionStatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code returnStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStat(LanguageExpressionsParser.ReturnStatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code whileNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#whileExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code whileBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#whileExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#ifEx}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#ifEx}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfBlock(LanguageExpressionsParser.IfBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code elseifNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseifExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code elseifBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseifExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code elseNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseNonBlock(LanguageExpressionsParser.ElseNonBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code elseBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseBlock(LanguageExpressionsParser.ElseBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#functionCall}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#printExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintExp(LanguageExpressionsParser.PrintExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#returnExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnExp(LanguageExpressionsParser.ReturnExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#conditionSigns}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConditionSigns(LanguageExpressionsParser.ConditionSignsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code newExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewExpr(LanguageExpressionsParser.NewExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code lengthExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLengthExpr(LanguageExpressionsParser.LengthExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code tableExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTableExpr(LanguageExpressionsParser.TableExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code fctExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFctExpr(LanguageExpressionsParser.FctExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arrayExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code plusMinusExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code condExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondExpr(LanguageExpressionsParser.CondExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code anyTypeExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyTypeExpr(LanguageExpressionsParser.AnyTypeExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code multDivExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code rbExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRbExpr(LanguageExpressionsParser.RbExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdExpr(LanguageExpressionsParser.IdExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#idCall}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdCall(LanguageExpressionsParser.IdCallContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#anyType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyType(LanguageExpressionsParser.AnyTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#anyTypeArr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyTypeArr(LanguageExpressionsParser.AnyTypeArrContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#rBExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRBExpr(LanguageExpressionsParser.RBExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#intType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntType(LanguageExpressionsParser.IntTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#boolType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolType(LanguageExpressionsParser.BoolTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#floatType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatType(LanguageExpressionsParser.FloatTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#charType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharType(LanguageExpressionsParser.CharTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#stringType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringType(LanguageExpressionsParser.StringTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#intDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntDecl(LanguageExpressionsParser.IntDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#floatDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatDecl(LanguageExpressionsParser.FloatDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#boolDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolDecl(LanguageExpressionsParser.BoolDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#charDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharDecl(LanguageExpressionsParser.CharDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#stringDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringDecl(LanguageExpressionsParser.StringDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#intArrDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntArrDecl(LanguageExpressionsParser.IntArrDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#floatArrDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatArrDecl(LanguageExpressionsParser.FloatArrDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#boolArrDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolArrDecl(LanguageExpressionsParser.BoolArrDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#charArrDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharArrDecl(LanguageExpressionsParser.CharArrDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#anyTypeDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclaration(LanguageExpressionsParser.DeclarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign(LanguageExpressionsParser.AssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#assign2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign2(LanguageExpressionsParser.Assign2Context ctx);
	/**
	 * Visit a parse tree produced by {@link LanguageExpressionsParser#args}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgs(LanguageExpressionsParser.ArgsContext ctx);
}