// Generated from /home/sebastien/IdeaProjects/Guillaume.Bonenfant_Sebastien.Rocca.dv507.A2/src/LanguageExpressions.g4 by ANTLR 4.9.2
    // Define name of package for generated Java files. 
    package generated;  

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link LanguageExpressionsParser}.
 */
public interface LanguageExpressionsListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#start}.
	 * @param ctx the parse tree
	 */
	void enterStart(LanguageExpressionsParser.StartContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#start}.
	 * @param ctx the parse tree
	 */
	void exitStart(LanguageExpressionsParser.StartContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#functionExp}.
	 * @param ctx the parse tree
	 */
	void enterFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#functionExp}.
	 * @param ctx the parse tree
	 */
	void exitFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#main}.
	 * @param ctx the parse tree
	 */
	void enterMain(LanguageExpressionsParser.MainContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#main}.
	 * @param ctx the parse tree
	 */
	void exitMain(LanguageExpressionsParser.MainContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#fctParams}.
	 * @param ctx the parse tree
	 */
	void enterFctParams(LanguageExpressionsParser.FctParamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#fctParams}.
	 * @param ctx the parse tree
	 */
	void exitFctParams(LanguageExpressionsParser.FctParamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(LanguageExpressionsParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(LanguageExpressionsParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code whileStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterWhileStat(LanguageExpressionsParser.WhileStatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code whileStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitWhileStat(LanguageExpressionsParser.WhileStatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterIfStat(LanguageExpressionsParser.IfStatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitIfStat(LanguageExpressionsParser.IfStatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code declStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterDeclStat(LanguageExpressionsParser.DeclStatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code declStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitDeclStat(LanguageExpressionsParser.DeclStatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterAssignStat(LanguageExpressionsParser.AssignStatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitAssignStat(LanguageExpressionsParser.AssignStatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code printStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterPrintStat(LanguageExpressionsParser.PrintStatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code printStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitPrintStat(LanguageExpressionsParser.PrintStatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code functionStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterFunctionStat(LanguageExpressionsParser.FunctionStatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code functionStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitFunctionStat(LanguageExpressionsParser.FunctionStatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code returnStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterReturnStat(LanguageExpressionsParser.ReturnStatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code returnStat}
	 * labeled alternative in {@link LanguageExpressionsParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitReturnStat(LanguageExpressionsParser.ReturnStatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code whileNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#whileExp}.
	 * @param ctx the parse tree
	 */
	void enterWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code whileNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#whileExp}.
	 * @param ctx the parse tree
	 */
	void exitWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code whileBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#whileExp}.
	 * @param ctx the parse tree
	 */
	void enterWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code whileBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#whileExp}.
	 * @param ctx the parse tree
	 */
	void exitWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#ifEx}.
	 * @param ctx the parse tree
	 */
	void enterIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#ifEx}.
	 * @param ctx the parse tree
	 */
	void exitIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#ifEx}.
	 * @param ctx the parse tree
	 */
	void enterIfBlock(LanguageExpressionsParser.IfBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#ifEx}.
	 * @param ctx the parse tree
	 */
	void exitIfBlock(LanguageExpressionsParser.IfBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code elseifNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseifExp}.
	 * @param ctx the parse tree
	 */
	void enterElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code elseifNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseifExp}.
	 * @param ctx the parse tree
	 */
	void exitElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code elseifBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseifExp}.
	 * @param ctx the parse tree
	 */
	void enterElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code elseifBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseifExp}.
	 * @param ctx the parse tree
	 */
	void exitElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code elseNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseExp}.
	 * @param ctx the parse tree
	 */
	void enterElseNonBlock(LanguageExpressionsParser.ElseNonBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code elseNonBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseExp}.
	 * @param ctx the parse tree
	 */
	void exitElseNonBlock(LanguageExpressionsParser.ElseNonBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code elseBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseExp}.
	 * @param ctx the parse tree
	 */
	void enterElseBlock(LanguageExpressionsParser.ElseBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code elseBlock}
	 * labeled alternative in {@link LanguageExpressionsParser#elseExp}.
	 * @param ctx the parse tree
	 */
	void exitElseBlock(LanguageExpressionsParser.ElseBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void enterFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void exitFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#printExp}.
	 * @param ctx the parse tree
	 */
	void enterPrintExp(LanguageExpressionsParser.PrintExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#printExp}.
	 * @param ctx the parse tree
	 */
	void exitPrintExp(LanguageExpressionsParser.PrintExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#returnExp}.
	 * @param ctx the parse tree
	 */
	void enterReturnExp(LanguageExpressionsParser.ReturnExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#returnExp}.
	 * @param ctx the parse tree
	 */
	void exitReturnExp(LanguageExpressionsParser.ReturnExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#conditionSigns}.
	 * @param ctx the parse tree
	 */
	void enterConditionSigns(LanguageExpressionsParser.ConditionSignsContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#conditionSigns}.
	 * @param ctx the parse tree
	 */
	void exitConditionSigns(LanguageExpressionsParser.ConditionSignsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code newExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNewExpr(LanguageExpressionsParser.NewExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code newExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNewExpr(LanguageExpressionsParser.NewExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code lengthExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLengthExpr(LanguageExpressionsParser.LengthExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code lengthExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLengthExpr(LanguageExpressionsParser.LengthExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code tableExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterTableExpr(LanguageExpressionsParser.TableExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code tableExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitTableExpr(LanguageExpressionsParser.TableExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code fctExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFctExpr(LanguageExpressionsParser.FctExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code fctExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFctExpr(LanguageExpressionsParser.FctExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arrayExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arrayExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code plusMinusExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code plusMinusExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code condExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterCondExpr(LanguageExpressionsParser.CondExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code condExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitCondExpr(LanguageExpressionsParser.CondExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code anyTypeExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAnyTypeExpr(LanguageExpressionsParser.AnyTypeExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code anyTypeExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAnyTypeExpr(LanguageExpressionsParser.AnyTypeExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code multDivExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code multDivExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code rbExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterRbExpr(LanguageExpressionsParser.RbExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code rbExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitRbExpr(LanguageExpressionsParser.RbExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIdExpr(LanguageExpressionsParser.IdExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link LanguageExpressionsParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIdExpr(LanguageExpressionsParser.IdExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#idCall}.
	 * @param ctx the parse tree
	 */
	void enterIdCall(LanguageExpressionsParser.IdCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#idCall}.
	 * @param ctx the parse tree
	 */
	void exitIdCall(LanguageExpressionsParser.IdCallContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#anyType}.
	 * @param ctx the parse tree
	 */
	void enterAnyType(LanguageExpressionsParser.AnyTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#anyType}.
	 * @param ctx the parse tree
	 */
	void exitAnyType(LanguageExpressionsParser.AnyTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#anyTypeArr}.
	 * @param ctx the parse tree
	 */
	void enterAnyTypeArr(LanguageExpressionsParser.AnyTypeArrContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#anyTypeArr}.
	 * @param ctx the parse tree
	 */
	void exitAnyTypeArr(LanguageExpressionsParser.AnyTypeArrContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#rBExpr}.
	 * @param ctx the parse tree
	 */
	void enterRBExpr(LanguageExpressionsParser.RBExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#rBExpr}.
	 * @param ctx the parse tree
	 */
	void exitRBExpr(LanguageExpressionsParser.RBExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#intType}.
	 * @param ctx the parse tree
	 */
	void enterIntType(LanguageExpressionsParser.IntTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#intType}.
	 * @param ctx the parse tree
	 */
	void exitIntType(LanguageExpressionsParser.IntTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#boolType}.
	 * @param ctx the parse tree
	 */
	void enterBoolType(LanguageExpressionsParser.BoolTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#boolType}.
	 * @param ctx the parse tree
	 */
	void exitBoolType(LanguageExpressionsParser.BoolTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#floatType}.
	 * @param ctx the parse tree
	 */
	void enterFloatType(LanguageExpressionsParser.FloatTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#floatType}.
	 * @param ctx the parse tree
	 */
	void exitFloatType(LanguageExpressionsParser.FloatTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#charType}.
	 * @param ctx the parse tree
	 */
	void enterCharType(LanguageExpressionsParser.CharTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#charType}.
	 * @param ctx the parse tree
	 */
	void exitCharType(LanguageExpressionsParser.CharTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#stringType}.
	 * @param ctx the parse tree
	 */
	void enterStringType(LanguageExpressionsParser.StringTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#stringType}.
	 * @param ctx the parse tree
	 */
	void exitStringType(LanguageExpressionsParser.StringTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#intDecl}.
	 * @param ctx the parse tree
	 */
	void enterIntDecl(LanguageExpressionsParser.IntDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#intDecl}.
	 * @param ctx the parse tree
	 */
	void exitIntDecl(LanguageExpressionsParser.IntDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#floatDecl}.
	 * @param ctx the parse tree
	 */
	void enterFloatDecl(LanguageExpressionsParser.FloatDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#floatDecl}.
	 * @param ctx the parse tree
	 */
	void exitFloatDecl(LanguageExpressionsParser.FloatDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#boolDecl}.
	 * @param ctx the parse tree
	 */
	void enterBoolDecl(LanguageExpressionsParser.BoolDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#boolDecl}.
	 * @param ctx the parse tree
	 */
	void exitBoolDecl(LanguageExpressionsParser.BoolDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#charDecl}.
	 * @param ctx the parse tree
	 */
	void enterCharDecl(LanguageExpressionsParser.CharDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#charDecl}.
	 * @param ctx the parse tree
	 */
	void exitCharDecl(LanguageExpressionsParser.CharDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#stringDecl}.
	 * @param ctx the parse tree
	 */
	void enterStringDecl(LanguageExpressionsParser.StringDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#stringDecl}.
	 * @param ctx the parse tree
	 */
	void exitStringDecl(LanguageExpressionsParser.StringDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#intArrDecl}.
	 * @param ctx the parse tree
	 */
	void enterIntArrDecl(LanguageExpressionsParser.IntArrDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#intArrDecl}.
	 * @param ctx the parse tree
	 */
	void exitIntArrDecl(LanguageExpressionsParser.IntArrDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#floatArrDecl}.
	 * @param ctx the parse tree
	 */
	void enterFloatArrDecl(LanguageExpressionsParser.FloatArrDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#floatArrDecl}.
	 * @param ctx the parse tree
	 */
	void exitFloatArrDecl(LanguageExpressionsParser.FloatArrDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#boolArrDecl}.
	 * @param ctx the parse tree
	 */
	void enterBoolArrDecl(LanguageExpressionsParser.BoolArrDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#boolArrDecl}.
	 * @param ctx the parse tree
	 */
	void exitBoolArrDecl(LanguageExpressionsParser.BoolArrDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#charArrDecl}.
	 * @param ctx the parse tree
	 */
	void enterCharArrDecl(LanguageExpressionsParser.CharArrDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#charArrDecl}.
	 * @param ctx the parse tree
	 */
	void exitCharArrDecl(LanguageExpressionsParser.CharArrDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#anyTypeDecl}.
	 * @param ctx the parse tree
	 */
	void enterAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#anyTypeDecl}.
	 * @param ctx the parse tree
	 */
	void exitAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#declaration}.
	 * @param ctx the parse tree
	 */
	void enterDeclaration(LanguageExpressionsParser.DeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#declaration}.
	 * @param ctx the parse tree
	 */
	void exitDeclaration(LanguageExpressionsParser.DeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssign(LanguageExpressionsParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssign(LanguageExpressionsParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#assign2}.
	 * @param ctx the parse tree
	 */
	void enterAssign2(LanguageExpressionsParser.Assign2Context ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#assign2}.
	 * @param ctx the parse tree
	 */
	void exitAssign2(LanguageExpressionsParser.Assign2Context ctx);
	/**
	 * Enter a parse tree produced by {@link LanguageExpressionsParser#args}.
	 * @param ctx the parse tree
	 */
	void enterArgs(LanguageExpressionsParser.ArgsContext ctx);
	/**
	 * Exit a parse tree produced by {@link LanguageExpressionsParser#args}.
	 * @param ctx the parse tree
	 */
	void exitArgs(LanguageExpressionsParser.ArgsContext ctx);
}