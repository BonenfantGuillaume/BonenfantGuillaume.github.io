package asm_test;

public class iftest {
    
    public static void main(String args[])
    {
        int a = 5; 
        if(7 > 6)
        {
            System.out.println("oui");
        }
    }
}
