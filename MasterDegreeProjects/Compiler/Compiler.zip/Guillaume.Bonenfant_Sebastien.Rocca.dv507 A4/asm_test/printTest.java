package asm_test;

public class printTest {
    
    public static void main(String args[])
    {
        countA("oui"); 
        
    }

    public static int countA(String str1)
    {   
        //System.out.println(str1);
        return 1; 
    }
}
