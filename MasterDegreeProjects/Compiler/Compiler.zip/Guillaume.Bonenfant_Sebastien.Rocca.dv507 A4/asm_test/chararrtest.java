package asm_test;

public class chararrtest {
    public static void main(String args[])
    {
        char[] a = {'a', 'b', 'e'};
        System.out.println(a);
        //a[2] = 'c';
        //System.out.println(a); 
    
        char[] r = replace(a, 'e', 'e');
        System.out.println(r); 
        //char[] a =  {'a', 'b', 'c'};
        //System.out.println(a);
        //a[2] = 'd'; 
        //System.out.println(a);

    }

    public static char[] replace(char[] str, char oldChar, char newChar) {
        int i = 0;
        while (i < str.length) {
            char c = str[i];
            System.out.println(c); 
            if (c == oldChar)
            {
                System.out.println(c); 
                //str[i] = 'o';
            }
        
            i = i+1;
        }
    
    return str;
    }

}
