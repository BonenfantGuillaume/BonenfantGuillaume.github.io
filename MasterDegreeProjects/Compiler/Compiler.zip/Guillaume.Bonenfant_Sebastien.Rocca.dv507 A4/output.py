def mult(a, n, b):
	return a * b

def fct_max(a, b):
	if (a > b):
 		return a
	else:
 		return b

if __name__ == "__main__": 
	f = 2.34
	ff = 2.0
	fff = mult(f, 5, ff)
	print(fff)
	fff = fct_max(f, ff)
	print(fff)
