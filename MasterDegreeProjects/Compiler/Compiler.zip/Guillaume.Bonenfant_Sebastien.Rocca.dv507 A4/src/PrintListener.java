package src; 

import generated.LanguageExpressionsBaseListener;
import generated.LanguageExpressionsParser;


import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

public class PrintListener extends LanguageExpressionsBaseListener {
    int s = 0;

    public void enter(LanguageExpressionsParser ctx)
    {

        System.out.println(s + ctx.getClass().getName());
    }

    public void exit()
    {
        
    }

	//start : functionExp* main functionExp*;
    @Override public void enterStart(LanguageExpressionsParser.StartContext ctx) {

        System.out.println(("hello"));
        System.out.println();
    }

    //functionExp : (anyTypeDecl|'void') ID LRB fctParams RRB block;
    @Override public void enterFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx) {
        //System.out.println(ctx.getClass().getSimpleName());
     }


    //WHILE LRB expr RRB stat      #whileNonBlock
    @Override public void enterWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx)
    {
        System.out.println("While non block statement");
    }

    //WHILE LRB expr RRB block        #whileBlock
    @Override public void enterWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx)
    {
        System.out.println("While block statement");
    }

    //IF LRB expr RRB stat             #ifNonBlock
    @Override public void enterIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx)
    {
        System.out.println("If non block statement");
    }

    //IF LRB expr RRB block              #ifBlock
    @Override public void enterIfBlock(LanguageExpressionsParser.IfBlockContext ctx)
    {
        System.out.println("If block statement");
    }

    //ELSE IF LRB expr RRB stat   #elseifNonBlock
    @Override public void enterElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx)
    {
        System.out.println("Else if non block statement");
    }

    //ELSE IF LRB expr RRB block     #elseifBlock
    @Override public void enterElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx)
    {
        System.out.println("Else if block statement");
    }

    //ELSE stat                     #elseNonBlock
    @Override public void enterElseNonBlock(LanguageExpressionsParser.ElseNonBlockContext ctx)
    {
        System.out.println("Else non block statement");
    }

    //ELSE block                       #elseBlock
    @Override public void enterElseBlock(LanguageExpressionsParser.ElseBlockContext ctx)
    {
        System.out.println("Else block statement");
    }


    //functionCallStat : ID '(' args ')';
    @Override public void enterFunctionCallStat(LanguageExpressionsParser.FunctionCallStatContext ctx)
    {
        String s = "Function : " + ctx.getChild(0).getText();
    }

    //functionCall : '(' args ')';
    @Override public void enterFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx)
    {
        String s = "Function call";
    }


    //printExp : (PRINT|PRINTLN) '(' (expr|STRING) ')' SC;
    @Override public void enterPrintExp(LanguageExpressionsParser.PrintExpContext ctx)
    {
        System.out.println(ctx.getChild(0).getText() + "(" + ctx.getChild(2).getText() + ")");
    }


    //returnExp : 'return' (expr) SC;
    @Override public void enterReturnExp(LanguageExpressionsParser.ReturnExpContext ctx)
    {
        System.out.println("return");
    }

    //conditionSigns : (LOWER|UPPER|EQUAL);
    @Override public void enterConditionSigns(LanguageExpressionsParser.ConditionSignsContext ctx)
    {
        System.out.println("Condition sign : " + ctx.getChild(0).getText());
    }


    //rBExpr                                                                  #rbExpr
    @Override public void enterRbExpr(LanguageExpressionsParser.RbExprContext ctx)
    {
        System.out.println("RBExprex");
    }


    //expr (MULT | DIV) expr                                                #multDivExpr
    @Override public void enterMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx)
    {
        if(ctx.getChild(1).getText().equals("*"))
        {
            System.out.println("Multiplication");
        }
        else if(ctx.getChild(1).getText().equals("/"))
        {
            System.out.println("Division");
        }
    }


    //expr (PLUS | MINUS) expr                                              #plusMinusExpr
    @Override public void enterPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx)
    {
        if(ctx.getChild(1).getText().equals("+"))
        {
            System.out.println("Addition");
        }
        else if(ctx.getChild(1).getText().equals("-"))
        {
            System.out.println("Substraction");
        }
    }


    //expr conditionSigns expr                                              #condExpr
    @Override public void enterCondExpr(LanguageExpressionsParser.CondExprContext ctx)
    {
        System.out.println("Condition expression");
    }


    //expr ('.length')                                                      #lengthExpr
    @Override public void enterLengthExpr(LanguageExpressionsParser.LengthExprContext ctx)
    {
        System.out.println("Length expression");
    }


    //expr ('[' expr ']')                                                   #tableExpr
    @Override public void enterTableExpr(LanguageExpressionsParser.TableExprContext ctx)
    {
        System.out.println("Table expression");
    }


    //ID (functionCall)                                                     #fctExpr
    @Override public void enterFctExpr(LanguageExpressionsParser.FctExprContext ctx)
    {
        System.out.println("Function expression : " + ctx.getChild(0).getText());
    }


    //'new ' (INTDECL|BOOLDECL|FLOATDECL|CHARDECL) '[' expr ']'             #newExpr
    @Override public void enterNewExpr(LanguageExpressionsParser.NewExprContext ctx)
    {
        System.out.println("New " + ctx.getChild(1).getText() + " expression");
    }


    //'{' (anyTypeArr)? (',' anyTypeArr)* '}'                               #arrayExpr
    @Override public void enterArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx)
    {
        System.out.print("Array expression : {" + ctx.getChild(1));

        for(int i = 4; i <= ctx.getChildCount() - 1 ; i+=2)
        {
            System.out.print(", " + ctx.getChild(i).getText());
        }

        System.out.println("}");
    }


    //anyType                                                               #anyTypeExpr
    @Override public void enterAnyTypeExpr(LanguageExpressionsParser.AnyTypeExprContext ctx)
    {
        System.out.println("Any type expression");
    }


    //ID                                                                    #idExpr
    @Override public void enterIdExpr(LanguageExpressionsParser.IdExprContext ctx)
    {
        System.out.println("ID expression : " + ctx.getChild(0).getText());
    }


    //anyType :  BOOL | FLOAT | CHAR | INT | STRING;
    @Override public void enterAnyType(LanguageExpressionsParser.AnyTypeContext ctx)
    {
        System.out.println("Value : " + ctx.getChild(0).getText());
    }


    //anyTypeArr : BOOL | FLOAT | CHAR | INT;
    @Override public void enterAnyTypeArr(LanguageExpressionsParser.AnyTypeArrContext ctx)
    {
        System.out.println("Any type array : " + ctx.getChild(0).getText());
    }


    //rBExpr : LRB expr RRB ;   // Round bracket expression
    @Override public void enterRBExpr(LanguageExpressionsParser.RBExprContext ctx)
    {
        System.out.println("RB expression");
    }

    //anyTypeDecl : (INTDECL|BOOLDECL|FLOATDECL|CHARDECL|STRINGDECL|INTARRDECL|FLOATARRDECL|BOOLARRDECL|CHARARRDECL);
    @Override public void enterAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx)
    {
        System.out.println("Type : " + ctx.getChild(0).getText());
    }

    //declaration : anyTypeDecl (assign | ID SC);
    @Override public void enterDeclaration(LanguageExpressionsParser.DeclarationContext ctx)
    {
        System.out.println("Declaration");
    }

    //assign : ID ('[' (expr) ']')* ASSIGN expr SC;
    @Override public void enterAssign(LanguageExpressionsParser.AssignContext ctx)
    {
        System.out.print("Assign : " + ctx.getChild(0).getText());

        for(int i = 2; i < ctx.getChildCount() - 3 ; i+=3)
        {
            System.out.print("[" + ctx.getChild(i).getText() + "]");
        }

        System.out.print(" = " + ctx.getChild(ctx.getChildCount()-2).getText());
        System.out.println();
    }

    //args : (expr (',' expr)*|) ;
    @Override public void enterArgs(LanguageExpressionsParser.ArgsContext ctx)
    {
        if(ctx.getChild(0) != null)
        {
            System.out.print("Args : " + ctx.getChild(0).getText());

            for(int i = 2; i < ctx.getChildCount() ; i+=2)
            {
            System.out.print(", " + ctx.getChild(i).getText());
            }
        
            System.out.println();
        }
    }


    
}
