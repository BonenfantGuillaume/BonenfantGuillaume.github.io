package src;

import java.util.ArrayList;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

import generated.LanguageExpressionsBaseListener;
import generated.LanguageExpressionsParser;

public class SymbolTableListener extends LanguageExpressionsBaseListener {

    int s = 0;

    private ParseTreeProperty<Scope> scopes = new ParseTreeProperty<Scope>(); 

    private ArrayList<Symbol> addToScope = new ArrayList<Symbol>();
    
    public ParseTreeProperty<Scope> getSymbolTable() 
    { 
        return scopes;
    }

    private Scope currentScope = new Scope(null);
    private FunctionSymbol currentFunctionSymbol = null;

	@Override public void enterStart(LanguageExpressionsParser.StartContext ctx) { 

        scopes.put(ctx, currentScope);
    }

    

    //functionExp : (anyTypeDecl|'void') ID LRB fctParams RRB block; 
    @Override public void enterFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx) {
        String typeName = ctx.getChild(0).getText(); 
        String name = ctx.getChild(1).getText(); 

        OFPType type = OFPType.getTypeFor(typeName);

        if(currentScope.localResolve(name))
        {
            throw new RuntimeException("Function already declared in this scope.");
        }

        FunctionSymbol sym = new FunctionSymbol(name, typeName);
        currentFunctionSymbol = sym;
        currentScope.define(sym);
     }

     @Override public void enterMain(LanguageExpressionsParser.MainContext ctx)
     {
        String typeName = "void"; 
        String name = "main"; 

        OFPType type = OFPType.getTypeFor(typeName);

        if(currentScope.localResolve(name))
        {
            System.out.println("Function already declared in this scope.");
        }

        FunctionSymbol sym = new FunctionSymbol(name, typeName);
        currentFunctionSymbol = sym;
        currentScope.define(sym);

        currentScope = new Scope(currentScope); // Associate scope with the Syntax Three Node
        scopes.put(ctx, currentScope);
        currentScope.setScopeName("main");       
     }  

     @Override public void exitMain(LanguageExpressionsParser.MainContext ctx)
     {
        currentScope = currentScope.getEnclosingScope();
     }


     //fctParams : (anyTypeDecl ID)? (',' anyTypeDecl ID)* ;
     @Override public void enterFctParams(LanguageExpressionsParser.FctParamsContext ctx)
     {
        int i = 0;

        while(i < ctx.getChildCount())
        {
            String argType = ctx.getChild(i).getText(); 
            String argName = ctx.getChild(i+1).getText(); 

            ParamSymbol prmSmb = new ParamSymbol(argName, OFPType.getTypeFor(argType)); 
            currentFunctionSymbol.addParam(prmSmb.getType());
            addToScope.add(prmSmb);
            i = i + 3;
        }
     }
    

    //block : LCB stat* RCB;
    @Override public void enterBlock(LanguageExpressionsParser.BlockContext ctx)
    {
        Scope nScope = new Scope(currentScope);
        currentScope = nScope;
        for(Symbol symbol: addToScope)
        {
            currentScope.define(symbol);
        }
        addToScope = new ArrayList<Symbol>();
        currentScope.setScopeName(currentFunctionSymbol.getName()); //what should we give for while... ?
    }

    @Override public void exitBlock(LanguageExpressionsParser.BlockContext ctx)
    {
        scopes.put(ctx, currentScope);
        currentScope = currentScope.getEnclosingScope(); 
    }

    //declaration : anyTypeDecl (assign2 | ID SC);
    @Override public void enterDeclaration(LanguageExpressionsParser.DeclarationContext ctx)
    {        
        String declType = ctx.getChild(0).getText();
        String declName = ctx.getChild(1).getChild(0).getText();//enterAssignName(ctx.getChild(1));//ctx.getChild(1).getText();


        if(!currentScope.localResolve(declName))
        {
            Symbol decSymbol = new Symbol(declName, OFPType.getTypeFor(declType)); 
            currentScope.define(decSymbol);
        }
        else
        {
            System.out.println("Variable already declared in this scope.");
        }

        
    }

    public String enterAssignName(LanguageExpressionsParser.Assign2Context ctx)
    {
        return ctx.getChild(0).getText();
    }
}
