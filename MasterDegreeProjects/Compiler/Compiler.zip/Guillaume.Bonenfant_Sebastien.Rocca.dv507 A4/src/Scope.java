package src;

import java.util.LinkedHashMap;
import java.util.Map;

public class Scope {
    private Scope enclosingScope; 

    private String scopeName = ""; 

    private Map<String, Symbol> symbols = new LinkedHashMap<String, Symbol>();
    
    public Scope(Scope enclosingScope) {
        this.enclosingScope = enclosingScope; 
    }
    public Scope getEnclosingScope() { return enclosingScope;}

    public void define(Symbol sym) { symbols.put(sym.getName(), sym); }

    public Symbol resolve(String name)
    {
        if(symbols.containsKey(name))
        {
            return symbols.get(name);
        }
        else
        {
            if (enclosingScope != null)
            {
                return enclosingScope.resolve(name);    
            }
            return null;
        }
    }

    public boolean localResolve(String name)
    {
        if(symbols.containsKey(name))
        {
            return true;
        }
        return false; 

    }

    @Override
    public String toString()
    {
        if (enclosingScope != null)
            return symbols.toString() + " Enclosing scope values : " +  enclosingScope.toString();
        return symbols.toString();
            
    }

    public void setScopeName(String name)
    {
        this.scopeName = name; 
    }

    public String getScopeName()
    {
        return scopeName;
    }
    
}
