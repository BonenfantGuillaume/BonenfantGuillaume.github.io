package src;

public class OFPType {
    public static final OFPType intType = new OFPType("int");
    public static final OFPType intArrType = new OFPType("int[]");
    public static final OFPType floatType = new  OFPType("float");
    public static final OFPType floatArrType = new  OFPType("float[]");
    public static final OFPType charType = new  OFPType("char");
    public static final OFPType charArrType = new  OFPType("char[]");
    public static final OFPType boolType = new OFPType("bool");
    public static final OFPType boolArrType = new OFPType("bool[]");
    public static final OFPType stringType = new OFPType("string");
    public static final OFPType voidType = new OFPType("void");

    public static final OFPType argsType = new OFPType("String[]");

    public static OFPType getTypeFor(String typeName)
    {
        switch (typeName) {
            case "int":
                return intType;
            case "int[]":
                return intArrType;
            case "float":
                return floatType;
            case "float[]":
                return floatArrType;
            case "char":
                return charType;
            case "char[]":
                return charArrType;
            case "bool":
                return boolType;
            case "bool[]":
                return boolArrType;
            case "string":
                return stringType;
            case "void":
                return voidType;
            case "String[]":
                return argsType;
            default:
                return null; 
            } 
    }

    private final String name; 
    private OFPType(String name) { this.name = name;}

    private String getName(){return name;}

    @Override
    public String toString() {return name;}



    
}
