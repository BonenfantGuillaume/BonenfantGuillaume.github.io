package src;

public class ParamSymbol extends Symbol {

    public ParamSymbol(String name, OFPType type) {
        super(name, type);
    }
    
    
}

