package src;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import org.antlr.runtime.tree.ParseTree;
import org.antlr.v4.codegen.model.SrcOp;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.antlr.v4.runtime.tree.TerminalNode;

import generated.LanguageExpressionsBaseVisitor;
import generated.LanguageExpressionsParser;

import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors
import java.io.FileWriter;   // Import the FileWriter class

public class PythonCodeGeneratorVisitor extends LanguageExpressionsBaseVisitor<Object> {

    private ParseTreeProperty<Scope> scopes; 
    private Scope currentScope; 

    private String d;

    private int nb_indent = 0; 

    private String indent_string;

    private ArrayList<String> code = new ArrayList<String>();

    private static HashSet<String> reservedIds = new HashSet<String>(Arrays.asList("False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield", "ArithmeticError", "AssertionError", "AttributeError", "BaseException", "BlockingIOError", "BrokenPipeError", "BufferError", "BytesWarning", "ChildProcessError", "ConnectionAbortedError", "ConnectionError", "ConnectionRefusedError", "ConnectionResetError", "DeprecationWarning", "EOFError", "Ellipsis", "EnvironmentError", "Exception", "False", "FileExistsError", "FileNotFoundError", "FloatingPointError", "FutureWarning", "GeneratorExit", "IOError", "ImportError", "ImportWarning", "IndentationError", "IndexError", "InterruptedError", "IsADirectoryError", "KeyError", "KeyboardInterrupt", "LookupError", "MemoryError", "NameError", "None", "NotADirectoryError", "NotImplemented", "NotImplementedError", "OSError", "OverflowError", "PendingDeprecationWarning", "PermissionError", "ProcessLookupError", "RecursionError", "ReferenceError", "ResourceWarning", "RuntimeError", "RuntimeWarning", "StopAsyncIteration", "StopIteration", "SyntaxError", "SyntaxWarning", "SystemError", "SystemExit", "TabError", "TimeoutError", "True", "TypeError", "UnboundLocalError", "UnicodeDecodeError", "UnicodeEncodeError", "UnicodeError", "UnicodeTranslateError", "UnicodeWarning", "UserWarning", "ValueError", "Warning", "ZeroDivisionError", "__build_class__", "__debug__", "__doc__", "__import__", "__loader__", "__name__", "__package__", "__spec__", "abs", "all", "any", "ascii", "bin", "bool", "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex", "copyright", "credits", "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec", "exit", "filter", "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter", "len", "license", "list", "locals", "map", "max", "memoryview", "min", "next", "object", "oct", "open", "ord", "pow", "print", "property", "quit", "range", "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super", "tuple", "type", "vars", "zip"));

    //issue 2
    private int indent = 0;

    public PythonCodeGeneratorVisitor(ParseTreeProperty<Scope> scopes)
    {
        this.scopes = scopes; 
    }

    public boolean fileCreating()
    {
        //Creating file
        try {
            File myFile = new File("output.py");
            if (!myFile.createNewFile()) 
            {
                System.out.println("WARNING : File already exists. deletion.");
                myFile.delete();
                myFile.createNewFile();

            }
        } catch (IOException e) {
            System.out.println("ERROR : An error has occurred.");
            e.printStackTrace();
            return false;
        }
        

        //Writing in file
        try {
            FileWriter myWriter = new FileWriter("output.py");
            for(String s : code)
            {
                myWriter.write(s);
            }
            myWriter.close();
          } catch (IOException e) {
            System.out.println("ERROR : An error has occurred.");
            e.printStackTrace();
            return false;
          }


        return true;
    }


    @Override
    public String visitStart(LanguageExpressionsParser.StartContext ctx)
    {
        currentScope = scopes.get(ctx); 
        StringBuilder buf = new StringBuilder();  // for generated python code

        ParserRuleContext main = null; 

        for (int i=0; i < ctx.getChildCount(); i++)
        {
            ParserRuleContext p = (ParserRuleContext) ctx.getChild(i);
            String fName = p.getChild(1).getText(); 
            if (p.getChild(0).getText().equals("void main()"))
            {
                main = p; 
            }
            else
            {
                //buf.append(visit(p));  // Visit non main function 
                String fct = (String) visit(p);
                code.add(fct);
            }
        }

        buf.append(visit(main));
        
        String mainString = (String) visit(main);
        code.add("if __name__ == \"__main__\": \n"); 
        code.add(mainString);

        fileCreating();

        return buf.toString(); 
    }

    @Override
    public String visitFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx)
    {
        String id = ctx.getChild(1).getText();
        String args = (String) visit(ctx.getChild(3));
        String block = (String) visit(ctx.getChild(5));
        if(reservedIds.contains(id))
        {
            return "def fct_" + id + "(" + args + "):\n" + block + "\n"; 
        }
        return "def " + id + "(" + args + "):\n" + block + "\n";
    }

    @Override
    public String visitMain(LanguageExpressionsParser.MainContext ctx)
    {
        String block = (String) visit(ctx.getChild(1));
        return block;
    }

    @Override
    public String visitFctParams(LanguageExpressionsParser.FctParamsContext ctx)
    {
        String s = "";
        for (int i = 1; i < ctx.getChildCount(); i += 3)
        {
            if (i != 1)
                s += ", ";
            
            String varName = ctx.getChild(i).getText();
            if(reservedIds.contains(varName))
            {
                varName = "var_" + varName;
            }
            s += varName;
        }
        return s;
    }

    @Override
    public String visitBlock(LanguageExpressionsParser.BlockContext ctx)
    {
        nb_indent++; 
        addIndent(nb_indent);
        String stats = "";
        for (int i = 1; i < ctx.getChildCount() -1 ; i++)
        {
            stats += (String) visit(ctx.getChild(i));
        }
        nb_indent--;
        removeIndent(nb_indent);
        return stats;
    }


    ////////////////
    ////////////////
    ////////////////
    //Statements

    @Override
    public String visitWhileStat(LanguageExpressionsParser.WhileStatContext ctx)
    {
        String s = (String) visit(ctx.getChild(0)); 
        return s + "\n"; 
    }

    @Override
    public String visitWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx)
    {
        String condExpr = (String) visit(ctx.getChild(2));
        String child = (String) visit(ctx.getChild(4));
        return indent_string + "while(" + condExpr + "): \n" + child; 
    }

    @Override
    public String visitWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx)
    {
        String condExpr = (String) visit(ctx.getChild(2));
        String child = (String) visit(ctx.getChild(4));
        return indent_string + "while(" + condExpr + "): \n \t" + child; 
    }


    @Override 
    public String visitIfStat(LanguageExpressionsParser.IfStatContext ctx)
    {
        String s1 = (String) visit(ctx.getChild(0));
        String s2 = "";
        String s3 = "";

        for (int i = 1; i <= ctx.getChildCount() - 1; i++)
        {
            if (ctx.getChild(i).getChildCount() == 6)
            {
                s2 += (String) visit(ctx.getChild(i));
            }
            else if (ctx.getChild(i).getChildCount() == 2)
            {
                s3 += (String) visit(ctx.getChild(i));
            }
        }

        return s1 + s2 + s3;
    }

    @Override 
    public String visitIfBlock(LanguageExpressionsParser.IfBlockContext ctx)
    {
        String expr = (String) visit(ctx.getChild(2));
        String stat = (String) visit(ctx.getChild(4));
        return indent_string + "if (" + expr + "):\n" + stat;
    }

    @Override 
    public String visitIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx)
    {
        String expr = (String) visit(ctx.getChild(2));
        String stat = (String) visit(ctx.getChild(4));
        return indent_string + "if (" + expr + "):\n \t" + stat;
    }

    @Override 
    public String visitElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx)
    {
        String expr = (String) visit(ctx.getChild(3));
        String stat = (String) visit(ctx.getChild(5));
        return indent_string + "elif (" + expr + "):\n" + stat;
    }

    @Override 
    public String visitElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx)
    {
        String expr = (String) visit(ctx.getChild(3));
        String stat = (String) visit(ctx.getChild(5));
        return indent_string + "elif (" + expr + "):\n " + " \t" + stat;
    }

    @Override 
    public String visitElseBlock(LanguageExpressionsParser.ElseBlockContext ctx)
    {
        String stat = (String) visit(ctx.getChild(1));
        return indent_string + "else:\n" + stat;
    }

    @Override 
    public String visitElseNonBlock(LanguageExpressionsParser.ElseNonBlockContext ctx)
    {
        String stat = (String) visit(ctx.getChild(1));
        return indent_string + "else:\n \t" + stat;
    }

    @Override 
    public String visitDeclStat(LanguageExpressionsParser.DeclStatContext ctx)
    {
        String decl = (String) visit(ctx.getChild(0));
        return indent_string + decl + "\n";
    }

    @Override 
    public String visitAssignStat(LanguageExpressionsParser.AssignStatContext ctx)
    {
        String assign = (String) visit(ctx.getChild(0));
        return indent_string + assign + "\n";
    }

    @Override 
    public String visitPrintStat(LanguageExpressionsParser.PrintStatContext ctx)
    {
        String print = (String) visit(ctx.getChild(0));
        
        return indent_string + print + "\n";
    }

    @Override 
    public String visitFunctionStat(LanguageExpressionsParser.FunctionStatContext ctx)
    {
        String fct = (String) visit(ctx.getChild(0));
        return indent_string + fct + "\n";
    }

    @Override 
    public String visitReturnStat(LanguageExpressionsParser.ReturnStatContext ctx)
    {
        String ret = (String) visit(ctx.getChild(0));
        return indent_string + ret + "\n";
    }

    @Override 
    public String visitFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx)
    {
        String id = ctx.getChild(0).getText();
        String args = (String) visit(ctx.getChild(2));
        if(reservedIds.contains(id))
        {
            return "fct_" + id + "(" + args + ")";
        }
        return id + "(" + args + ")";
    }

    @Override 
    public String visitPrintExp(LanguageExpressionsParser.PrintExpContext ctx)
    {
        String expr = (String) visit(ctx.getChild(2));
        String printType = ctx.getChild(0).getText();
          
        if (printType.equals("println"))
        {
            return "print(" + expr + ")";
        }

        return "print(" + expr + ", end=\"\")";
    }

    @Override 
    public String visitReturnExp(LanguageExpressionsParser.ReturnExpContext ctx)
    {
        String expr = (String) visit(ctx.getChild(1));
        return "return " + expr;
    }

    ////////////////
    ////////////////
    ////////////////
    //Expressions

    @Override public String visitRbExpr(LanguageExpressionsParser.RbExprContext ctx)
    {
        String expr = (String) visit(ctx.getChild(0));
        return expr;
    }

    @Override public String visitRBExpr(LanguageExpressionsParser.RBExprContext ctx)
    {
        String expr = (String) visit(ctx.getChild(1));
        return "(" + expr + ")";
    }

    @Override public String visitMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx)
    {
        String firstExpr = (String) visit(ctx.getChild(0));
        String secondExpr = (String) visit(ctx.getChild(2));
        String sign = ctx.getChild(1).getText();
        return firstExpr + " " + sign + " " + secondExpr;
    }

    @Override public String visitPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx)
    {
        String firstExpr = (String) visit(ctx.getChild(0));
        String secondExpr = (String) visit(ctx.getChild(2));
        String sign = ctx.getChild(1).getText();
        return firstExpr + " " + sign + " " + secondExpr;
    }

    @Override public String visitCondExpr(LanguageExpressionsParser.CondExprContext ctx)
    {
        String firstExpr = (String) visit(ctx.getChild(0));
        String sign = (String) ctx.getChild(1).getText();
        String secondExpr = (String) visit(ctx.getChild(2));
        return firstExpr + " " + sign + " " + secondExpr;
    }


    @Override public String visitLengthExpr(LanguageExpressionsParser.LengthExprContext ctx) //never visited actually (to fix !)
    {
        System.out.println("test");

        String expr = (String) visit(ctx.getChild(0));
        return "len(" + expr + ")";
    }

    @Override public String visitTableExpr(LanguageExpressionsParser.TableExprContext ctx)
    {
        String firstExpr = (String) visit(ctx.getChild(0));
        String secondExpr = (String) visit(ctx.getChild(2));
        return firstExpr + "[" + secondExpr + "]";
    }

    @Override public String visitFctExpr(LanguageExpressionsParser.FctExprContext ctx)
    {
        String expr = (String) visit(ctx.getChild(0));
        return expr;
    }    

    @Override public String visitNewExpr(LanguageExpressionsParser.NewExprContext ctx)
    {
        String expr = (String) visit(ctx.getChild(3));
        String type = (String) ctx.getChild(1).getText();
        if (type.equals("int"))
        {
            return "[0] * " + expr;
        }
        else if (type.equals("float"))
        {
            return "[0.0] * " + expr;
        }
        else if (type.equals("bool"))
        {
            return "[True] * " + expr;
        }
        else if (type.equals("char"))
        {
            return "[' '] * " + expr;
        }
        return "[0] * " + expr;
    }

    @Override public String visitArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx)
    {
        String list = "";
        for (int i = 1; i <= ctx.getChildCount() - 2; i += 2)
        {
            if (i != 1)
            {
                list += ", ";
            }
            list += ctx.getChild(i).getText();
        }

        //code.add("[" + list + "]");
        return "[" + list + "]";
    }

    @Override public String visitConditionSigns(LanguageExpressionsParser.ConditionSignsContext ctx)
    {
        return ctx.getChild(0).getText();
    }

    @Override public String visitIdCall(LanguageExpressionsParser.IdCallContext ctx)
    {
        String id = ctx.getChild(0).getText();

        if(reservedIds.contains(id))
        {
            return "var_" + id;
        }

        return id;
    }

    @Override public String visitBoolType(LanguageExpressionsParser.BoolTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        if(b.equals("true"))
        {
            return "True";
        }
        else
        {
            return "False";
        }
    }
    
    @Override public String visitIntType(LanguageExpressionsParser.IntTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        return b;
    }

    @Override public String visitFloatType(LanguageExpressionsParser.FloatTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        return b;
    }

    @Override public String visitCharType(LanguageExpressionsParser.CharTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        return b;
    }

    @Override public String visitStringType(LanguageExpressionsParser.StringTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        return b;
    }

    @Override public String visitAnyTypeExpr(LanguageExpressionsParser.AnyTypeExprContext ctx)
    {
        String t = (String) visit(ctx.getChild(0));
        return t;
    }

    @Override public String visitAnyType(LanguageExpressionsParser.AnyTypeContext ctx)
    {
        String t = (String) visit(ctx.getChild(0));
        
        if (t.contains(".length"))
        {
            String id = t.replace(".length", "");
            if(reservedIds.contains(id))
            {
                id = "var_" + id;
            }
            t = "len(" + id + ")";
        }

        return t;
    }

    @Override public String visitIdExpr(LanguageExpressionsParser.IdExprContext ctx)
    {
        String t = (String) visit(ctx.getChild(0));
        if(reservedIds.contains(t))
        {
            return "var_" + t;
        }
        
        return t;
    }

    @Override public String visitAnyTypeArr(LanguageExpressionsParser.AnyTypeArrContext ctx)
    {
        String t = (String) visit(ctx.getChild(0));
        return t;
    }

    @Override public String visitIntDecl(LanguageExpressionsParser.IntDeclContext ctx)
    {
        return "int";
    }

    @Override public String visitFloatDecl(LanguageExpressionsParser.FloatDeclContext ctx)
    {
        return "float";
    }

    @Override public String visitCharDecl(LanguageExpressionsParser.CharDeclContext ctx)
    {
        return "char";
    }

    @Override public String visitBoolDecl(LanguageExpressionsParser.BoolDeclContext ctx)
    {
        return "bool";
    }

    @Override public String visitAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx)
    {
        return "";
    }

    //Maybe to modify in case of a declaration without assignment ?
    @Override public String visitDeclaration(LanguageExpressionsParser.DeclarationContext ctx)
    {
        if (ctx.getChildCount() == 2)
        {
            String assign = (String) visit(ctx.getChild(1));
            if(reservedIds.contains(assign))
            {
                assign = "var_" + assign;
            }
            return assign;
        }
        return "";
    }
    

    @Override public String visitAssign(LanguageExpressionsParser.AssignContext ctx)
    {
        String stat = (String) visit(ctx.getChild(0));
        if(reservedIds.contains(stat))
        {
            stat = "var_" + stat;
        }

        if (ctx.getChildCount() == 4)
        {
            String firstExpr = (String) visit(ctx.getChild(2));
            stat += " = " + firstExpr; 
        }
        else if (ctx.getChildCount() == 7)
        {
            String firstExpr = (String) visit(ctx.getChild(2));
            String secondExpr = (String) visit(ctx.getChild(5));
            stat += "[" + firstExpr + "] = " + secondExpr;
        }

        return stat;
    }

    @Override public String visitAssign2(LanguageExpressionsParser.Assign2Context ctx)
    {
        String stat = ctx.getChild(0).getText();

        if(reservedIds.contains(stat))
        {
            stat = "var_" + stat;
        }

        if (ctx.getChildCount() == 4)
        {
            String firstExpr = (String) visit(ctx.getChild(2));
            stat += " = " + firstExpr; 
        }
        else if (ctx.getChildCount() == 7)
        {
            String firstExpr = (String) visit(ctx.getChild(2));
            String secondExpr = (String) visit(ctx.getChild(5));
            stat += "[" + firstExpr + "] = " + secondExpr;
        }

        return stat;
    }

    @Override public String visitArgs(LanguageExpressionsParser.ArgsContext ctx)
    {
        String args = "";
        for (int i = 0; i < ctx.getChildCount(); i += 2)
        {
            args += (String) visit(ctx.getChild(i));
            if(i < ctx.getChildCount()-1)
            {
                args += ", "; 
            }
                
        }
        return args;
    }

    public void addIndent(int i)
    {   
        //indent++; 
        indent_string = "\t".repeat(i);
    }

    public void removeIndent(int i)
    {
        //indent--;
        indent_string = "\t".repeat(i);
    } 
}
