package src;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

import generated.LanguageExpressionsBaseListener;
import generated.LanguageExpressionsListener;
import generated.LanguageExpressionsParser;

public class CheckRefListener extends LanguageExpressionsBaseListener{

    private ParseTreeProperty<Scope> scopes; 

    private Scope currentScope;
    private Scope globalScope; 

    private Map<Scope, Set<String>> scopeVarInits = new LinkedHashMap<Scope, Set<String>>();
    
    private String currentFunction; //for logging purposes
    int errorCount = 0;  // Keep track of the total number of errors
    
    public CheckRefListener(ParseTreeProperty<Scope> scopes)
    {
        this.scopes = scopes; // Scopes initialized in previous traversal 
    }

    public int getErrorCount() { return errorCount;}

    // Switch scopes 

    private void enterScope(ParserRuleContext ctx)
    {
        currentScope = scopes.get(ctx);
        
        if (currentScope == null)
        {
            throw new RuntimeException("No current scope in enterScope !");
        }
        //For each scope, there should be a set of variables already initialized within that scope, if not, we declare it 
        if(!scopeVarInits.containsKey(currentScope))
        {
            scopeVarInits.put(currentScope, new LinkedHashSet<String>());
        }
    }
 
    private void exitScope() //move to parent node
    {
        currentScope = currentScope.getEnclosingScope(); 
    } 

    @Override public void enterStart(LanguageExpressionsParser.StartContext ctx)
    {
        enterScope(ctx);
        
        globalScope = currentScope; 
    }

    @Override public void enterBlock(LanguageExpressionsParser.BlockContext ctx)
    {
        enterScope(ctx);
    }

    @Override public void exitBlock(LanguageExpressionsParser.BlockContext ctx)
    {   
        exitScope();
    }

    @Override public void enterFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx)
    {   
        currentFunction = ctx.getChild(1).getText();
    }

    @Override public void enterMain(LanguageExpressionsParser.MainContext ctx)
    {   
        currentFunction = "main";
    }

    // Handle calls when checking undeclared identifiers 
    @Override public void enterIdCall(LanguageExpressionsParser.IdCallContext ctx) 
    {
        String name = ctx.getChild(0).getText();
        Symbol sym = currentScope.resolve(name);
        if (sym == null || (sym instanceof FunctionSymbol))
        {
            errorCount++;
            System.out.println(errorCount+"\t Undeclared variable in function " + currentFunction + ": " + name);
        } 
    }

    // Handle calls when checking undeclared identifiers 
    @Override public void enterFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx) 
    {
        String name = ctx.getChild(0).getText();
        Symbol sym = currentScope.resolve(name);
        if (sym == null || !(sym instanceof FunctionSymbol))
        {
            errorCount++;
            System.out.println(errorCount+"\t Undeclared function called in function " + currentFunction + ": " + name);
        } 
    }
    
    private void addVariableInit(String variableName) //Add every variable to the scope 
    {
        // It's a set, so there is not harm in adding the same variable name
        // for multiple assignment statements in the same scope
        // (addition to a set is an idempotent operation)
        scopeVarInits.get(currentScope).add(variableName);
    }

    private boolean testVariableInit(Scope scope, String variableName) //test if variable is initialized
    {
        //check in the given scope and then its enclosing scope recursively, if necessary
        if(scopeVarInits.get(scope) != null)
        {
            if(scopeVarInits.get(scope).contains(variableName))
            {
                return true;
            }
    
            if(scope.getEnclosingScope() == null) //recursivity
            {
                errorCount++; 
                System.out.println(errorCount + "\t Uninitialized variable " + currentFunction + ": " + variableName);
                return false;        
            }
            else 
            {
                return testVariableInit(scope.getEnclosingScope(), variableName);
            }
        }
        else
        {
            errorCount++; 
            System.out.println(errorCount + "\t Uninitialized variable " + currentFunction + ": " + variableName);    
        }
        return false;
    }

    @Override public void enterAssign(LanguageExpressionsParser.AssignContext ctx)
    {
        String name = ctx.getChild(0).getText();
        addVariableInit(name);
        testVariableInit(currentScope, name);
    }

    @Override public void enterAssign2(LanguageExpressionsParser.Assign2Context ctx)
    {
        String name = ctx.getChild(0).getText();
        addVariableInit(name);
        testVariableInit(currentScope, name);
    }

    @Override public void enterIdExpr(LanguageExpressionsParser.IdExprContext ctx)
    {
        String name = ctx.getChild(0).getText();
        
        if (!(currentScope.resolve(name) instanceof ParamSymbol))
        {
            testVariableInit(currentScope, name);
        }
    }
}
