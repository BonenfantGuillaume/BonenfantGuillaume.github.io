package src;

import java.util.ArrayList;

public class FunctionSymbol extends Symbol
{
    private ArrayList<OFPType> listParam = new ArrayList<>();

    public FunctionSymbol(String name, String typeName) {
        super(name, OFPType.getTypeFor(typeName));
    }

    public void addParam(OFPType type)
    {
        listParam.add(type); 
    }

    public ArrayList<OFPType> getListParam()
    {
        return listParam; 
    }

}
