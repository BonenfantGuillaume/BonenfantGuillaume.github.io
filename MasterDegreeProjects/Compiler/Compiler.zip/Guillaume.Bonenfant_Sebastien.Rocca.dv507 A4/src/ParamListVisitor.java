package src;
import java.util.ArrayList;

import org.antlr.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.antlr.v4.runtime.tree.TerminalNode;

import generated.LanguageExpressionsBaseVisitor;
import generated.LanguageExpressionsParser;


public class ParamListVisitor extends LanguageExpressionsBaseVisitor<Object> {

    private ParseTreeProperty<Scope> scopes;
    
    private Scope currentScope;

    private Scope globalScope; 

    private int errorCount = 0;
    
    private String currentFunctionName = ""; 

    private String functionCallName = "";

    //functionExp : (anyTypeDecl|'void') ID LRB fctParams RRB block;
    public OFPType visitAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx)
    {
        return OFPType.getTypeFor(ctx.getChild(0).getText()); 
    }

    public ParamListVisitor(ParseTreeProperty <Scope> scopes)
    {
        this.scopes = scopes;
    }

    @Override public OFPType visitStart(LanguageExpressionsParser.StartContext ctx)
    {
        this.globalScope = scopes.get(ctx);
        for (int i=0; i<ctx.getChildCount();i++) {
            visit(ctx.getChild(i)); //visit children
        }
        return null;
    }

    @Override public OFPType visitFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx)
    { 
        currentFunctionName = ctx.getChild(1).getText();
        for (int i=0; i<ctx.getChildCount();i++) {
            visit(ctx.getChild(i)); //visit children
        }
        return null; 
    }

    @Override public OFPType visitMain(LanguageExpressionsParser.MainContext ctx)
    {
        currentFunctionName = "main";
        for (int i=0; i<ctx.getChildCount();i++) {
            visit(ctx.getChild(i)); //visit children
        }
        return null; 
    }

    @Override public OFPType visitBlock(LanguageExpressionsParser.BlockContext ctx)
    {
        currentScope = scopes.get(ctx);
        
        for (int i=1; i<ctx.getChildCount()-1;i++) {
            visit(ctx.getChild(i)); //visit children
        }

        return null; 
        
    }

    @Override public OFPType visitWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx)
    {
        OFPType type = (OFPType) visit(ctx.getChild(2));

        if (type != OFPType.getTypeFor("bool"))
        {
            errorCount++;
            System.out.println(errorCount +"\tIncompatible type in while non block in "+
            "function " + currentFunctionName + ": " + type);            
        }

        return null; 
    }

    @Override public OFPType visitWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx)
    {
        OFPType type = (OFPType) visit(ctx.getChild(2));

        if (type != OFPType.getTypeFor("bool"))
        {
            errorCount++;
            System.out.println(errorCount +"\tIncompatible type in while block in "+
            "function " + currentFunctionName + ": " + type);            
        }

        return null; 
    }

    @Override public OFPType visitIfBlock(LanguageExpressionsParser.IfBlockContext ctx)
    {
        OFPType type = (OFPType) visit(ctx.getChild(2));

        if (type != OFPType.getTypeFor("bool"))
        {
            errorCount++;
            System.out.println(errorCount +"\tIncompatible type in if block in "+
            "function " + currentFunctionName + ": " + type);            
        }

        return null; 
    }

    @Override public OFPType visitIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx)
    {
        OFPType type = (OFPType) visit(ctx.getChild(2));

        if (type != OFPType.getTypeFor("bool"))
        {
            errorCount++;
            System.out.println(errorCount +"\tIncompatible type in if non block in "+
            "function " + currentFunctionName + ": " + type);            
        }

        return null; 
    }

    @Override public OFPType visitElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx)
    {
        OFPType type = (OFPType) visit(ctx.getChild(3));

        if (type != OFPType.getTypeFor("bool"))
        {
            errorCount++;
            System.out.println(errorCount +"\tIncompatible type in else if block in "+
            "function " + currentFunctionName + ": " + type);            
        }

        return null; 
    }

    @Override public OFPType visitElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx)
    {
        OFPType type = (OFPType) visit(ctx.getChild(3));

        if (type != OFPType.getTypeFor("bool"))
        {
            errorCount++;
            System.out.println(errorCount +"\tIncompatible type in else if non block in "+
            "function " + currentFunctionName + ": " + type);            
        }

        return null; 
    }


    // expr (PLUS | MINUS) expr
    @Override public OFPType visitPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx) 
    {
        OFPType lhsType = (OFPType) visit(ctx.getChild(0));
        OFPType rhsType = (OFPType) visit(ctx.getChild(2));
        
        if (lhsType != rhsType) // Error detected!
        { 
            errorCount++;
            System.out.println(errorCount +"\tIncompatible plus op types in "+
            "function " + currentFunctionName + ": "+lhsType+", "+rhsType);
        }
        
        return lhsType; // lhs and rhs are both the same type
    }

    // expr (MULT | DIV) expr
    @Override public OFPType visitMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx) 
    {
        OFPType lhsType = (OFPType) visit(ctx.getChild(0));
        OFPType rhsType = (OFPType) visit(ctx.getChild(2));
        if (lhsType != rhsType) // Error detected!
        { 
            errorCount++;
            System.out.println(errorCount +"\tIncompatible plus op types in "+
            "function  " + currentFunctionName + ": "+lhsType+", "+rhsType);
        }
        
        return lhsType; // lhs and rhs are both the same type
    }

    @Override public OFPType visitCondExpr(LanguageExpressionsParser.CondExprContext ctx) 
    {
        OFPType lhsType = (OFPType) visit(ctx.getChild(0));
        OFPType rhsType = (OFPType) visit(ctx.getChild(2));
        if (lhsType != rhsType) // Error detected!
        { 
            errorCount++;
            System.out.println(errorCount +"\tIncompatible plus op types in "+
            "function  " + currentFunctionName + ": "+lhsType+", "+rhsType);
        }
        
        return OFPType.getTypeFor("bool");
    }

    @Override public OFPType visitLengthExpr(LanguageExpressionsParser.LengthExprContext ctx) 
    {
        OFPType type = (OFPType) visit(ctx.getChild(0));
        if (type != OFPType.getTypeFor("float[]") && type != OFPType.getTypeFor("int[]") && type != OFPType.getTypeFor("bool[]") && type != OFPType.getTypeFor("char[]") && type != OFPType.getTypeFor("string")  ) // Error detected!
        { 
            errorCount++;
            System.out.println(errorCount +"\tIncompatible plus op types in "+
            "function  " + currentFunctionName + ": "+type);
        }
        
        return OFPType.getTypeFor("int");
    }

    //rBExpr
    @Override public OFPType visitRbExpr(LanguageExpressionsParser.RbExprContext ctx) 
    {
        OFPType type = (OFPType) visit(ctx.getChild(0));
        
        return type; // lhs and rhs are both the same type
    }

    //rbExpr
    @Override public OFPType visitRBExpr(LanguageExpressionsParser.RBExprContext ctx) 
    {
        OFPType type = (OFPType) visit(ctx.getChild(1));
         
        return type; // lhs and rhs are both the same type
    }

    //expr ('[' expr ']')
    @Override public OFPType visitTableExpr(LanguageExpressionsParser.TableExprContext ctx) 
    {           
        OFPType rtype = (OFPType) visit(ctx.getChild(1));

        if(OFPType.getTypeFor("int") == rtype)
        {
            errorCount++; 
            System.out.println(errorCount +"\t Incompatible type in squared brackets in "+
            "function  " + currentFunctionName + ": "+rtype); 
        }

        OFPType ltype = (OFPType) visit(ctx.getChild(0));

        String type = "";

        if (ltype != OFPType.getTypeFor("float[]") && ltype != OFPType.getTypeFor("int[]") && ltype != OFPType.getTypeFor("bool[]") && ltype != OFPType.getTypeFor("char[]") && ltype != OFPType.getTypeFor("string")  ) // Error detected!
        {
            errorCount++; 
            System.out.println(errorCount +"\t Incompatible type, not an array in "+
            "function  " + currentFunctionName + ": "+ltype); 
        }
        else
        {
            if (ltype == OFPType.getTypeFor("float[]"))
                type = "float";
            else if (ltype == OFPType.getTypeFor("int[]"))
                type = "int";
            else if (ltype == OFPType.getTypeFor("bool[]"))
                type = "bool";
            else if (ltype == OFPType.getTypeFor("char[]"))
                type = "char";
            else if (ltype == OFPType.getTypeFor("string"))
                type = "char";
        }

        return (OFPType) OFPType.getTypeFor(type);
    }

    @Override public OFPType visitFctExpr(LanguageExpressionsParser.FctExprContext ctx) 
    {
        OFPType type = (OFPType) visit(ctx.getChild(0));

        return type;
    }

    @Override public OFPType visitFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx) 
    {
        String idName = ctx.getChild(0).getText();
        functionCallName = idName;

        OFPType type = currentScope.resolve(idName).getType();

        visit(ctx.getChild(2));

        return type; 
    }

    @Override public OFPType visitArgs(LanguageExpressionsParser.ArgsContext ctx) 
    {
        ArrayList <OFPType> params = ((FunctionSymbol) currentScope.resolve(functionCallName)).getListParam();
        for(int i = 0; i < params.size(); i++)
        {
            if (ctx.getChildCount() >= 1 + 2*i)
            {
                OFPType callParamType = (OFPType) visit(ctx.getChild(2*i));
                OFPType fctParamType = params.get(i);


                if(callParamType != fctParamType)
                {
                    errorCount++; 
                    System.out.println(errorCount +"\t Incompatible type, in function call" + functionCallName + " in "+
                    "function  " + currentFunctionName + ": " + callParamType + ". Wanted: " + fctParamType); 
                }
            }
            else
            {
                errorCount++; 
                System.out.println(errorCount +"\t Missing parameter(s) in function call" + functionCallName + " in "+
                "function  " + currentFunctionName);
            }
        }

        if (ctx.getChildCount() != 0 && ctx.getChildCount() > 1 + (params.size()-1)*2)
        {
            errorCount++; 
            System.out.println(errorCount +"\t Too many parameters in function call " + functionCallName + " in "+
            "function  " + currentFunctionName);
        }

        return null; 
    }

    @Override public OFPType visitReturnExp(LanguageExpressionsParser.ReturnExpContext ctx) 
    {
        OFPType type = (OFPType) visit(ctx.getChild(1));
        OFPType functionType = currentScope.resolve(currentFunctionName).getType();

        if(type != functionType)
        {
            errorCount++; 
            System.out.println(errorCount +"\t Incompatible type, in return in "+
            "function  " + currentFunctionName + ": " + type + ". Wanted: " + functionType); 
        }

        return type; 
    }
 
    @Override public OFPType visitIdExpr(LanguageExpressionsParser.IdExprContext ctx) 
    {
        OFPType type = (OFPType) visit(ctx.getChild(0));
        return (OFPType) type;
    }
    
    //ID
    @Override public OFPType visitIdCall(LanguageExpressionsParser.IdCallContext ctx) 
    {        
        OFPType type = currentScope.resolve(ctx.getChild(0).getText()).getType();
        return  type; // lhs and rhs are both the same type
    }

    //anyType
    @Override public OFPType visitAnyTypeExpr(LanguageExpressionsParser.AnyTypeExprContext ctx)
    {
        OFPType type = (OFPType) visit(ctx.getChild(0));
        return (OFPType) type; // lhs and rhs are both the same type
    }

     //anyType
     @Override public OFPType visitAnyType(LanguageExpressionsParser.AnyTypeContext ctx)
     {
         return (OFPType) visit(ctx.getChild(0)); 
     }

     @Override public OFPType visitNewExpr(LanguageExpressionsParser.NewExprContext ctx)
     {
        OFPType expSizeType = (OFPType) visit(ctx.getChild(3));
        OFPType type = (OFPType) visit(ctx.getChild(1));
        String typeToReturn = "";  

        if (expSizeType != OFPType.getTypeFor("int"))
        {
            errorCount++; 
            System.out.println(errorCount +"\t Incompatible type, not an integer in "+
            "array declaration size " + currentFunctionName + ": "+ expSizeType); 
        }

        if (type == OFPType.getTypeFor("float"))
            typeToReturn = "float[]";
        else if (type == OFPType.getTypeFor("int"))
            typeToReturn = "int[]";
        else if (type == OFPType.getTypeFor("bool"))
            typeToReturn = "bool[]";
        else if (type == OFPType.getTypeFor("char"))
            typeToReturn = "char[]";
        
        return OFPType.getTypeFor(typeToReturn);  
     }

     @Override public OFPType visitArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx)
     {
        OFPType type = (OFPType) visit(ctx.getChild(1)); 

        for(int i = 3; i < ctx.getChildCount() - 1; i += 2)
        {
            OFPType type2 = (OFPType) visit(ctx.getChild(i)); 

            if (type != type2)
            {
                errorCount++;
                System.out.println(errorCount +"\t Incompatible type in "+
                "array declaration " + currentFunctionName + ": " + type); 
            }
        }
        String typeToReturn = "";
        if (type == OFPType.getTypeFor("float"))
            typeToReturn = "float[]";
        else if (type == OFPType.getTypeFor("int"))
            typeToReturn = "int[]";
        else if (type == OFPType.getTypeFor("bool"))
            typeToReturn = "bool[]";
        else if (type == OFPType.getTypeFor("char"))
            typeToReturn = "char[]";

        return OFPType.getTypeFor(typeToReturn);
     }

     @Override public OFPType visitAssign(LanguageExpressionsParser.AssignContext ctx)
     {
        OFPType ltype = currentScope.resolve(ctx.getChild(0).getText()).getType();

        if (ctx.getChildCount() == 7)
        {
            if(ctx.getChild(2) != OFPType.getTypeFor("int"))
            {
                errorCount++; 
                System.out.println(errorCount +"\t Incompatible type, not an integer in "+
                "array declaration " + currentFunctionName + ": "+ ctx.getChild(2));     
            }

            if (ltype == OFPType.getTypeFor("float[]"))
                ltype = OFPType.getTypeFor("float");
            else if (ltype == OFPType.getTypeFor("int[]"))
               ltype = OFPType.getTypeFor("int");
            else if (ltype == OFPType.getTypeFor("bool[]"))
                ltype = OFPType.getTypeFor("bool");
            else if (ltype == OFPType.getTypeFor("char[]"))
                ltype = OFPType.getTypeFor("char");
            else if (ltype == OFPType.getTypeFor("string"))
                ltype = OFPType.getTypeFor("char");
            else if (ltype == OFPType.getTypeFor("int") || ltype == OFPType.getTypeFor("float") || ltype == OFPType.getTypeFor("bool") || ltype == OFPType.getTypeFor("char"))
            {
                errorCount++; 
                System.out.println(errorCount + ctx.getChild(0).getText() + "\t not an array in " + "currentFunction");
            }
        }

        OFPType rtype;
        if (ctx.getChildCount() < 7)
        {
            rtype = (OFPType) visit(ctx.getChild(2));
        }
        else
            rtype = (OFPType) visit(ctx.getChild(5));

        if (ltype != rtype)
        {
            errorCount++; 
            System.out.println(errorCount +"\t Incompatible type " + ltype + " and " + rtype +
            " in function " + currentFunctionName); 
        }
        
        return ltype;
     }

     @Override public OFPType visitAssign2(LanguageExpressionsParser.Assign2Context ctx)
     {
        OFPType ltype = currentScope.resolve(ctx.getChild(0).getText()).getType();

        if (ctx.getChildCount() == 7)
        {
            if(ctx.getChild(2) != OFPType.getTypeFor("int"))
            {
                errorCount++; 
                System.out.println(errorCount +"\t Incompatible type, not an integer in "+
                "array declaration " + currentFunctionName + ": "+ ctx.getChild(2));     
            }

            if (ltype == OFPType.getTypeFor("float[]"))
                ltype = OFPType.getTypeFor("float");
            else if (ltype == OFPType.getTypeFor("int[]"))
               ltype = OFPType.getTypeFor("int");
            else if (ltype == OFPType.getTypeFor("bool[]"))
                ltype = OFPType.getTypeFor("bool");
            else if (ltype == OFPType.getTypeFor("char[]"))
                ltype = OFPType.getTypeFor("char");
            else if (ltype == OFPType.getTypeFor("string"))
                ltype = OFPType.getTypeFor("char");
            else if (ltype == OFPType.getTypeFor("int") || ltype == OFPType.getTypeFor("float") || ltype == OFPType.getTypeFor("bool") || ltype == OFPType.getTypeFor("char"))
            {
                errorCount++; 
                System.out.println(errorCount + ctx.getChild(0).getText() + "\t not an array in " + "currentFunction");
            }
        }

        OFPType rtype;
        if (ctx.getChildCount() < 7)
        {
            //System.out.println((ctx.getChild(2)).toString());
            rtype = (OFPType) visit(ctx.getChild(2));
        }
        else
            rtype = (OFPType) visit(ctx.getChild(5));

        if (ltype != rtype)
        {
            errorCount++; 
            System.out.println(errorCount +"\t Incompatible type " + ltype + " and " + rtype +
            " in function " + currentFunctionName); 
        }
        
        return ltype;
     }

     @Override public OFPType visitIntType(LanguageExpressionsParser.IntTypeContext ctx)
     {
        return OFPType.getTypeFor("int"); 
     }

     @Override public OFPType visitFloatType(LanguageExpressionsParser.FloatTypeContext ctx)
     {
        return OFPType.getTypeFor("float"); 
     }

     @Override public OFPType visitBoolType(LanguageExpressionsParser.BoolTypeContext ctx)
     {
        return OFPType.getTypeFor("bool"); 
     }

     @Override public OFPType visitCharType(LanguageExpressionsParser.CharTypeContext ctx)
     {
        return OFPType.getTypeFor("char"); 
     }

     @Override public OFPType visitStringType(LanguageExpressionsParser.StringTypeContext ctx)
     {
        return OFPType.getTypeFor("string"); 
     }

     @Override public OFPType visitIntDecl(LanguageExpressionsParser.IntDeclContext ctx)
     {
        return OFPType.getTypeFor("int");
     } 

     @Override public OFPType visitFloatDecl(LanguageExpressionsParser.FloatDeclContext ctx)
     {
        return OFPType.getTypeFor("float");
     } 

     @Override public OFPType visitBoolDecl(LanguageExpressionsParser.BoolDeclContext ctx)
     {
        return OFPType.getTypeFor("bool");
     } 

     @Override public OFPType visitIntArrDecl(LanguageExpressionsParser.IntArrDeclContext ctx)
     {
        return OFPType.getTypeFor("int[]");
     } 

     @Override public OFPType visitFloatArrDecl(LanguageExpressionsParser.FloatArrDeclContext ctx)
     {
        return OFPType.getTypeFor("float[]");
     } 

     @Override public OFPType visitBoolArrDecl(LanguageExpressionsParser.BoolArrDeclContext ctx)
     {
        return OFPType.getTypeFor("bool[]");
     } 

     @Override public OFPType visitCharArrDecl(LanguageExpressionsParser.CharArrDeclContext ctx)
     {
        return OFPType.getTypeFor("char[]");
     } 

     @Override public OFPType visitStringDecl(LanguageExpressionsParser.StringDeclContext ctx)
     {
        return OFPType.getTypeFor("string");
     } 


    public ParseTree visitAllChildren(ParseTree node) 
    {
        System.out.println(node.getClass().getName()+":"+node.getChildCount());
        for (int i=0; i<node.getChildCount();i++) {
            ParseTree child = node.getChild(i);
            if (child instanceof TerminalNode)
            visitTerminalNode( (TerminalNode) child);
            else
            visit(child); // Visit a non-terminal child
            } // Will call corresponding visitX method
        return node;
    }  

    public void visitTerminalNode(TerminalNode node)
    {
        System.out.println("\t" + node.getClass().getName()+": " + node.getText());
    }
    
}
