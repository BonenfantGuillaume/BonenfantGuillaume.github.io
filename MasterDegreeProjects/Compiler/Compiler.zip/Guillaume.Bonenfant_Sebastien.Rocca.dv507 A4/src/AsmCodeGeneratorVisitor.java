package src;

import java.io.PrintStream;
import java.io.FileOutputStream;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

import generated.LanguageExpressionsBaseVisitor;
import generated.LanguageExpressionsParser;

import java.io.PrintWriter;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.commons.GeneratorAdapter;
import org.objectweb.asm.commons.Method;
import org.objectweb.asm.util.CheckClassAdapter;
import org.objectweb.asm.util.TraceClassVisitor;
import org.objectweb.asm.Label;


public class AsmCodeGeneratorVisitor extends LanguageExpressionsBaseVisitor<Object> implements Opcodes {
    
    private ParseTreeProperty<Scope> scopes; 

    private Scope currentScope; 

    private Map<String, Integer> varMap = new HashMap<String, Integer>(); //map id and index

    private Map<Integer, String> variableIndexType = new HashMap<Integer, String>(); 

    private int variableIndex = 1;

    private String lastVariableType; 
    
    private Map<String, Integer> functionArgs = new HashMap<>();  

    private ArrayList<String> code = new ArrayList<String>();

    private GeneratorAdapter mg; 

    private ClassWriter cw;

    private Label jmpLabel; 

    private Label endLabel; 

    public AsmCodeGeneratorVisitor(ParseTreeProperty<Scope> scopes)
    {
        this.scopes = scopes; 

        cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cw.visit(V1_1, ACC_PUBLIC, "Hello", null, "java/lang/Object", null);

        // Creates a GeneratorAdapter for the (implicit) constructor (must always be included)
        Method m = Method.getMethod("void <init> ()");
        mg = new GeneratorAdapter(ACC_PUBLIC, m, null, null,cw);
        mg.loadThis();
        mg.invokeConstructor(Type.getType(Object.class), m);
        mg.returnValue();
        mg.endMethod();
    }

    //start : functionExp* main functionExp*;
    @Override
    public String visitStart(LanguageExpressionsParser.StartContext ctx)
    {
        currentScope = scopes.get(ctx); 

        ParserRuleContext main = null; 

        for (int i = 0 ; i < ctx.getChildCount(); i++)
        {

            ParserRuleContext p = (ParserRuleContext) ctx.getChild(i);
        
            if (p.getChild(0).getText().equals("void main()"))
            {
                main = p; 
            }
            else
            {
                
                String fct = (String) visit(p);
                
                code.add(fct);
            }

        }

        visit(main); 
        
        // Save

        System.out.println("INFO : Saving code ... ");

        byte[] code = cw.toByteArray();
        try {
            FileOutputStream fos = new FileOutputStream("Hello.class");
            fos.write(code);
            fos.close();
        } catch (Exception e) {
            System.out.println("ERROR : error while writing code into file.");
        }
       
        System.out.println("INFO : Code diagnostics ... ");

        // Diagnostics
        ClassReader cr = new ClassReader(code);
		ClassVisitor tracer = new TraceClassVisitor(new PrintWriter(System.out));
		ClassVisitor checker = new CheckClassAdapter(tracer, true);
		cr.accept(checker,0);
        
        // Execute
        /*AsmCodeGeneratorVisitor loader = new AsmCodeGeneratorVisitor();
        Class<?> exampleClass = loader.defineClass("Hello", code, 0, code.length);
        exampleClass.getMethods()[0].invoke(null, new Object[] { null });*/

        return null;


    }

    //functionExp : (anyTypeDecl|'void') ID LRB fctParams RRB block;
    @Override
    public String visitFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx)
    {
        varMap = new HashMap<String, Integer>(); //map id and index 
        variableIndexType = new HashMap<Integer, String>(); 
        functionArgs = new HashMap<String, Integer>();
        variableIndex = 0; 
     
        String id = ctx.getChild(1).getText();
        
        FunctionSymbol aScope = (FunctionSymbol) currentScope.resolve(id);
        ArrayList<OFPType> fctParametersTypes = aScope.getListParam();  
        String fctName = aScope.getName(); 
        String fctType = aScope.getType().toString(); 

        if(fctType.equals("float"))
        {
            fctType = "double"; 
        }
        else if(fctType.equals("float[]"))
        {
            fctType = "double[]"; 
        }
        else if(fctType.equals("string"))
        {
            fctType = "char[]"; 
        }
        else if(fctType.equals("bool"))
        {
            fctType = "boolean"; 
        }

        String fctSign = fctType + " " + fctName + "(";
        
        for(int i = 0; i < fctParametersTypes.size(); i++)
        {
            String p = fctParametersTypes.get(i).toString();
            if(p.equals("string"))
            {
                p = "String"; 
            }
            else if(p.equals("bool"))
            {
                p = "boolean"; 
            }
            else if(p.equals("bool[]"))
            {
                p = "boolean[]"; 
            }
            else if(p.equals("float"))
            {
                p = "double";
            }
            else if(p.equals("float[]"))
            {
                p = "double[]";
            }
            if(i+1 != fctParametersTypes.size())
            {
                fctSign += p + ",";
            }
            else
            {
                fctSign += p; 
            }
        }

        fctSign += ")";

        Method m = Method.getMethod(fctSign); //to do : add function return type (jType variable) instead of void
        mg = new GeneratorAdapter(ACC_PUBLIC + ACC_STATIC, m, null, null, this.cw);

        visit(ctx.getChild(3)); //visit fct args

        visit(ctx.getChild(5)); //visit "block" expression 
        
        mg.returnValue();
        mg.endMethod();

        cw.visitEnd();

        return null; 
    }

    //main : 'void main()' block;
    @Override
    public Object visitMain(LanguageExpressionsParser.MainContext ctx)
    {
        varMap = new HashMap<String, Integer>(); //map id and index 
        variableIndexType = new HashMap<Integer, String>(); 
        variableIndex = 1;
        functionArgs = new HashMap<String, Integer>();

        Method main = Method.getMethod("void main (String[])");
        mg = new GeneratorAdapter(ACC_PUBLIC + ACC_STATIC, main, null, null, this.cw);

        visit(ctx.getChild(1)); //visit "block" expression

        mg.returnValue();
        mg.endMethod();

        cw.visitEnd();

        return null; 
    }
    
    //fctParams : (anyTypeDecl ID)? (',' anyTypeDecl ID)* ;
    @Override
    public String visitFctParams(LanguageExpressionsParser.FctParamsContext ctx)
    {
        for (int i = 1; i < ctx.getChildCount(); i += 3)
        {            
            String varName = ctx.getChild(i).getText();
            String type = ctx.getChild(i-1).getText();

            if(!varMap.containsKey(varName) )  
            {            
                varMap.put(varName, variableIndex);
                functionArgs.put(varName, variableIndex); //to check if belong to fct params
            }        
            if(type.equals("int"))
            {   
                
                variableIndexType.put(variableIndex, "int");
                variableIndex += 1;
                
            }
            else if(type.equals("double") || type.equals("float"))
            {
                variableIndexType.put(variableIndex, "double");
                variableIndex += 1; //2
                
            }
            else if(type.equals("char"))
            {
                variableIndexType.put(variableIndex, "char");
                variableIndex += 1;                
            }       
            else if(type.equals("bool"))
            {
                variableIndexType.put(variableIndex, "boolean");
                variableIndex += 1;                
            }
            else if(type.equals("string"))
            {
                variableIndexType.put(variableIndex, "String");   
                variableIndex += 1;                
            }
            else if(type.equals("char[]"))
            {
                variableIndexType.put(variableIndex, "char[]");   
                variableIndex += 1;                
            } 
            else if(type.equals("bool[]"))
            {
                variableIndexType.put(variableIndex, "boolean[]");   
                variableIndex += 1;                
            }
            else if(type.equals("float[]"))
            {
                variableIndexType.put(variableIndex, "double[]");   
                variableIndex += 1;                
            }
            else if(type.equals("int[]"))
            {
                variableIndexType.put(variableIndex, "int[]");   
                variableIndex += 1;                
            }            
        }

        return null;
    }

    //block : LCB stat* RCB;
    @Override
    public String visitBlock(LanguageExpressionsParser.BlockContext ctx)
    {
        for (int i = 1; i < ctx.getChildCount() -1 ; i++)
        {
            visit(ctx.getChild(i));
        }

        return null; 
    }

    //args : (expr (',' expr)*|) ;
    @Override public String visitArgs(LanguageExpressionsParser.ArgsContext ctx)
    {
        for (int i = 0; i < ctx.getChildCount(); i += 2)
        {
            visit(ctx.getChild(i));               
        }

        return null;
    }

    //////////////////////////////////:

    //anyTypeDecl : (intDecl|boolDecl|floatDecl|charDecl|stringDecl|intArrDecl|floatArrDecl|boolArrDecl|charArrDecl);
    @Override public String visitAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx)
    {
        visit(ctx.getChild(0));

        return null;
    }

    //anyTypeArr : intType | boolType | charType | floatType;
    @Override public String visitAnyTypeArr(LanguageExpressionsParser.AnyTypeArrContext ctx)
    {
        visit(ctx.getChild(0));

        return null;
    }

    //anyType :  intType | boolType | floatType | charType | stringType;
    @Override public String visitAnyType(LanguageExpressionsParser.AnyTypeContext ctx)
    {
        visit(ctx.getChild(0));
        
        return null;
    }

    //intDecl : INTDECL;
    @Override public String visitIntDecl(LanguageExpressionsParser.IntDeclContext ctx)
    {
        return "int"; 
    }

    //floatDecl : FLOATDECL;
    @Override public String visitFloatDecl(LanguageExpressionsParser.FloatDeclContext ctx)
    {
        return "double"; 
    }

    //boolDecl : BOOLDECL;
    @Override public String visitBoolDecl(LanguageExpressionsParser.BoolDeclContext ctx)
    {
        return "boolean"; 
    }

    //charDecl : CHARDECL;
    @Override public String visitCharDecl(LanguageExpressionsParser.CharDeclContext ctx)
    {
        return "char"; 
    }

    //intArrDecl : INTARRDECL;
    @Override public String visitIntArrDecl(LanguageExpressionsParser.IntArrDeclContext ctx)
    {
        return "int[]"; 
    }

    //floatArrDecl : FLOATARRDECL;
    @Override public String visitFloatArrDecl(LanguageExpressionsParser.FloatArrDeclContext ctx)
    {
        return "double[]"; 
    }

    //boolArrDecl : BOOLARRDECL;
    @Override public String visitBoolArrDecl(LanguageExpressionsParser.BoolArrDeclContext ctx)
    {
        return "boolean[]"; 
    }

    //charArrDecl : CHARARRDECL;
    @Override public String visitCharArrDecl(LanguageExpressionsParser.CharArrDeclContext ctx)
    {
        return "char[]"; 
    }

    //stringDecl : STRINGDECL;
    @Override public String visitStringDecl(LanguageExpressionsParser.StringDeclContext ctx)
    {
        return "String";
    }
    

    /////////////////
    /////////////////
    /////////////////
    /////////////////
    //// Control Statements 

    //whileExp                         #whileStat
    @Override
    public String visitWhileStat(LanguageExpressionsParser.WhileStatContext ctx)
    {
        visit(ctx.getChild(0)); 
        return null; 
    }

    //whileExp : WHILE LRB expr RRB stat      #whileNonBlock
    @Override
    public String visitWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx)
    {   
        Label whileCond = new Label();
        mg.goTo(whileCond);

        jmpLabel = mg.mark();

        visit(ctx.getChild(4));

        mg.mark(whileCond);

        //while condition here 


        if(ctx.getChild(2).getChildCount() > 1 )
        {
            visit(ctx.getChild(2)); //expr
        }
        else
        {
            visit(ctx.getChild(2));
            mg.push(new Boolean(true)); 
            mg.ifICmp(GeneratorAdapter.EQ, jmpLabel);
        }

        return null; 
    }

    //... | WHILE LRB expr RRB block        #whileBlock
    @Override
    public String visitWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx)
    {
        Label whileCond = new Label();
        mg.goTo(whileCond);
        
        jmpLabel = mg.mark();

        Label tmplabel = jmpLabel;

        visit(ctx.getChild(4));

        mg.mark(whileCond);

        jmpLabel = tmplabel; 
        
        if(ctx.getChild(2).getChildCount() > 1 )
        {
            visit(ctx.getChild(2)); //expr
        }
        else
        {
            visit(ctx.getChild(2));
            mg.push(new Boolean(true)); 
            mg.ifICmp(GeneratorAdapter.EQ, jmpLabel);
        }

        return null; 
    }

    //ifEx elseifExp* elseExp?         #ifStat
    @Override 
    public String visitIfStat(LanguageExpressionsParser.IfStatContext ctx)
    {
        endLabel = new Label(); 
        visit(ctx.getChild(0));
        
        for (int i = 1; i <= ctx.getChildCount() - 1; i++)
        {
             
            if (ctx.getChild(i).getChildCount() == 6)
            {   
                visit(ctx.getChild(i));
            }
            else if (ctx.getChild(i).getChildCount() == 2)
            {
                visit(ctx.getChild(i));
            }
            
        }
        
        mg.mark(endLabel); 

        return null;
    }

    //ifEx : IF LRB expr RRB stat             #ifNonBlock
    @Override 
    public String visitIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx)
    {
        //if lower than
        Label condLabel = new Label();
       
        mg.goTo(condLabel);
        
        jmpLabel = mg.mark();

        
        visit(ctx.getChild(4)); //stat
        
        mg.goTo(endLabel); 

        mg.mark(condLabel);
        if(ctx.getChild(2).getChildCount() > 1 )
        {
            
            visit(ctx.getChild(2)); //expr
        }
        else
        {
            visit(ctx.getChild(2));
            mg.push(new Boolean(true)); 
            mg.ifICmp(GeneratorAdapter.EQ, jmpLabel);
        }


        return null; 
    }

    //... | IF LRB expr RRB block              #ifBlock
    @Override 
    public String visitIfBlock(LanguageExpressionsParser.IfBlockContext ctx)
    {
        Label condLabel = new Label();
        
        mg.goTo(condLabel);
        
        jmpLabel = mg.mark();

        Label tmplabel = jmpLabel; 

        visit(ctx.getChild(4)); //stat
        
        mg.goTo(endLabel);
        
        jmpLabel = tmplabel; 

        mg.mark(condLabel);

        //visit(ctx.getChild(2)); //expr

        if(ctx.getChild(2).getChildCount() > 1 )
        {
            visit(ctx.getChild(2)); //expr
        }
        else
        {
            visit(ctx.getChild(2));
            mg.push(new Boolean(true)); 
            mg.ifICmp(GeneratorAdapter.EQ, jmpLabel);
        }

        return null; 
    }

    //elseifExp : ELSE IF LRB expr RRB stat   #elseifNonBlock
    @Override 
    public String visitElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx)
    {
        Label condLabel = new Label();
        //Label afterIf = new Label();
        //endLabel = new Label();
        mg.goTo(condLabel);
        
        jmpLabel = mg.mark();

        visit(ctx.getChild(5)); //stat
        
        mg.goTo(endLabel); 

        mg.mark(condLabel);

        //visit(ctx.getChild(3)); //expr

        if(ctx.getChild(3).getChildCount() > 1 )
        {
            visit(ctx.getChild(3)); //expr
        }
        else
        {
            visit(ctx.getChild(3));
            mg.push(new Boolean(true)); 
            mg.ifICmp(GeneratorAdapter.EQ, jmpLabel);
        }

        return null; 
    }


    //| ELSE IF LRB expr RRB block     #elseifBlock
    @Override 
    public String visitElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx)
    {    
        Label condLabel = new Label();
        
        mg.goTo(condLabel);
        
        jmpLabel = mg.mark();

        visit(ctx.getChild(5)); //stat
        
        mg.goTo(endLabel); 

        mg.mark(condLabel);

        //visit(ctx.getChild(3)); //expr
        if(ctx.getChild(3).getChildCount() > 1 )
        {
            visit(ctx.getChild(3)); //expr
        }
        else
        {
            visit(ctx.getChild(3));
            mg.push(new Boolean(true)); 
            mg.ifICmp(GeneratorAdapter.EQ, jmpLabel);
        } 

        return null; 
    }

    //elseExp : ELSE stat                     #elseNonBlock
    @Override 
    public String visitElseNonBlock(LanguageExpressionsParser.ElseNonBlockContext ctx)
    {
        visit(ctx.getChild(1));
        return null;
    }

    //| ELSE block                       #elseBlock
    @Override 
    public String visitElseBlock(LanguageExpressionsParser.ElseBlockContext ctx)
    {
        visit(ctx.getChild(1));
        return null;
    }

    //functionCall : ID '(' args ')';
    @Override 
    public String visitFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx)
    {
        
        String fct_name = ctx.getChild(0).getText();

        FunctionSymbol aScope = (FunctionSymbol) currentScope.resolve(fct_name);
        ArrayList<OFPType> fctParametersTypes = aScope.getListParam();  
        String fctName = aScope.getName(); 
        String fctType = aScope.getType().toString(); 

        if(fctType.equals("float"))
        {
            fctType = "double"; 
        }
        else if(fctType.equals("float[]"))
        {
            fctType = "double[]"; 
        }
        else if(fctType.equals("string"))
        {
            fctType = "String"; 
        }
        else if(fctType.equals("bool"))
        {
            fctType = "boolean"; 
        }

        String fctSign = fctType + " " + fctName + "(";
        
        for(int i = 0; i < fctParametersTypes.size(); i++)
        {   
            String p = fctParametersTypes.get(i).toString();
            if(p.equals("string"))
            {
                p = "String"; 
            }
            else if(p.equals("bool"))
            {
                p = "boolean"; 
            }
            else if(p.equals("bool[]"))
            {
                p = "boolean[]"; 
            }
            else if(p.equals("float"))
            {
                p = "double";
            }
            else if(p.equals("float[]"))
            {
                p = "double[]";
            }
            
            if(i+1 == fctParametersTypes.size())
            {
                fctSign += p;
            }
            else
            {
                fctSign += p  + ","; 
            }
        }

        fctSign += ")";

        visit(ctx.getChild(2)); // visit args 
        mg.invokeStatic(Type.getType("L"+"Hello"+";"), Method.getMethod(fctSign));
        
        return null; 
    }

    //printExp : (PRINT|PRINTLN) '(' (expr|STRING) ')' SC;
    @Override 
    public String visitPrintExp(LanguageExpressionsParser.PrintExpContext ctx)
    {
        String printType = ctx.getChild(0).getText();
 
        if (printType.equals("println"))
        {
            mg.getStatic(Type.getType(System.class), "out",Type.getType(PrintStream.class)); //push ref to System.out
            visit(ctx.getChild(2)); 
            
            mg.invokeVirtual(Type.getType(PrintStream.class), Method.getMethod("void println ("+ lastVariableType + ")"));
        }
        else if (printType.equals("print"))
        {
            mg.getStatic(Type.getType(System.class), "out",Type.getType(PrintStream.class)); //push ref to System.out
            visit(ctx.getChild(2)); 
             
            mg.invokeVirtual(Type.getType(PrintStream.class), Method.getMethod("void print ("+ lastVariableType + ")"));
        }

        return null;
    }

    //returnExp : 'return' (expr) SC;
    @Override 
    public String visitReturnExp(LanguageExpressionsParser.ReturnExpContext ctx)
    {
        visit(ctx.getChild(1));
        mg.returnValue();
        
        return null;
    }

    /////////////////
    /////////////////
    /////////////////
    /////////////////
    //// Expressions
    
    //declaration                      #declStat
    @Override 
    public String visitDeclStat(LanguageExpressionsParser.DeclStatContext ctx)
    {
        visit(ctx.getChild(0));
        
        return null; 
    }

    @Override 
    public String visitAssignStat(LanguageExpressionsParser.AssignStatContext ctx)
    {
        //String assign = (String) visit(ctx.getChild(0));
        visit(ctx.getChild(0));

        return null; 
    }

    //declaration : anyTypeDecl (assign2 | ID SC);
    @Override public String visitDeclaration(LanguageExpressionsParser.DeclarationContext ctx)
    {
        String varType = ctx.getChild(0).getText(); //anyTypeDecl

        if (ctx.getChildCount() == 2)
        {
            if(varType.equals("float[]"))
            {
                lastVariableType = "double[]";
            }
            else if(varType.equals("bool[]"))
            {
                lastVariableType = "boolean[]";
            }
            else if(varType.equals("string"))
            {
                lastVariableType = "String"; 
            }
            else
            {
                lastVariableType = varType;
            }
            
            visit(ctx.getChild(1)); 
            
            switch (varType) {
                case "int":
                    mg.storeLocal(variableIndex,Type.INT_TYPE);
                    variableIndexType.put(variableIndex, "int");
                    variableIndex += 1;
                    break;
                case "float":
                    mg.storeLocal(variableIndex,Type.DOUBLE_TYPE);
                    
                    variableIndexType.put(variableIndex, "double");
                     
                    variableIndex += 2;
                    break;
                case "char": 
                    mg.storeLocal(variableIndex, Type.CHAR_TYPE);
                    variableIndexType.put(variableIndex, "char");
                    variableIndex += 2; 
                    break;
                case "bool":
                    mg.storeLocal(variableIndex, Type.BOOLEAN_TYPE);
                    variableIndexType.put(variableIndex, "boolean");
                    variableIndex += 1;
                    break;  
                case "int[]":
                    variableIndexType.put(variableIndex, "int[]");
                    Type intArray = Type.getType(Integer[].class);
                   
                    mg.storeLocal(variableIndex, intArray); 
                    variableIndex += 1;
                   
                    break; 
                case "float[]":
                    variableIndexType.put(variableIndex, "double[]");
                    Type doubleArray = Type.getType(Double[].class);
                    mg.storeLocal(variableIndex, doubleArray);  
                    variableIndex += 2;
                    break; 
                case "char[]":
                    variableIndexType.put(variableIndex, "char[]");
                    Type charArray = Type.getType(Character[].class);
                    mg.storeLocal(variableIndex, charArray);  
                    variableIndex += 1; //2
                    break;
                case "bool[]":
                    variableIndexType.put(variableIndex, "boolean[]");
                    Type boolArray = Type.getType(Boolean[].class);
                    mg.storeLocal(variableIndex, boolArray);  
                    variableIndex += 1;
                    break;
                case "string":
                    variableIndexType.put(variableIndex, "String");
                    Type stringArray = Type.getType(Character[].class);
                    mg.storeLocal(variableIndex, stringArray);  
                    variableIndex += 2;
                    break;
                default:
                    break;
            } 
        }
        
        return null;
    }
    
    //assign : idCall ('[' (expr) ']')? ASSIGN expr SC;
    @Override public String visitAssign(LanguageExpressionsParser.AssignContext ctx)
    {
        String varName = ctx.getChild(0).getText();
        

        if(!varMap.containsKey(varName) )  
        {            
            varMap.put(varName, variableIndex);
            
        }        

        if (ctx.getChildCount() == 4)
        {
            int prev_var_index = variableIndex; 
             
            variableIndex = varMap.get(varName);
            
            visit(ctx.getChild(2));
            
            String vType = variableIndexType.get(variableIndex);
            
            
            if(vType.equals("int"))
            {
                mg.storeLocal(variableIndex,Type.INT_TYPE);
            }
            else if(vType.equals("double"))
            {
                mg.storeLocal(variableIndex,Type.DOUBLE_TYPE);
            }
            else if(vType.equals("char"))
            {
                mg.storeLocal(variableIndex,Type.CHAR_TYPE); //TO DO : STRING 
            }
            else if(vType.equals("bool"))
            {
                mg.storeLocal(variableIndex,Type.BOOLEAN_TYPE); //TO DO : STRING 
            }
            else if(vType.equals("string"))
            {
                Type t = Type.getType(Character[].class);
                mg.storeLocal(variableIndex, t);
                
            }
            else if(vType.equals("char[]"))
            {
                
                Type t = Type.getType(Character[].class);
                mg.storeLocal(variableIndex, t);
            }
            
            variableIndex = prev_var_index; 
        }
        else if (ctx.getChildCount() == 7)
        {
            
            int TvariableIndex = varMap.get(varName);
            String vType = variableIndexType.get(TvariableIndex);
            

            int prev_var_index = variableIndex;   
             
            if(vType.equals("char[]"))
            {
                Type t = Type.getType(Character[].class);
                
                if(functionArgs.containsKey(varName))
                {
                    mg.loadArg(TvariableIndex);
                }
                else
                {
                    
                    mg.loadLocal(TvariableIndex);
                }

                visit(ctx.getChild(2)); //Push index
                
                visit(ctx.getChild(5)); //push value 

                mg.visitInsn(Opcodes.CASTORE);
                
            }
            if(vType.equals("int[]"))
            {
                Type t = Type.getType(Integer[].class);
                if(functionArgs.containsKey(varName))
                {
                    mg.loadArg(TvariableIndex);
                }
                else
                {
                    mg.loadLocal(TvariableIndex, t);
                }
                
                visit(ctx.getChild(2)); //Push index
                
                visit(ctx.getChild(5)); //push value 

                mg.visitInsn(Opcodes.IASTORE);
            }
            else if(vType.equals("double[]"))
            {
                Type t = Type.getType(Double[].class);   
               
                if(functionArgs.containsKey(varName))
                {
                    mg.loadArg(TvariableIndex);
                }
                else
                {
                    mg.loadLocal(TvariableIndex, t);
                }
                
                visit(ctx.getChild(2)); //Push index
                
                visit(ctx.getChild(5)); //push value 

                mg.visitInsn(Opcodes.DASTORE);
            }
            else if(vType.equals("boolean[]"))
            {
                Type t = Type.getType(Boolean[].class);   
                
                if(functionArgs.containsKey(varName))
                {
                    mg.loadArg(TvariableIndex);
                }
                else
                {
                    mg.loadLocal(TvariableIndex, t);
                }
                
                visit(ctx.getChild(2)); //Push index
                
                visit(ctx.getChild(5)); //push value 

                mg.visitInsn(Opcodes.BASTORE);
            }       

            variableIndex = prev_var_index; 
        }    
        
        return null; 
    }

    //assign2 : ID ('[' (expr) ']')? ASSIGN expr SC;
    @Override public String visitAssign2(LanguageExpressionsParser.Assign2Context ctx)
    {
        
        String varName = ctx.getChild(0).getText();
        
        if(!varMap.containsKey(varName) )  
        {
            varMap.put(varName,variableIndex);
        }     
        
        if (ctx.getChildCount() == 4)
        {
            visit(ctx.getChild(2));
        }
        else if (ctx.getChildCount() == 7)
        {
            
            visit(ctx.getChild(2));
            visit(ctx.getChild(5));
        }    
        
        return null; 
    }


    //idCall : ID;
    @Override public String visitIdCall(LanguageExpressionsParser.IdCallContext ctx)
    {
        String id = ctx.getChild(0).getText(); //get variable name text 
       
        int id_index = varMap.get(id); 
        
        
        if(!variableIndexType.get(id_index).equals("int[]") && !variableIndexType.get(id_index).equals("double[]") && !variableIndexType.get(id_index).equals("char[]") && !variableIndexType.get(id_index).equals("boolean[]") && !variableIndexType.get(id_index).equals("String"))
        {
            
            if(functionArgs.containsKey(id))
            {
               
                mg.loadArg(functionArgs.get(id));
                
            }
            else
            {
                mg.loadLocal(id_index);
            }
            
        }
        else if(variableIndexType.get(id_index).equals("int[]"))
        {
            Type intArray = Type.getType(Integer[].class);

            if(functionArgs.containsKey(id))
            {
                mg.loadArg(functionArgs.get(id));
            }
            else
            {
                mg.loadLocal(id_index, intArray);
            }
        }
        else if(variableIndexType.get(id_index).equals("double[]"))
        {
            Type doubleArray = Type.getType(Double[].class);
           
            if(functionArgs.containsKey(id))
            {
                mg.loadArg(functionArgs.get(id));
            }
            else
            {
                mg.loadLocal(id_index, doubleArray);
            }
        }
        else if(variableIndexType.get(id_index).equals("char[]"))
        {
            Type charArray = Type.getType(Character[].class);
            if(functionArgs.containsKey(id))
            {
                mg.loadArg(functionArgs.get(id));
            }
            else
            {   
                mg.loadLocal(id_index, charArray);
            }
        }
        else if(variableIndexType.get(id_index).equals("boolean[]"))
        {
            Type boolArray = Type.getType(Boolean[].class);
            
            if(functionArgs.containsKey(id))
            {
                mg.loadArg(functionArgs.get(id));
            }
            else
            {
                mg.loadLocal(id_index, boolArray);
            }
        }
        else if(variableIndexType.get(id_index).equals("String"))
        {
             
            Type stringArray = Type.getType(Character[].class);

            if(functionArgs.containsKey(id))
            {
                
            
                mg.loadArg(functionArgs.get(id));
                
            }
            else
            {
               mg.loadLocal(id_index, stringArray); 
            }

           
        }
        
        lastVariableType = variableIndexType.get(id_index);
        
        return null; 
    }

    @Override public String visitIntType(LanguageExpressionsParser.IntTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();

        if (b.contains(".length"))
        {
            String varName = b.split("\\.")[0];

            int index = varMap.get(varName);
            String type = variableIndexType.get(index);
            

            if(functionArgs.containsKey(varName))
            {
                
                mg.loadArg(index); 
            }
            else
            {
                mg.loadLocal(index);
            }
            
            if(type.equals("String"))
            {
                mg.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/lang/String", "length", "()I", false);
                mg.push(new Integer(2)); 
                mg.math(GeneratorAdapter.SUB, Type.INT_TYPE); 
            }
            else
            {
                mg.arrayLength();
            }
            lastVariableType = "int"; 
            return null; 
        }

        lastVariableType = "int";
        mg.push(new Integer(b));
        
        return null; 
    }

    @Override public String visitFloatType(LanguageExpressionsParser.FloatTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        lastVariableType = "double";
        mg.push(new Double(b));

        return null;
    }

    @Override public String visitCharType(LanguageExpressionsParser.CharTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        lastVariableType = "char";
        mg.push(b.charAt(1)); 

        return null;
    }

    @Override public String visitStringType(LanguageExpressionsParser.StringTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        lastVariableType = "String";
        mg.push(b);
        
        return null;
    }

    @Override public String visitBoolType(LanguageExpressionsParser.BoolTypeContext ctx)
    {
        String b = ctx.getChild(0).getText();
        lastVariableType = "boolean";
        
        if(b.equals("true"))
        {
            mg.push(new Boolean(true)); 
        }
        else
        {
            mg.push(new Boolean(false));
        }
    
        return null;
    }


    //expr (MULT | DIV) expr                                                #multDivExpr
    @Override public String visitMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx)
    {
        visit(ctx.getChild(0));
        visit(ctx.getChild(2)); 
        String sign = ctx.getChild(1).getText();

        Type t = Type.INT_TYPE; 
        if(lastVariableType.equals("int"))
        {
            t = Type.INT_TYPE; 
        }
        else if(lastVariableType.equals("double"))
        {
            t = Type.DOUBLE_TYPE; 
        }

        if(sign.equals("*"))
        {
            mg.math(GeneratorAdapter.MUL, t);
        }
        else if(sign.equals("/"))
        {
            mg.math(GeneratorAdapter.DIV, t);
        }

        return null;        
    }

    //expr (PLUS | MINUS) expr                                              #plusMinusExpr
    @Override public String visitPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx)
    {
        visit(ctx.getChild(0));
        visit(ctx.getChild(2)); 

        String sign = ctx.getChild(1).getText();
        Type t = Type.INT_TYPE; 
        if(lastVariableType.equals("int"))
        {
            t = Type.INT_TYPE; 
        }
        else if(lastVariableType.equals("double"))
        {
            t = Type.DOUBLE_TYPE; 
        }

        if(sign.equals("+"))
        {
            mg.math(GeneratorAdapter.ADD, t);
        }
        else if(sign.equals("-"))
        {
            mg.math(GeneratorAdapter.SUB, t);
        }

        return null; 
    }

    //expr conditionSigns expr                                              #condExpr
    // conditionSigns : (LOWER|UPPER|EQUAL);
    @Override public String visitCondExpr(LanguageExpressionsParser.CondExprContext ctx)
    {
        visit(ctx.getChild(0));
        visit(ctx.getChild(2)); 

        String sign = ctx.getChild(1).getText();
        
        Type t = Type.INT_TYPE; 
        if(lastVariableType.equals("int"))
        {
            t = Type.INT_TYPE;
        }
        else if(lastVariableType.equals("double"))
        {
            t = Type.DOUBLE_TYPE;
        }
        else if(lastVariableType.equals("boolean"))
        {
            t = Type.INT_TYPE; 
        }

        
        if(sign.equals("<"))
        {
            //mg.ifICmp(GeneratorAdapter.LT, jmpLabel); 
            mg.ifCmp(t, GeneratorAdapter.LT, jmpLabel); 
        }
        else if(sign.equals(">"))
        {
            //mg.ifICmp(GeneratorAdapter.GT, jmpLabel); 
            mg.ifCmp(t, GeneratorAdapter.GT, jmpLabel); 
        }
        else if(sign.equals("=="))
        {
            //mg.ifICmp(GeneratorAdapter.EQ, jmpLabel); 
            mg.ifCmp(t, GeneratorAdapter.EQ, jmpLabel); 
        }
        
        return null; 
    }

    //// conditionSigns : (LOWER|UPPER|EQUAL);
    @Override public String visitConditionSigns(LanguageExpressionsParser.ConditionSignsContext ctx)
    {
        return ctx.getChild(0).getText();
    }

    //expr  '.length'                                                        #lengthExpr
    @Override public String visitLengthExpr(LanguageExpressionsParser.LengthExprContext ctx) //never visited actually (to fix !)
    {
        visit(ctx.getChild(0));
        return null;
    }


    //expr ('[' expr ']')                                                   #tableExpr
    @Override public String visitTableExpr(LanguageExpressionsParser.TableExprContext ctx)
    {
        visit(ctx.getChild(0)); //load array in memory (idcall most of the time)
        String arrayType = lastVariableType; 

        
        visit(ctx.getChild(2)); //push index 
        
        
        if(arrayType.equals("int[]"))
        {
            mg.arrayLoad(Type.INT_TYPE);
            lastVariableType = "int";
        }
        else if(arrayType.equals("double[]"))
        {
            mg.arrayLoad(Type.DOUBLE_TYPE);
            lastVariableType = "double";
        }
        else if(arrayType.equals("char[]"))
        { 
            mg.arrayLoad(Type.CHAR_TYPE);
            lastVariableType = "char";
        }
        else if(arrayType.equals("boolean[]"))
        {
            mg.arrayLoad(Type.BOOLEAN_TYPE);
            lastVariableType = "boolean";
        }
        else if(arrayType.equals("string") || arrayType.equals("String")) //bug ici cette ligne  
        {
            mg.push(new Integer(1)); 
            mg.math(GeneratorAdapter.ADD, Type.INT_TYPE);
            mg.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/lang/String", "charAt", "(I)C", false);
            lastVariableType = "char";
        }

        return null;
    }

    //functionCall                                                          #fctExpr
    @Override public String visitFctExpr(LanguageExpressionsParser.FctExprContext ctx)
    {
        //String expr = (String) visit(ctx.getChild(0));
        visit(ctx.getChild(0));

        return null;
    }

    //| 'new ' (intDecl|boolDecl|floatDecl|charDecl) '[' expr ']'             #newExpr
    @Override public String visitNewExpr(LanguageExpressionsParser.NewExprContext ctx)
    {    
        Type t = null;
        int increment_val = 1; 
        
        lastVariableType = (String) visit(ctx.getChild(1));
        
        if(lastVariableType.equals("int[]") || lastVariableType.equals("int") )
        {
            t = Type.INT_TYPE;
        }
        else if(lastVariableType.equals("double[]") || lastVariableType.equals("double"))
        {
            t = Type.DOUBLE_TYPE;
            //increment_val = 2; 
        }
        else if(lastVariableType.equals("char[]") || lastVariableType.equals("char"))
        {
            t = Type.CHAR_TYPE;
            //increment_val = 2; 
        }
        else if(lastVariableType.equals("boolean[]") || lastVariableType.equals("boolean"))
        {
            t = Type.BOOLEAN_TYPE;
        }
        
        visit(ctx.getChild(3)); //get expression  

        mg.newArray(t);
       
        return null;
    }

    

    //... '{' (anyTypeArr)? (',' anyTypeArr)* '}'                               #arrayExpr
    @Override public String visitArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx)
    {
        int count_size = 0; 
        for (int i = 1; i <= ctx.getChildCount() - 2; i += 2)
        {
            count_size++; 
        }

        Type t = null;
        int increment_val = 1; 
        
        if(lastVariableType.equals("int[]"))
        {
            t = Type.INT_TYPE;
        }
        else if(lastVariableType.equals("double[]"))
        {
            t = Type.DOUBLE_TYPE;
        }
        else if(lastVariableType.equals("char[]"))
        {
            t = Type.CHAR_TYPE;
        }
        else if(lastVariableType.equals("boolean[]"))
        {
            t = Type.BOOLEAN_TYPE;
        }
        
        mg.push(Integer.valueOf(count_size * increment_val)); //array memory size
        
        mg.newArray(t); //create array with memory size defined above 

        int arrayIndex = 0;
        for (int i = 1; i <= ctx.getChildCount() - 2; i += 2)
        {
            mg.dup();   // push array ref again
		    mg.push(arrayIndex); // push index
            if(lastVariableType.equals("int[]"))
            {
                mg.push(Integer.valueOf(ctx.getChild(i).getText()));
            }
            else if(lastVariableType.equals("double[]"))
            {
                mg.push(Double.valueOf(ctx.getChild(i).getText()));
            }
            else if(lastVariableType.equals("char[]"))
            {
                mg.push(ctx.getChild(i).getText().charAt(1));
            }
            else if(lastVariableType.equals("boolean[]"))
            {
                mg.push(Boolean.valueOf(ctx.getChild(i).getText()));
            }
		      
		    mg.arrayStore(t);  // pop, pop, pop and store in array
            arrayIndex += increment_val; 
        }

        return null;
    }

    @Override 
    public String visitPrintStat(LanguageExpressionsParser.PrintStatContext ctx)
    {
        visit(ctx.getChild(0));
        
        return null;
    }

    //| returnExp                        #returnStat
    @Override 
    public String visitReturnStat(LanguageExpressionsParser.ReturnStatContext ctx)
    {
        visit(ctx.getChild(0));
        return null;
    }

}
