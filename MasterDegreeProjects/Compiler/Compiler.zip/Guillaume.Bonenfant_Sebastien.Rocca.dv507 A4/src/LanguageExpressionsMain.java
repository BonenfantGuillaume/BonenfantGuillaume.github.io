package src; 

import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;

import generated.LanguageExpressionsLexer; 
import generated.LanguageExpressionsParser; 
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.IOException;


public class LanguageExpressionsMain {

	public static void main(String[] args) throws Exception {
		// Read test program path from args
		// or provide a hard coded path to test program
		//String testProgram = args[0];
		String testProgram;
		if(args.length > 0)
		{
			testProgram = args[0];
		}
		else
		{ 
			String testDir = "/home/sebastien/IdeaProjects/Guillaume.Bonenfant_Sebastien.Rocca.dv507 A4/Samples/";
			testProgram = testDir + "float.ofp";//"Tests/char_test.ofp";//"Tests/stringTest.ofp"; //"Basic.ofp";/
		}

		if (!testProgram.endsWith(".ofp"))
		{
			System.out.println("File must end with '.ofp' extension");
			System.exit(-1);
		}

		System.out.println("Reading test program from: "+testProgram);

		// Parse input program
		System.out.println("Parsing starting");
		LanguageExpressionsParser parser = null;
		LanguageExpressionsParser.StartContext root = null;
		CommonTokenStream commonTokenStream = null;
		try
		{
			CharStream inputStream = CharStreams.fromFileName(testProgram);
			LanguageExpressionsLexer lexer = new LanguageExpressionsLexer( inputStream );			

			commonTokenStream = new CommonTokenStream(lexer);
			parser = new LanguageExpressionsParser(commonTokenStream);
			root = parser.start();
			
		}
			
		catch (IOException e)
		{
			e.printStackTrace();
		}

			System.out.println("\n Parsing completed");

			//new SymbolTableVisitor().visitAllChildren(root);

			//Trees.inspect(root, parser);

			ParseTreeWalker walker = new ParseTreeWalker();
			//PrintListener symbolTableListener = new PrintListener(); 
			SymbolTableListener symbolTableListener = new SymbolTableListener();
			
			walker.walk(symbolTableListener, root);

			System.out.println("INFO : Starting check for duplication, undeclared and unitialized identifiers");
			
			CheckRefListener checkRefListener = new CheckRefListener(symbolTableListener.getSymbolTable());
			 
			walker = new ParseTreeWalker();
			walker.walk(checkRefListener, root);

			System.out.println("INFO : Identifiers check done.");

			/*System.out.println("INFO : Starting type checking...");

			ParamListVisitor prmListVisitor = new ParamListVisitor(symbolTableListener.getSymbolTable());

			prmListVisitor.visit(root);

			System.out.println("INFO : Type checking Done.");*/

			System.out.println("INFO : Starting code translation to Python");

			PythonCodeGeneratorVisitor pCodeVisitor = new PythonCodeGeneratorVisitor(symbolTableListener.getSymbolTable()); 

			pCodeVisitor.visit(root); 

			System.out.println("INFO : Code translation in python done.");	

			System.out.println("INFO : Starting code translation to ASM");
			
			AsmCodeGeneratorVisitor asmCodeVisitor = new AsmCodeGeneratorVisitor(symbolTableListener.getSymbolTable());
			
			asmCodeVisitor.visit(root); 

			System.out.println("INFO : Code translation in ASM done.");	

			System.out.println("INFO : Everything is done!");

	}

	

}
