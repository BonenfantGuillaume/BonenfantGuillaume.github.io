package src;

import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.TerminalNode;

import generated.LanguageExpressionsBaseVisitor;
import generated.LanguageExpressionsParser;

public class PrintVisitor extends LanguageExpressionsBaseVisitor<Object>
{
    @Override public Object visitIfStat(LanguageExpressionsParser.IfStatContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitStart(LanguageExpressionsParser.StartContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitFunctionExp(LanguageExpressionsParser.FunctionExpContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitMain(LanguageExpressionsParser.MainContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitFctParams(LanguageExpressionsParser.FctParamsContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitBlock(LanguageExpressionsParser.BlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitWhileStat(LanguageExpressionsParser.WhileStatContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitDeclStat(LanguageExpressionsParser.DeclStatContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitAssignStat(LanguageExpressionsParser.AssignStatContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitPrintStat(LanguageExpressionsParser.PrintStatContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitFunctionStat(LanguageExpressionsParser.FunctionStatContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitReturnStat(LanguageExpressionsParser.ReturnStatContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitWhileNonBlock(LanguageExpressionsParser.WhileNonBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitWhileBlock(LanguageExpressionsParser.WhileBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitIfNonBlock(LanguageExpressionsParser.IfNonBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitIfBlock(LanguageExpressionsParser.IfBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitElseifNonBlock(LanguageExpressionsParser.ElseifNonBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitElseifBlock(LanguageExpressionsParser.ElseifBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitElseNonBlock(LanguageExpressionsParser.ElseNonBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitElseBlock(LanguageExpressionsParser.ElseBlockContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitFunctionCall(LanguageExpressionsParser.FunctionCallContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitPrintExp(LanguageExpressionsParser.PrintExpContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitReturnExp(LanguageExpressionsParser.ReturnExpContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitConditionSigns(LanguageExpressionsParser.ConditionSignsContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitNewExpr(LanguageExpressionsParser.NewExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitLengthExpr(LanguageExpressionsParser.LengthExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitTableExpr(LanguageExpressionsParser.TableExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitFctExpr(LanguageExpressionsParser.FctExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitArrayExpr(LanguageExpressionsParser.ArrayExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitPlusMinusExpr(LanguageExpressionsParser.PlusMinusExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitCondExpr(LanguageExpressionsParser.CondExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitAnyTypeExpr(LanguageExpressionsParser.AnyTypeExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitMultDivExpr(LanguageExpressionsParser.MultDivExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitRbExpr(LanguageExpressionsParser.RbExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitIdExpr(LanguageExpressionsParser.IdExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitAnyType(LanguageExpressionsParser.AnyTypeContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitAnyTypeArr(LanguageExpressionsParser.AnyTypeArrContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitRBExpr(LanguageExpressionsParser.RBExprContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitAnyTypeDecl(LanguageExpressionsParser.AnyTypeDeclContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitDeclaration(LanguageExpressionsParser.DeclarationContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitAssign(LanguageExpressionsParser.AssignContext ctx) { return visitAllChildren(ctx); }

    @Override public Object visitArgs(LanguageExpressionsParser.ArgsContext ctx) { return visitAllChildren(ctx); }

    public ParseTree visitAllChildren(ParseTree node) 
    {
        System.out.println(node.getClass().getName()+":"+node.getChildCount());
        for (int i=0; i<node.getChildCount();i++) {
            ParseTree child = node.getChild(i);
            if (child instanceof TerminalNode)
            visitTerminalNode( (TerminalNode) child);
            else
            visit(child); // Visit a non-terminal child
            } // Will call corresponding visitX method
        return node;
    }  
    
   
    public void visitTerminalNode(TerminalNode node)
    {
        System.out.println("\t" + node.getClass().getName()+": " + node.getText());
    }

}
